# TipPool Project Assessment

Date: 2026-05-31

## Scope

This assessment reviews the project explanation and packaging files outside the
live JS/CSS source, then checks the live implementation for likely bugs and
risks. No source behavior is changed here.

Reviewed explanatory and packaging files:

- `tippool/index.html`
- `tippool_structure.md`
- `tippool_improvement_plan.md`
- `tippool_v18_summary.md`
- `Untitled document (1).md`
- `tippool_v19.html`
- `tippool_v18_fixed.html`

Reviewed implementation surface:

- `tippool/js/*.js`
- `tippool/index.html`

The live app appears to be the modular static app in `tippool/`, opened through
`tippool/index.html`. The root-level `tippool_v18_fixed.html` and
`tippool_v19.html` files are legacy single-file builds.

## Current Project Shape

- Static browser app, no framework and no `package.json`.
- Live UI has five tabs: Home, Cash, Staff, Summary, Dist
  (`tippool/index.html:152-181`).
- Live app includes persistence/import/export UI in the header
  (`tippool/index.html:27-36`) backed by `tippool/js/persist.js`.
- Live app loads global scripts in sequence, not ES modules
  (`tippool/index.html:215-229`).
- The current distribution engine is the `calculateV19Pipeline` pipeline in
  `tippool/js/engine.js:13-57`, with wrappers at
  `tippool/js/engine.js:394-410`.
- Existing automated coverage is limited to `tippool/js/engine.test.js`.

## Documentation and Explanation File Issues

### High: `tippool_structure.md` describes files and behavior that do not exist

The structure document says the split app is functionally identical to the
single-file app (`tippool_structure.md:3-5`, `tippool_structure.md:319-327`).
That is no longer accurate.

Examples:

- Lists `css/forecast.css`, `js/trade.js`, and `js/forecast.js`
  (`tippool_structure.md:40-52`), but those files are not present in
  `tippool/`.
- Documents `dist.js` APIs for swap cards, `applyTrade`, `toggleDistMode`, and
  Actual/Ideal distribution (`tippool_structure.md:250-253`), while current
  `tippool/js/dist.js` only renders the distribution table and error state.
- Documents `distMode` in global state (`tippool_structure.md:199-206`), but
  current `tippool/js/state.js:1-22` has no `distMode`.
- Says `index.html` uses `<script type="module" src="js/main.js">`
  (`tippool_structure.md:67-70`), but later says plain ordered script tags are
  used (`tippool_structure.md:188-193`). The live app uses ordered plain script
  tags (`tippool/index.html:215-229`).
- Says the font links are in `index.html`
  (`tippool_structure.md:72-93`), but the live `index.html` has no Google Fonts
  links. Fonts are loaded by CSS instead.

Recommendation: treat this file as stale until it is rewritten to document the
current five-tab modular app.

### High: `tippool_v18_summary.md` is historical but reads like current docs

The file is a useful record of prior behavior, but it conflicts heavily with
the live app:

- Describes Swap and What If tabs (`tippool_v18_summary.md:57-65`) that the
  live app does not have.
- Says the tab bar has four buttons (`tippool_v18_summary.md:67-68`) while its
  own table lists five panels and the live app has five different tabs.
- Describes Bills and Staff as modals (`tippool_v18_summary.md:70-98`), while
  Cash and Staff are full tabs in the live app (`tippool/index.html:62-124`).
- Documents a greedy `solveDistribution` algorithm
  (`tippool_v18_summary.md:211-229`), but the live engine uses the newer
  pipeline in `tippool/js/engine.js:13-57`.
- Marks trade-related fixes as implemented
  (`tippool_v18_summary.md:298-305`, `tippool_v18_summary.md:369-381`), but
  the live modular app has no trade UI or trade module.
- Later says Forecast / What If is implemented
  (`tippool_v18_summary.md:481-493`), but it is absent from the live modular
  app.

Recommendation: rename or archive this as v18 historical notes, and do not use
it as current product documentation.

### Medium: `tippool_improvement_plan.md` is partly implemented but still written as a future plan

Much of this plan is now present in the modular app:

- Header session menu/import/export exists in `tippool/index.html:27-36`.
- Persistence exists in `tippool/js/persist.js`.
- iOS tab-bar `visualViewport` handling exists in `tippool/js/main.js:59-67`.
- Synchronous Staff/Cash tab focus exists in `tippool/js/tabs.js:8-16`.
- Page-load pulse hint exists in `tippool/js/main.js:49-57`.

Stale details:

- Says persistence should be added to `js/state.js`
  (`tippool_improvement_plan.md:303-349`), but it lives in `js/persist.js`.
- Shows schema version `v: 1` (`tippool_improvement_plan.md:305-359`), while
  current saves use `v: 2` (`tippool/js/persist.js:13-31`) and load accepts
  v1/v2 (`tippool/js/persist.js:42-48`).
- Includes `distMode` in the snapshot
  (`tippool_improvement_plan.md:288-297`), but current state no longer has
  `distMode`.
- Still references a Forecast branch in `switchTab`
  (`tippool_improvement_plan.md:222-249`), but the live app has no Forecast
  tab.

Recommendation: convert this to an "implemented changes and remaining work"
note, or archive it.

### Medium: legacy HTML files are not labeled as archives

`tippool_v19.html` and `tippool_v18_fixed.html` remain in the repo beside the
live modular app with no README explaining which file is canonical.

Observed differences:

- `tippool_v19.html` still has a Forecast panel (`tippool_v19.html:543`) and
  trade/swap functions (`tippool_v19.html:860-952`).
- `tippool_v18_fixed.html` still has Swap and Forecast panels
  (`tippool_v18_fixed.html:956-967`).
- The live modular app has no Forecast tab and no trade/swap module.

Recommendation: add a README or top-level note naming `tippool/index.html` as
the live entry point and the root HTML files as archives.

### Low: `Untitled document (1).md` is useful but not a usable project document

This file mixes UI notes, embedded images, and a distribution-engine spec. Some
notes align with the live app, such as "Remove what if tab"
(`Untitled document (1).md:8`) and the newer pipeline concept
(`Untitled document (1).md:18-77`). Other notes are scratchpad items without
status.

Recommendation: extract the accurate engine architecture into a named design
document and delete or archive the scratchpad.

### Low: missing project entry documentation

There is no README, no run instructions, no note that the app is static, and no
documented command for the only test file. This makes the legacy HTML files and
stale docs more confusing than they need to be.

Recommended minimum README content:

- Open `tippool/index.html` or serve `tippool/` with any static server.
- Root `tippool_v18_fixed.html` and `tippool_v19.html` are archived builds.
- Run engine tests with `node tippool/js/engine.test.js`.

## Live Implementation Bug and Risk Assessment

### High: Dist tab cannot fix the swap failures that the UI tells users to fix

Current live code still tells users that distribution failures need swaps:

- Engine failure message says "Swap required"
  (`tippool/js/engine.js:39-40`).
- Home status says "Distribution needs swaps" (`tippool/js/cards.js:27-30`).
- Summary warning says "go to Dist tab to fix"
  (`tippool/js/summary.js:59-64`).

But the live Dist tab only renders a warning and a cash-on-hand table for
errors (`tippool/js/dist.js:15-21`). There is no live trade/swap UI and no
`trade.js`.

Impact: a manager can reach a real exact-change failure, be directed to Dist,
and find no action that resolves it.

Recommendation: either restore a supported swap workflow in the modular app, or
change the copy to accurately say the user must manually change bill counts in
Cash.

### High: stale Summary and Dist results remain when staff is cleared or invalidated

`autoCalculate()` returns early when there are no named staff rows or total cash
is zero (`tippool/js/calculator.js:1-12`). It only shows stale banners when cash
is zero (`tippool/js/calculator.js:6-10`).

This handles "cash cleared" but not "staff cleared" or "staff became invalid".
If cash remains and staff names are deleted, Summary and Dist can keep showing
the previous payout with no stale warning.

A similar path exists when all named staff rows are filtered out for invalid
hours. `calculate()` exits for `totH <= 0` and only shows stale banners if
`lastStaff.length` (`tippool/js/calculator.js:50-57`), but silent auto-calc does
not surface an inline validation message.

Impact: the displayed payout can be trusted after its inputs are no longer
valid.

Recommendation: on any early return caused by missing staff, invalid staff, or
zero cash, either clear Summary/Dist back to empty states or show a stale banner
with a reason-specific message.

### Medium: date-only edits may not persist immediately

The date input has no `oninput` or `onchange` handler
(`tippool/index.html:23-36`). `saveState()` stores the date
(`tippool/js/persist.js:13-18`), but it only runs when other actions trigger
auto-calculation or export.

Impact: changing only the date and then reloading can lose the date change.

Recommendation: add an `onchange="saveState()"` hook or a small listener during
bootstrap.

### Medium: numeric inputs silently normalize values

Bill counts are read with `parseInt` (`tippool/js/utils.js:3-6`), so fractional
counts are truncated. Net total also uses `parseInt`
(`tippool/js/cash.js:194-204`). Staff times use `parseFloat`
(`tippool/js/staff.js:83-89`, `tippool/js/calculator.js:41-48`), which accepts
partial strings such as `5abc`.

Impact: some bad input can become a different valid number with no user-facing
validation. This is risky for a payroll/tip calculator.

Recommendation: validate whole-number bill counts and valid decimal time
strings explicitly, and show inline errors instead of silently normalizing.

### Medium: invalid hours are shown in the row but silently excluded from payout

The staff row displays `?` for zero or over-12-hour shifts
(`tippool/js/staff.js:83-89`). The calculation then filters those staff out
(`tippool/js/calculator.js:41-48`). In normal auto-calculate mode, no alert or
inline Summary warning explains that a named person was excluded.

Impact: a named staff member can disappear from payout calculations without a
clear app-level warning.

Recommendation: surface a blocking validation state when any named row has
invalid hours.

### Medium: import validation is shallow

`importSession()` validates that the file parses and has schema version 1 or 2
(`tippool/js/persist.js:68-83`), but it does not validate field shapes such as
`staff` being an array or bill snapshots being objects.

Impact: malformed imported files can be accepted into localStorage and then
produce odd restore behavior on reload.

Recommendation: validate snapshot shape before saving imported JSON.

### Low: re-importing the same file may not fire

The hidden file input calls `importSession(this.files[0])`
(`tippool/index.html:36`). The import code does not reset the input value after
failure or success (`tippool/js/persist.js:68-83`).

Impact: choosing the same file twice may not trigger `change` in some browsers.

Recommendation: clear `importFileInput.value` after handling a file.

### Low: duplicated tip-target math can drift

The same effective-hours and closer/remainder logic is implemented in
`calculate()` (`tippool/js/calculator.js:17-83`) and in net-total helper
`getIdealTargetsForTotal()` (`tippool/js/cash.js:82-134`).

Impact: a future change to payout rules can update one path and not the other,
making net-total ideal breakdown disagree with actual calculation.

Recommendation: extract shared target calculation into one helper used by both
paths.

### Low: dead or partial-port artifacts remain

Examples:

- `rerenderAfterTrade()` exists (`tippool/js/calculator.js:93-98`), but there is
  no live trade UI.
- `syncPoolToInputs()` exists (`tippool/js/cash.js:58-61`) mainly for trade
  workflows that are no longer wired.
- `isSwitchingCashMode` is set in `tippool/js/cash.js:63-80` and declared in
  `tippool/js/state.js:18`, but no code reads it.
- `collectStaffInputRows()` exists (`tippool/js/staff.js:92-103`) and appears
  intended for Forecast, which the live app removed.

Impact: these artifacts make it harder to tell which features are supported and
increase the chance of future edits reactivating incomplete behavior.

Recommendation: remove dead artifacts or mark them with a clear TODO tied to a
planned feature.

## Tests Run

Command:

```bash
node tippool/js/engine.test.js
```

Result:

```text
engine distribution tests passed
```

## Test Coverage Gaps

The existing test file covers two distribution scenarios. There is no automated
coverage for:

- `autoCalculate()` stale-state behavior.
- Staff validation and invalid-hour exclusion.
- Net-total mode and ideal bill breakdown.
- Persistence restore/import/export.
- Distribution failure UX.
- The missing swap/trade workflow in the modular app.

## Recommended Next Actions

1. Add a short README that names `tippool/index.html` as canonical and labels
   the root HTML files as legacy archives.
2. Decide whether Swap/Trade is a supported live feature. If yes, restore it in
   the modular app. If no, remove swap-specific copy and dead trade helpers.
3. Fix stale Summary/Dist behavior for staff-cleared and invalid-staff states.
4. Add explicit validation for bill counts, net total, and staff time inputs.
5. Update or archive stale docs so they no longer describe missing Forecast,
   Swap, or modal-based workflows as current behavior.
6. Add focused tests around stale UI state, input validation, net-total mode,
   and distribution failure handling.
