# Dist Page Mockups

Goal: explore alternatives to data cards for showing why the bill mix works or
does not work. These mockups assume the Dist page can show normal staff rows,
then add denomination/value rows that explain exact-change pressure, cumulative
coverage, and how $50 bills reduce odd-$10 needs.

Sample cash used in the examples:

| Denom | $1 | $5 | $10 | $20 | $50 | $100 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Count | 18 | 4 | 2 | 12 | 3 | 4 |
| Value | $18 | $20 | $20 | $240 | $150 | $400 |

Sample need rows:

| Need type | Meaning | Example |
| --- | --- | ---: |
| Min $1s | Sum of every payout modulo $5 | 16 |
| Min $1+$5 value | Sum of every payout modulo $10 | $36 |
| Min $1+$5+$10 value | Sum of every payout modulo $20, reduced by eligible $50 coverage | $86 |
| $50 odd-ten coverage | Each usable $50 can remove one $10 need from an odd-ten payout | $30 |

## 1. Footer ledger under current Dist table

This keeps the current staff distribution table and replaces data cards with
rows below Total. The `Value` row is the requested `total * bill amount` row.

```text
Name        $100  $50  $20  $10  $5  $1  Tot
Alex          1    -    4    -    1   4  $189
Bea           1    1    3    1    -   2  $222
Cal           -    1    5    -    1   3  $158
------------------------------------------------
Total cnt     2    2   12    1    2   9  $569
Value       200  100  240   10   10   9  $569
Roll 1->100 569  369  269   29   19   9
Need min      -    -    -   86   36  16
Delta         -    -    -  -56   +7  -7
$50 credit    -  -20    -  +20    -   -
```

Data shape:

```js
{
  rows: staffDistributions,
  footer: [
    { key: 'count', cellsByDenom },
    { key: 'value', cellsByDenom },
    { key: 'rollupLowToHigh', cellsByDenom },
    { key: 'needMin', cellsByDenom },
    { key: 'delta', cellsByDenom },
    { key: 'fiftyCredit', cellsByDenom }
  ]
}
```

## 2. Low-to-high exact-change health table

The main table stays untouched. A second table reads left-to-right from $1s to
$100s so the manager sees how smaller bills accumulate.

```text
Exact-change health
Metric               $1    $5   $10   $20   $50   $100
Have count           18     4     2    12     3      4
Have value          $18   $20   $20  $240  $150   $400
Rolling value       $18   $38   $58  $298  $448   $848
Required floor      $16   $36   $86    --    --     --
After $50 credit    $16   $36   $56    --    --     --
Delta               +2    +2    +2     --    --     --
```

$50 integration is explicit in the `After $50 credit` row: odd-ten need drops
from `$86` to `$56` because three $50s can cover `$30` of $10 pressure.

## 3. Compare bars inside the footer

This is still table data, but the need/delta rows become tiny visual bars.

```text
Small bill coverage
$1   have 18  need 16  [##########..] +2
$5   have $38 combined  need $36  [##########..] +$2
$10  have $58 combined  need $86  [######......] -$28
$10 after $50 coverage  need $56  [##########..] +$2
```

Data shape:

```js
[
  { band: 'ones', have: 18, need: 16, unit: 'count' },
  { band: 'oneFive', have: 38, need: 36, unit: 'value' },
  { band: 'oneFiveTen', have: 58, need: 86, adjustedNeed: 56, unit: 'value' }
]
```

## 4. Per-person remainder pressure matrix

Instead of only totals, show which staff payouts create the need. This helps
explain why a shortage exists even when total cash is enough.

```text
Name    Pay   Need $1s   Need $1+$5   Odd $10?   $50 can cover?
Alex   189       4          $9          yes          yes
Bea    222       2          $2           no           no
Cal    158       3          $8          yes          yes
Dee     91       1          $1          yes          yes
---------------------------------------------------------------
Need             10         $20          3           $30 credit
Have             18         $38          $58         $30 credit
```

This structure prioritizes the "why" over the final bill assignment.

## 5. Shortage trade ledger with before/delta/after rows

Use only when the original distribution cannot solve but simple trades can.

```text
Simple trades needed before payout
Break 1 x $20 -> 1 x $10 + 1 x $5 + 5 x $1

            $1   $5   $10   $20   $50   $100
Before       2    -     1     1     -      -
Delta       +5   +1    +1    -1     -      -
After        7    1     2     -     -      -
Value       $7   $5   $20    $0    $0     $0
Roll        $7  $12   $32   $32   $32    $32
Need         5  $10   $30    --    --     --
```

Then the normal distribution table can be labeled `Preview after trades`.

## 6. Two-axis matrix: denomination count vs value

This puts count and value in the same cells, reducing the need for extra rows.

```text
Denom      $1        $5        $10       $20       $50       $100
Have       18/$18    4/$20     2/$20     12/$240   3/$150    4/$400
Need       16/$16    --/$36    --/$86    --        --        --
$50 adj    --        --        -3/$30    --        3/$150    --
After adj  +2/$2     +2/$2     +2/$2     --        --        --
```

$50 integration is represented as a transfer: the $50 column shows the count
that can cover odd-ten slots, and the $10 column shows reduced pressure.

## 7. Running-sum receipt

This is a receipt-style explanation, useful for a manager scanning on a phone.

```text
Can we make exact change?

1. Required singles: 16
   Have singles: 18        OK +2

2. Required $1+$5 value: $36
   Have $1+$5 value: $38   OK +$2

3. Required $1+$5+$10 value before $50s: $86
   Have $1+$5+$10 value: $58
   $50s cover odd-ten slots: -$30
   Adjusted need: $56      OK +$2

4. Remaining value can be carried by $20/$50/$100 rows.
```

Data shape:

```js
{
  checks: [
    { label: 'singles', have: 18, need: 16 },
    { label: 'oneFive', have: 38, need: 36 },
    { label: 'oneFiveTen', have: 58, need: 86, credit: 30 }
  ]
}
```

## 8. Denomination waterfall

Show how cash value accumulates from smallest to largest. Put required
thresholds on the same axis.

```text
$1         $18  |#####
$1+$5      $38  |###########
$1+$5+$10  $58  |################
$1+$5+$10 + $50 credit
            $88 |#########################  need $86
$1..$20    $298 |########################################
$1..$100   $848 |##################################################
```

This is not a card layout; it is closer to a compact horizontal chart.

## 9. Staff rows with inline remainder chips

Each staff row includes the small-bill pressure that payout contributes. The
bottom rows still show value totals and rolling sums.

```text
Name  Pay  Remainder chips             $100 $50 $20 $10 $5 $1 Tot
Alex  189  1s:4  1+5:$9  odd10:$10      1   -   4   -  1  4 $189
Bea   222  1s:2  1+5:$2  odd10:--       1   1   3   1  -  2 $222
Cal   158  1s:3  1+5:$8  odd10:$10      -   1   5   -  1  3 $158
------------------------------------------------------------------
Value                                  200 100 240  10 10  9 $569
Roll 1->100                            --  -- 569 329 89  9
```

The chips tell the story per person without separate diagnostic cards.

## 10. Normal table plus "solve deltas" row group

For an unsolved mix, keep the exact table area but swap totals for deltas.

```text
Shortage view
Row              $1   $5   $10   $20   $50   $100   Total
Have              2    -     1     1     -      -     $30
Need floor        5   $10   $30    -     -      -      --
Delta            -3  -$10  -$20    -     -      -      --
Trade             +5  +1    +1    -1     -      -      $0
After             7    1     2     -     -      -     $30
After delta      +2  +$2   +$2     -     -      -      OK
```

This directly contrasts counts and values, while the trade row remains simple.

## 11. $50 bridge table

Make $50 behavior its own bridge instead of burying it in a card.

```text
$50 bridge for odd-ten payouts
Odd-ten payout      Would need $10?   Uses $50?   $10 pressure removed
Alex $189                yes             no              $0
Cal  $158                yes             yes            $10
Dee  $91                 yes             yes            $10
Rae  $75                 yes             yes            $10
----------------------------------------------------------------
Totals                   4 slots         3 $50s         $30

Then: min $1+$5+$10 need $86 - $30 bridge = $56 adjusted need.
```

This is verbose but very understandable when the $50 rule feels surprising.

## 12. Layered ledger: exactness, small bills, high bills

Group rows by the job each denomination band performs.

```text
Layer         Formula / source                       Have       Need       Status
Exact $1s     sum(pay % 5)                            18         16         OK +2
$1+$5         sum(pay % 10)                           $38        $36        OK +$2
$1+$5+$10     sum(pay % 20)                           $58        $86        short $28
$50 bridge    min($50 count, odd-ten slots) * $10     +$30       credit     OK +$2
$20+          remaining payout value                  $790       $790       OK
```

This is the most compact for diagnostics and may fit above the staff table.

## 13. Split "actual vs minimum" rows under Total

This is closest to the user's row idea and avoids cards entirely.

```text
Name        $1   $5   $10   $20   $50   $100   Total
Alex         4    1     -     4     -      1    $189
Bea          2    -     1     3     1      1    $222
Cal          3    1     -     5     1      -    $158
-----------------------------------------------------
Total cnt    9    2     1    12     2      2    $569
Total val   $9  $10   $10  $240  $100   $200    $569
Roll val    $9  $19   $29  $269  $369   $569
Minimum     16  $36   $86    --    --     --
$50 bridge  --   --  -$20    --   +2      --
Compare     -7  -$17 -$37    --    --     --
Adj compare -7  -$17 -$17    --    --     --
```

If we use this live, the columns should probably be ordered `$1 -> $100` on
Dist diagnostics even if the staff payout columns remain `$100 -> $1`.

## Recommendation to test first

Start with either:

1. **Mockup 13** for the main Dist table footer because it directly matches the
   total/value/rolling/compare row idea.
2. **Mockup 5** for shortage cases because before/delta/after is the clearest
   way to depict simple trades.
3. **Mockup 11** as an expandable explanation if $50 integration remains
   confusing after the footer rows.

