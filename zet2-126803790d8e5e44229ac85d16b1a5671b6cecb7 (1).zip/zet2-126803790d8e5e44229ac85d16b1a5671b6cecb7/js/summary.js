function renderSummary(staffWithBills, staffOrig, total, totH, rate, leftover, poolAfter) {
  const sb = $('stale-summary'); if (sb) sb.classList.remove('visible');
  const dateVal = $('tipDate').value;
  const [yr, mo, dy] = dateVal ? dateVal.split('-') : ['', '', ''];
  const dateStr = (mo && dy && yr) ? `${parseInt(mo)}/${parseInt(dy)}/${yr}` : '';
  const sumFinal = staffWithBills.reduce((s, p) => s + p.final, 0);
  const summaryTime = (t, wrapped) => {
    let hr = Math.floor(t), mn = Math.round((t - hr) * 60);
    if (mn === 60) { hr++; mn = 0; }
    let h12 = hr % 12;
    if (h12 === 0) h12 = 12;
    return `${h12}<span class="time-min">:${mn < 10 ? '0' : ''}${mn}</span><span class="time-ap">${wrapped ? 'a' : 'p'}</span>`;
  };
  const shiftHTML = p => `${summaryTime(p.i, false)}<span class="shift-dash">-</span>${summaryTime(p.o, p.o < p.i)}`;
  const hoursHTML = h => {
    const raw = fmtHrs(h);
    const [whole, frac = ''] = raw.split('.');
    return `<span class="hrs-int">${whole}</span>${frac ? `<span class="hrs-dec">.${frac}</span>` : ''}`;
  };
  const rateHTML = value => {
    const [whole, cents] = value.toFixed(2).split('.');
    return `$${whole}<span class="num-dec">.${cents}</span>/hr`;
  };
  const shiftStarts = staffWithBills.map(p => p.i);
  const shiftEnds   = staffWithBills.map(p => p.eo ?? (p.o < p.i ? p.o + 12 : p.o));
  const timelineStart = Math.min(...shiftStarts);
  const timelineEnd   = Math.max(...shiftEnds);
  const timelineSpan  = Math.max(1, timelineEnd - timelineStart);

  const personCards = staffWithBills.map(p => {
    const safe         = escapeHTML(p.n);
    const bonusLine    = p.bonus > 0
      ? `<div class="person-tip-bonus"><span>${p.base}</span><span>+${p.bonus}</span></div>`
      : '';
    const barStart     = Math.max(0, Math.min(100, ((p.i - timelineStart) / timelineSpan) * 100));
    const barEnd       = Math.max(0, Math.min(100, (((p.eo ?? (p.o < p.i ? p.o + 12 : p.o)) - timelineStart) / timelineSpan) * 100));
    const barWidth     = Math.max(2, barEnd - barStart);
    return `<div class="person-card${p.closer ? ' is-closer' : ''}" onclick="openPersonModal('${escapeHTML(p._rowId)}')">
      <div class="person-card-top">
        <div class="person-main">
          <div class="person-name-row">
            <span class="person-name">${safe}</span>
            <span class="person-shift-inline">${shiftHTML(p)}</span>
          </div>
        </div>
        <div class="person-hrs-block"><div class="person-hrs-val">${hoursHTML(p.h)}</div></div>
        <div class="person-tip-col"><div class="person-tip">${p.final}</div>${bonusLine}</div>
      </div>
      <div class="shift-bar"><div class="shift-bar-fill" style="left:${barStart.toFixed(2)}%;width:${barWidth.toFixed(2)}%"></div></div>
    </div>`;
  }).join('');

  const remainderRow = leftover > 0
    ? `<div class="summary-simple-row">
      <span class="summary-simple-lbl">Remainder</span>
      <span class="summary-simple-val muted">$${leftover}</span>
    </div>`
    : '';
  const unpaid   = staffWithBills.reduce((s, p) => s + Math.max(0, p.rem || 0), 0);
  const remainderPaid = poolValue(lastRemainderBills || {});
  const remShort = leftover > 0 && remainderPaid !== leftover;
  const warnMsg  = lastDistributionError || (unpaid > 0 ? 'Distribution short $' + unpaid : remShort ? 'Remainder cannot be represented by available bills' : '');
  const warnHTML = warnMsg ? `<div class="warn-box">⚠ ${warnMsg} Review Cash counts or adjust the bill mix.</div>` : '';

  $('summary-content').innerHTML = `
    <div class="summary-hero">
      <div class="summary-hero-label">Total Pool${dateStr ? ' · ' + dateStr : ''}</div>
      <div class="summary-hero-val">$${total}</div>
      <div class="summary-meta">
        <div class="summary-meta-item"><div class="summary-meta-lbl">Total Hrs</div><div class="summary-meta-val summary-hrs">${hoursHTML(totH)}</div></div>
        <div class="summary-meta-item"><div class="summary-meta-lbl">Rate</div><div class="summary-meta-val">${rateHTML(rate)}</div></div>
        <div class="summary-meta-item"><div class="summary-meta-lbl">Paid Out</div><div class="summary-meta-val">$${sumFinal}</div></div>
      </div>
    </div>
    <div class="section-hdr">Breakdown</div>
    <div class="summary-breakdown-head"><span></span><span>Hrs</span><span>Tip</span></div>
    ${personCards}
    ${remainderRow}
    <div class="summary-totals-strip">
      <span class="summary-totals-lbl">Total</span>
      <div class="summary-totals-values">
        <span class="summary-totals-hrs">${hoursHTML(totH)}</span>
        <span class="summary-totals-val">${sumFinal + leftover}</span>
      </div>
    </div>
    ${warnHTML}
  `;
}
