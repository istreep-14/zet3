// SplitScreen.jsx — Summary + Distribution merged. Sub-toggle: Payout (per
// person) / Handout (bills to count out). Remainder + per-person handout open
// the unified BillSheet. This is the reveal.

function SplitScreen({ pool, staff, effectiveBills, split, onSheet, onGo }) {
  const { PersonCard, MoneyValue } = window.TipPoolDesignSystem_bcb6c4;
  const { fmtMoney, distribute } = window.TP;
  const DEN = window.CASH_DENOMS;
  const [view, setView] = React.useState('payout');
  const [hv, setHv] = React.useState('table');

  if (!pool || split.rows.length === 0) {
    return (
      <div className="screen split-screen">
        <div className="split-empty">
          <div className="se-icon">◇</div>
          <div className="se-title">Nothing to split yet</div>
          <div className="se-sub">Count cash and add crew first</div>
          <div className="se-actions">
            <button onClick={() => onGo('count')}>Count cash ›</button>
            <button onClick={() => onGo('crew')}>Add crew ›</button>
          </div>
        </div>
      </div>
    );
  }

  const dist = distribute(split.rows, effectiveBills);

  return (
    <div className="screen split-screen">
      <div className="split-hero">
        <div className="split-hero-main">
          <div className="sh-eyebrow">Per head</div>
          <div className="sh-figure">{fmtMoney(split.perHead)}</div>
        </div>
        <div className="split-hero-side">
          <div className="shs-row"><span>Pool</span><span className="gold">{fmtMoney(pool)}</span></div>
          <div className="shs-row"><span>Earners</span><span>{split.rows.length}</span></div>
          <div className="shs-row"><span>Hours</span><span>{split.totalHours ? split.totalHours.toFixed(1) + 'h' : 'even'}</span></div>
        </div>
      </div>

      <div className="split-toggle">
        <button className={view === 'payout' ? 'active' : ''} onClick={() => setView('payout')}>Payout</button>
        <button className={view === 'handout' ? 'active' : ''} onClick={() => setView('handout')}>Handout</button>
      </div>

      {view === 'payout' ? (
        <div className="payout-list">
          {split.rows.map((r) => (
            <PersonCard key={r.id} name={r.name} hours={r.h % 1 === 0 ? r.h : r.h.toFixed(2)}
              inTime={r.inEff || null} outTime={r.outEff || null}
              payout={r.payout} basePay={r.bonus ? null : r.basePay} bonus={r.bonus || null}
              isCloser={r.isCloser} onClick={() => {}} />
          ))}
          <button className={'remainder-row' + (split.remainder === 0 ? ' zero' : '')} onClick={() => split.remainder !== 0 && onSheet('remainder', { amount: split.remainder, leftover: dist.leftover, closer: (split.rows.find((r) => r.isCloser) || {}).name })}>
            <span className="rr-label">Remainder</span>
            <span className="rr-val">{fmtMoney(split.remainder)}</span>
            {split.remainder !== 0 ? <span className="rr-chev">allocate ›</span> : <span className="rr-ok">✓ clean</span>}
          </button>
        </div>
      ) : (
        <div className="handout-block">
          <div className="handout-subtoggle">
            <button className={hv === 'table' ? 'active' : ''} onClick={() => setHv('table')}>Table</button>
            <button className={hv === 'cards' ? 'active' : ''} onClick={() => setHv('cards')}>Cards</button>
          </div>

          {hv === 'table' ? (
            <div className="dist-table-wrap">
              <div className="dist-table">
                <div className="dt-row dt-head">
                  <span className="dt-name">Staff</span>
                  {DEN.map((d) => <span className="dt-cell" key={d}>${d}</span>)}
                  <span className="dt-total">Cut</span>
                </div>
                {dist.people.map((p, i) => (
                  <button className="dt-row" key={p.id} data-role={p.role} onClick={() => onSheet('dist', { people: dist.people, leftover: dist.leftover, leftoverTotal: dist.leftoverTotal, start: i })}>
                    <span className="dt-name">{(p.name || '?').split(' ')[0]}</span>
                    {DEN.map((d) => <span className={'dt-cell' + (p.given[d] ? '' : ' zero')} key={d}>{p.given[d] || '·'}</span>)}
                    <span className="dt-total gold">{fmtMoney(p.paid)}</span>
                  </button>
                ))}
                <div className="dt-row dt-foot">
                  <span className="dt-name">Total</span>
                  {DEN.map((d) => { const out = dist.people.reduce((s, p) => s + (p.given[d] || 0), 0); return <span className="dt-cell" key={d}>{out || '·'}</span>; })}
                  <span className="dt-total">{fmtMoney(dist.people.reduce((s, p) => s + p.paid, 0))}</span>
                </div>
              </div>
              {dist.leftoverTotal > 0 ? <div className="dist-left">Remainder left in drawer: <strong>{fmtMoney(dist.leftoverTotal)}</strong></div> : null}
            </div>
          ) : (
            <React.Fragment>
              <div className="handout-cap">Bills leaving the drawer</div>
              <div className="handout-grid">
                {DEN.map((d) => {
                  const out = dist.people.reduce((s, p) => s + (p.given[d] || 0), 0);
                  return (
                    <div className={'handout-cell' + (out ? '' : ' empty')} key={d}>
                      <span className="hc-denom">${d}</span>
                      <span className="hc-count">{out ? '×' + out : '—'}</span>
                    </div>
                  );
                })}
              </div>
              <div className="handout-people">
                {dist.people.map((p, i) => (
                  <button className="handout-person" key={p.id} data-role={p.role} onClick={() => onSheet('dist', { people: dist.people, leftover: dist.leftover, leftoverTotal: dist.leftoverTotal, start: i })}>
                    <span className="hp-name">{p.name}</span>
                    <span className="hp-bills">{DEN.filter((d) => p.given[d]).map((d) => '$' + d + '×' + p.given[d]).join(' · ') || '—'}</span>
                    <span className="hp-amt">{fmtMoney(p.paid)}</span>
                  </button>
                ))}
              </div>
            </React.Fragment>
          )}

          <button className="handout-cta" onClick={() => onSheet('dist', { people: dist.people, leftover: dist.leftover, leftoverTotal: dist.leftoverTotal, start: 0 })}>
            Hand out bills →
          </button>
        </div>
      )}
    </div>
  );
}

window.SplitScreen = SplitScreen;
