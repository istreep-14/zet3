// crew.jsx — the roster. Role-coded, inline editable, closer toggle, live
// hours. Blank in/out inherit the GLOBAL DEFAULTS (shown as nested
// placeholders) — handy for closers whose exact out-time isn't known yet.

function CrewScreen({ role, setRole, staff, setStaff, defaults, setDefaults }) {
  const { SegmentedControl } = window.TipPoolDesignSystem_bcb6c4;
  const { computeHours, fmtHours } = window.TP;

  const roleAccent = {
    bartender: { color: 'var(--role-bartender)', border: 'var(--role-bartender-border)' },
    server: { color: 'var(--role-server)', border: 'var(--role-server-border)' },
    support: { color: 'var(--role-support)', border: 'var(--role-support-border)' },
  };
  const list = staff.filter((s) => s.role === role);
  const labels = { bartender: 'Bartender', server: 'Server', support: 'Support' };

  function update(id, patch) { setStaff(staff.map((s) => s.id === id ? { ...s, ...patch } : s)); }
  function remove(id) { setStaff(staff.filter((s) => s.id !== id)); }
  function add() { setStaff([...staff, { id: Date.now(), name: '', role, in: '', out: '', isCloser: false }]); }

  const initials = (n) => (n || '?').trim().split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase() || '?';

  return (
    <div className="screen crew-screen">
      <SegmentedControl
        options={[{ value: 'bartender', label: 'Bar' }, { value: 'server', label: 'Server' }, { value: 'support', label: 'Support' }]}
        value={role} onChange={setRole} accentMap={roleAccent} />

      {/* GLOBAL DEFAULTS — nest into any blank in/out below */}
      <div className="defaults-bar">
        <span className="db-label">Default shift</span>
        <div className="db-fields">
          <span className="db-cap">In</span>
          <input className="db-input" placeholder="—" value={defaults.in} onChange={(e) => setDefaults({ ...defaults, in: e.target.value })} />
          <span className="db-sep">–</span>
          <span className="db-cap close">Close</span>
          <input className="db-input" placeholder="—" value={defaults.out} onChange={(e) => setDefaults({ ...defaults, out: e.target.value })} />
        </div>
        <span className="db-hint">Fills blank rows · sets the close time for closers</span>
      </div>

      <div className="crew-head">
        <span className="crew-count">{list.length} {labels[role].toLowerCase()}{list.length === 1 ? '' : 's'}</span>
        {role === 'support' ? <span className="crew-note">share hours · no direct tips</span> : <span className="crew-note">split by hours worked</span>}
      </div>

      <div className="crew-list">
        {list.map((p) => {
          const inBlank = !(p.in || '').trim();
          const outBlank = !(p.out || '').trim();
          const inEff = (p.in || '').trim() || defaults.in;
          const outEff = (p.out || '').trim() || defaults.out;
          const h = computeHours(inEff, outEff);
          const inherited = (inBlank && defaults.in) || (outBlank && defaults.out);
          return (
            <div className="crew-row" key={p.id} data-role={p.role} data-closer={p.isCloser ? 'true' : 'false'}>
              <div className="crew-spine" />
              <div className="crew-avatar">{initials(p.name)}</div>
              <div className="crew-body">
                <input className="crew-name" placeholder="Name" value={p.name} onChange={(e) => update(p.id, { name: e.target.value })} />
                <div className="crew-times">
                  <input className="crew-time" data-inherit={(inBlank && !!defaults.in).toString()} placeholder={defaults.in || 'in'} value={p.in} onChange={(e) => update(p.id, { in: e.target.value })} />
                  <span className="crew-dash">–</span>
                  <input className="crew-time" data-inherit={(outBlank && !!defaults.out).toString()} placeholder={p.isCloser ? 'close' : (defaults.out || 'out')} value={p.out} onChange={(e) => update(p.id, { out: e.target.value })} />
                  <span className="crew-hours" data-inherit={inherited ? 'true' : 'false'}>{h ? fmtHours(h) : '—'}</span>
                </div>
              </div>
              <div className="crew-actions">
                {role !== 'support' ? (
                  <button className={'closer-btn' + (p.isCloser ? ' on' : '')} title="Closer" onClick={() => update(p.id, { isCloser: !p.isCloser })}>★</button>
                ) : null}
                <button className="crew-remove" title="Remove" onClick={() => remove(p.id)}>✕</button>
              </div>
            </div>
          );
        })}
        {list.length === 0 ? <div className="crew-empty">No {labels[role].toLowerCase()}s yet</div> : null}
        <button className="add-btn" onClick={add}>+ Add {labels[role]}</button>
      </div>
    </div>
  );
}

window.CrewScreen = CrewScreen;
