// HomeScreen.jsx — the "Tonight" command center. Three layouts (homeLayout
// tweak): 'command' (progress spine), 'receipt' (register tape), 'ledger'
// (dense dashboard). The hero moment is the per-head reveal.

function RDHomeScreen({ layout = 'command', shift, date, cashTotal, billCount, staff, split, onGo, onSheet }) {
  const { fmtMoney } = window.TP;
  const earners = staff.filter((s) => s.role !== 'support' && (s.name || '').trim());
  const counted = cashTotal > 0;
  const crewed = earners.length > 0;
  const ready = counted && crewed;

  const Step = ({ n, id, label, done, value, sub, active }) => (
    <button className={'step-row' + (done ? ' done' : active ? ' active' : '')} onClick={() => onGo(id)}>
      <span className="step-dot">{done ? '✓' : n}</span>
      <span className="step-main">
        <span className="step-label">{label}</span>
        <span className="step-sub">{sub}</span>
      </span>
      <span className="step-val">{value}</span>
      <span className="step-chev">›</span>
    </button>
  );

  // ---------- COMMAND ----------
  if (layout === 'command') {
    return (
      <div className="screen home-command">
        <div className="tonight-head">
          <div className="tonight-eyebrow">Tonight</div>
          <div className="tonight-date">{date} · {shift === 'night' ? 'Night' : 'Day'} shift</div>
        </div>

        <div className={'hero-card' + (ready ? ' ready' : '')}>
          <div className="hero-sheen" />
          {ready ? (
            <React.Fragment>
              <div className="hero-eyebrow">Per head</div>
              <div className="hero-figure">{fmtMoney(split.perHead)}</div>
              <div className="hero-sub">{fmtMoney(cashTotal)} pool · {earners.length} earners</div>
              <button className="hero-cta" onClick={() => onGo('split')}>See the split ›</button>
            </React.Fragment>
          ) : (
            <React.Fragment>
              <div className="hero-eyebrow">Pool</div>
              <div className="hero-figure muted">{counted ? fmtMoney(cashTotal) : '—'}</div>
              <div className="hero-sub">{counted ? 'Add your crew to split it' : 'Count the drawer to begin'}</div>
              <button className="hero-cta" onClick={() => onGo(counted ? 'crew' : 'count')}>{counted ? 'Add crew ›' : 'Count cash ›'}</button>
            </React.Fragment>
          )}
        </div>

        <div className="step-spine">
          <Step n="1" id="count" label="Count" sub={billCount ? billCount + ' bills' : 'cash on hand'} done={counted} active={!counted} value={counted ? fmtMoney(cashTotal) : '—'} />
          <Step n="2" id="crew" label="Crew" sub={crewed ? earners.length + ' on the floor' : 'who worked'} done={crewed} active={counted && !crewed} value={crewed ? earners.length : '—'} />
          <Step n="3" id="split" label="Split" sub={ready ? 'ready to pay out' : 'payout & handout'} done={ready} active={ready} value={ready ? fmtMoney(split.perHead) + '/ea' : '—'} />
        </div>

        <button className="ghost-action" onClick={() => onSheet('closetime')}>
          <span className="ga-ico">⊘</span> Close-time bills
        </button>
      </div>
    );
  }

  // ---------- RECEIPT ----------
  if (layout === 'receipt') {
    return (
      <div className="screen home-receipt">
        <div className="receipt">
          <div className="receipt-perf top" />
          <div className="receipt-mark">TIP <span>POOL</span></div>
          <div className="receipt-meta">{date} — {shift === 'night' ? 'NIGHT' : 'DAY'} SHIFT</div>
          <div className="receipt-rule" />
          <div className="receipt-line"><span>POOL</span><span className="dots" /><span className="rc-val">{counted ? fmtMoney(cashTotal) : '—'}</span></div>
          <div className="receipt-line"><span>EARNERS</span><span className="dots" /><span className="rc-val plain">{crewed ? earners.length : '—'}</span></div>
          <div className="receipt-line"><span>BILLS</span><span className="dots" /><span className="rc-val plain">{billCount || '—'}</span></div>
          <div className="receipt-rule" />
          <div className="receipt-total">
            <div className="rt-label">PER HEAD</div>
            <div className="rt-figure">{ready ? fmtMoney(split.perHead) : '—'}</div>
          </div>
          <div className="receipt-perf bottom" />
        </div>
        <button className="receipt-cta" onClick={() => onGo(ready ? 'split' : counted ? 'crew' : 'count')}>
          {ready ? 'View split' : counted ? 'Add crew' : 'Count cash'} →
        </button>
      </div>
    );
  }

  // ---------- LEDGER ----------
  const rows = split.rows.slice(0, 4);
  return (
    <div className="screen home-ledger">
      <div className="ledger-tiles">
        <button className="ltile" onClick={() => onGo('count')}>
          <span className="lt-eyebrow">Cash on hand</span>
          <span className="lt-figure gold">{counted ? fmtMoney(cashTotal) : '—'}</span>
          <span className="lt-sub">{billCount ? billCount + ' bills' : 'not counted'}</span>
          <span className="lt-chev">›</span>
        </button>
        <button className="ltile" onClick={() => onGo('crew')}>
          <span className="lt-eyebrow">Crew</span>
          <span className="lt-figure">{crewed ? earners.length : '—'}</span>
          <span className="lt-sub">{crewed ? 'earners' : 'add staff'}</span>
          <span className="lt-chev">›</span>
        </button>
      </div>

      <div className="live-card">
        <div className="live-head">
          <span className="live-title">Live split</span>
          <span className="live-perhead">{ready ? fmtMoney(split.perHead) + ' /head' : 'pending'}</span>
        </div>
        {ready ? (
          <div className="live-rows">
            {rows.map((r) => (
              <div className="live-row" key={r.id} data-role={r.role}>
                <span className="lr-name">{r.name}</span>
                {r.isCloser ? <span className="lr-closer">closer</span> : null}
                <span className="lr-pay">{fmtMoney(r.payout)}</span>
              </div>
            ))}
            {split.rows.length > 4 ? <div className="live-more" onClick={() => onGo('split')}>+{split.rows.length - 4} more · see all ›</div> : null}
          </div>
        ) : (
          <div className="live-empty">Count cash &amp; add crew to see live tips</div>
        )}
      </div>
    </div>
  );
}

window.RDHomeScreen = RDHomeScreen;
