// lib.jsx — TipPool redesign shared engine + helpers (exported to window).
// Pure functions: hours, money formatting, the pool split, and the bill
// distribution that powers the unified BillSheet (dist / remainder / exchange).

const DENOMS = [100, 50, 20, 10, 5, 1];

// "5:00"/"2:00" style shift times → decimal hours, handling PM→AM wrap.
function computeHours(inT, outT) {
  const p = (s) => {
    if (!s) return null;
    const m = String(s).trim().match(/^(\d{1,2})(?::(\d{1,2}))?/);
    if (!m) return null;
    return Number(m[1]) + (m[2] ? Number(m[2]) / 60 : 0);
  };
  let a = p(inT), b = p(outT);
  if (a == null || b == null) return 0;
  // Evening-into-night: an "in" of 5 means 17:00, "out" of 2 means 02:00.
  let ain = a < 12 ? a + 12 : a;          // treat small in as PM
  let bout = b <= 6 ? b + 24 : (b < 12 ? b + 12 : b); // small out = next-day AM
  let h = bout - ain;
  if (h <= 0) h += 24;
  return Math.round(h * 100) / 100;
}

function fmtMoney(n) {
  const v = Math.round(Number(n) || 0);
  return '$' + v.toLocaleString('en-US');
}
function fmtHours(h) {
  if (!h) return '0h';
  return (h % 1 === 0 ? h : h.toFixed(2)) + 'h';
}

// Pool split: earners (bar+server) split by hours; each closer skims a flat bonus.
function splitPool(pool, staff, opts = {}) {
  const closerBonus = opts.closerBonus ?? 24;
  const def = opts.defaults || {};
  const earners = staff.filter((s) => s.role !== 'support' && (s.name || '').trim());
  if (!pool || earners.length === 0) return { rows: [], remainder: pool || 0, totalHours: 0, perHead: 0 };
  // Blank in/out inherit the global defaults (e.g. a closer whose exact
  // out-time you don't know yet falls back to the global close time).
  const withH = earners.map((p) => {
    const inEff = (p.in || '').trim() || def.in || '';
    const outEff = (p.out || '').trim() || def.out || '';
    return { ...p, inEff, outEff, inherited: { in: !(p.in || '').trim() && !!def.in, out: !(p.out || '').trim() && !!def.out }, h: computeHours(inEff, outEff) || 0 };
  });
  let totalHours = withH.reduce((s, p) => s + p.h, 0);
  const evenFallback = totalHours === 0;
  if (evenFallback) totalHours = earners.length;
  const closers = withH.filter((p) => p.isCloser).length;
  const base = pool - closers * closerBonus;
  const rows = withH.map((p) => {
    const weight = evenFallback ? 1 : p.h;
    const share = Math.round((weight / totalHours) * base);
    const bonus = p.isCloser ? closerBonus : 0;
    return { ...p, basePay: share, bonus, payout: share + bonus };
  });
  const paid = rows.reduce((s, r) => s + r.payout, 0);
  return { rows, remainder: pool - paid, totalHours: evenFallback ? 0 : totalHours, perHead: Math.round(pool / earners.length) };
}

// Bill counts {100:n,...} → total + count.
function billsTotal(bills) { return DENOMS.reduce((s, d) => s + d * (Number(bills[d]) || 0), 0); }
function billsCount(bills) { return DENOMS.reduce((s, d) => s + (Number(bills[d]) || 0), 0); }

// Ideal breakdown of a target amount into clean bills (for net-total mode).
function idealBreakdown(total) {
  let rem = Math.round(Number(total) || 0);
  const out = {};
  for (const d of DENOMS) { out[d] = Math.floor(rem / d); rem -= out[d] * d; }
  return out;
}

// Distribute physical bills across payouts (greedy, largest-first), returning a
// per-person bill map and the leftover bills nobody could be paid cleanly.
function distribute(rows, bills) {
  const pool = {};
  DENOMS.forEach((d) => { pool[d] = Number(bills[d]) || 0; });
  const people = rows.map((r) => ({ id: r.id, name: r.name, role: r.role, target: r.payout, given: {}, paid: 0 }));
  // Largest payouts first so big bills land where they fit.
  const order = [...people].sort((a, b) => b.target - a.target);
  for (const p of order) {
    for (const d of DENOMS) {
      while (pool[d] > 0 && p.paid + d <= p.target) {
        pool[d]--; p.given[d] = (p.given[d] || 0) + 1; p.paid += d;
      }
    }
  }
  const leftover = {};
  DENOMS.forEach((d) => { if (pool[d] > 0) leftover[d] = pool[d]; });
  const leftoverTotal = DENOMS.reduce((s, d) => s + d * (pool[d] || 0), 0);
  return { people, leftover, leftoverTotal };
}

// Exchange suggestion: break the largest leftover bills into smaller ones so the
// remainder can be split (illustrative — what to grab from the register drawer).
function exchangeSuggestion(leftover) {
  const give = [], get = [];
  DENOMS.forEach((d) => { if (leftover[d] && d >= 20) give.push({ denom: d, count: leftover[d] }); });
  let smallNeed = give.reduce((s, g) => s + g.denom * g.count, 0);
  if (smallNeed > 0) {
    let rem = smallNeed;
    [5, 1].forEach((d) => { const n = Math.floor(rem / d); if (n) { get.push({ denom: d, count: n }); rem -= n * d; } });
  }
  return { give, get };
}

Object.assign(window, {
  CASH_DENOMS: DENOMS,
  TP: { computeHours, fmtMoney, fmtHours, splitPool, billsTotal, billsCount, idealBreakdown, distribute, exchangeSuggestion },
});
