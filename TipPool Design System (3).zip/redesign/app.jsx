// app.jsx — shell: header, navigation models (tabs / hybrid / flow), the four
// screens, the unified BillSheet, and the Tweaks panel. Reads design tokens
// via ../styles.css and DS components via the bundle.

const { useState, useMemo } = React;
const Icons = window.TipPoolIcons;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "navModel": "hybrid",
  "homeLayout": "command",
  "density": "regular",
  "tabBar": "labeled",
  "vibe": "safe",
  "accent": "#e94560"
}/*EDITMODE-END*/;

const SEED_STAFF = [
  { id: 1, name: 'Maya Rodriguez', role: 'bartender', in: '5:00', out: '2:00', isCloser: true },
  { id: 2, name: 'Devon Clarke', role: 'bartender', in: '6:00', out: '12:00', isCloser: false },
  { id: 3, name: 'Sam Okafor', role: 'server', in: '5:30', out: '12:45', isCloser: false },
  { id: 4, name: 'Priya Anand', role: 'server', in: '6:00', out: '1:30', isCloser: false },
  { id: 5, name: 'Theo Brandt', role: 'support', in: '7:00', out: '1:00', isCloser: false },
];
const SEED_DAYPOOLS = [
  { id: 'a', name: 'Bar', crew: 2, total: '640' },
  { id: 'b', name: 'Patio', crew: 3, total: '480' },
];

const TABS = [
  { id: 'home', label: 'Home', icon: 'home' },
  { id: 'count', label: 'Count', icon: 'cash' },
  { id: 'crew', label: 'Crew', icon: 'staff' },
  { id: 'split', label: 'Split', icon: 'summary' },
];
const STEPS = ['count', 'crew', 'split'];

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [tab, setTab] = useState('home');
  const [shift, setShift] = useState('night');
  const [mode, setMode] = useState('perbill');
  const [netTotal, setNetTotal] = useState('1284');
  const [bills, setBills] = useState({ 100: 6, 50: 4, 20: 14, 10: 8, 5: 12, 1: 24 });
  const [staff, setStaff] = useState(SEED_STAFF);
  const [dayPools, setDayPools] = useState(SEED_DAYPOOLS);
  const [crewRole, setCrewRole] = useState('bartender');
  const [defaults, setDefaults] = useState({ in: '5:00', out: '2:00' });
  const [menu, setMenu] = useState(false);
  const [sheet, setSheet] = useState({ kind: null, payload: {}, seq: 0 });

  const { fmtMoney, billsTotal, billsCount, idealBreakdown, splitPool } = window.TP;

  const cashTotal = shift === 'day'
    ? dayPools.reduce((s, p) => s + (Number(p.total) || 0), 0)
    : (mode === 'nettotal' ? (Number(netTotal) || 0) : billsTotal(bills));
  const billCount = mode === 'perbill' ? billsCount(bills) : 0;
  const split = useMemo(() => splitPool(cashTotal, staff, { defaults }), [cashTotal, staff, defaults]);
  const effectiveBills = mode === 'perbill' ? bills : idealBreakdown(cashTotal);

  function openSheet(kind, payload = {}) {
    if (kind === 'exchange') {
      const { exchangeSuggestion, distribute } = window.TP;
      const d = distribute(split.rows, effectiveBills);
      payload = exchangeSuggestion(d.leftover);
    }
    if (kind === 'closetime') payload = { bills: effectiveBills, closeTime: defaults.out, closers: staff.filter((s) => s.isCloser && (s.name || '').trim()).map((s) => s.name) };
    setSheet((s) => ({ kind, payload, seq: s.seq + 1 }));
  }
  function closeSheet() { setSheet((s) => ({ ...s, kind: null })); }

  function newSession() {
    setStaff([]); setBills({}); setNetTotal(''); setDayPools(SEED_DAYPOOLS.map((p) => ({ ...p, total: '' })));
    setMenu(false); setTab('home');
  }

  const stepIdx = STEPS.indexOf(tab);
  const showTabBar = t.navModel === 'tabs' || t.navModel === 'hybrid';
  const showProgress = t.navModel === 'hybrid' || t.navModel === 'flow';
  const showFlowNav = t.navModel === 'flow';

  // progress completion
  const earners = staff.filter((s) => s.role !== 'support' && (s.name || '').trim()).length;
  const done = { count: cashTotal > 0, crew: earners > 0, split: cashTotal > 0 && earners > 0 };

  return (
    <div className="app" data-vibe={t.vibe} data-density={t.density} data-tabbar={t.tabBar} data-nav={t.navModel}
      style={{ '--accent': t.accent }} onClick={() => menu && setMenu(false)}>

      {/* HEADER */}
      <div className="hdr">
        <button className="hdr-mark" onClick={() => setTab('home')}>
          TIP <span>POOL</span>
        </button>
        <div className="hdr-right" onClick={(e) => e.stopPropagation()}>
          <span className="hdr-date">Fri · Jun 6</span>
          <button className="hdr-btn" onClick={() => setMenu(!menu)}>⋯</button>
          {menu ? (
            <div className="session-menu">
              <button onClick={() => setMenu(false)}>Save session</button>
              <button onClick={() => setMenu(false)}>History</button>
              <button className="danger" onClick={newSession}>New session</button>
            </div>
          ) : null}
        </div>
      </div>

      {/* PROGRESS STRIP (hybrid / flow) */}
      {showProgress ? (
        <div className="progress-strip">
          {STEPS.map((s, i) => (
            <button key={s} className={'ps-step' + (tab === s ? ' current' : '') + (done[s] ? ' done' : '')} onClick={() => setTab(s)}>
              <span className="ps-dot">{done[s] ? '✓' : i + 1}</span>
              <span className="ps-label">{s}</span>
              {i < STEPS.length - 1 ? <span className="ps-line" /> : null}
            </button>
          ))}
        </div>
      ) : null}

      {/* CONTENT */}
      <div className="content">
        {tab === 'home' && <window.RDHomeScreen layout={t.homeLayout} shift={shift} date="Fri, Jun 6" cashTotal={cashTotal} billCount={billCount} staff={staff} split={split} onGo={setTab} onSheet={openSheet} />}
        {tab === 'count' && <window.CountScreen shift={shift} setShift={setShift} mode={mode} setMode={setMode} bills={bills} setBills={setBills} netTotal={netTotal} setNetTotal={setNetTotal} dayPools={dayPools} setDayPools={setDayPools} onSheet={openSheet} />}
        {tab === 'crew' && <window.CrewScreen role={crewRole} setRole={setCrewRole} staff={staff} setStaff={setStaff} defaults={defaults} setDefaults={setDefaults} />}
        {tab === 'split' && <window.SplitScreen pool={cashTotal} staff={staff} effectiveBills={effectiveBills} split={split} onSheet={openSheet} onGo={setTab} />}
      </div>

      {/* FLOW NAV (wizard) */}
      {showFlowNav ? (
        <div className="flow-nav">
          <button className="flow-back" disabled={stepIdx <= 0} onClick={() => stepIdx > 0 && setTab(STEPS[stepIdx - 1])}>‹ Back</button>
          {stepIdx < STEPS.length - 1 ? (
            <button className="flow-next" onClick={() => setTab(STEPS[Math.max(0, stepIdx) + 1] || 'split')}>{stepIdx < 0 ? 'Start counting' : 'Next'} ›</button>
          ) : (
            <button className="flow-next gold" onClick={() => openSheet('dist', distPayload(split, effectiveBills))}>Hand out →</button>
          )}
        </div>
      ) : null}

      {/* TAB BAR */}
      {showTabBar ? (
        <div className="tab-bar">
          {TABS.map((tb) => {
            const TIcon = Icons[tb.icon];
            const active = tb.id === tab;
            let sub = '', cls = '';
            if (tb.id === 'count') { sub = cashTotal ? fmtMoney(cashTotal) : '—'; cls = cashTotal ? 'gold' : ''; }
            if (tb.id === 'crew') { sub = earners ? earners + '' : '—'; cls = earners ? 'blue' : ''; }
            if (tb.id === 'split') { sub = done.split ? fmtMoney(split.perHead) : '—'; cls = done.split ? 'gold' : ''; }
            return (
              <button key={tb.id} className={'tab-btn' + (active ? ' active' : '')} onClick={() => setTab(tb.id)}>
                <span className="tab-ico-wrap"><TIcon size={19} />{(tb.id === 'count' && cashTotal) || (tb.id === 'crew' && earners) ? <span className="tab-dot" /> : null}</span>
                <span className="tab-label">{tb.label}</span>
                {sub ? <span className={'tab-sub ' + cls}>{sub}</span> : <span className="tab-sub" />}
              </button>
            );
          })}
        </div>
      ) : null}

      {/* UNIFIED SHEET */}
      <window.BillSheet key={sheet.seq} kind={sheet.kind} payload={sheet.payload} open={!!sheet.kind} onClose={closeSheet} />

      {/* TWEAKS */}
      <TweaksPanel>
        <TweakSection label="Navigation" />
        <TweakRadio label="Model" value={t.navModel} options={[{ value: 'tabs', label: 'Tabs' }, { value: 'hybrid', label: 'Hybrid' }, { value: 'flow', label: 'Wizard' }]} onChange={(v) => setTweak('navModel', v)} />
        <TweakRadio label="Tab bar" value={t.tabBar} options={[{ value: 'labeled', label: 'Labeled' }, { value: 'minimal', label: 'Minimal' }, { value: 'pill', label: 'Pill' }]} onChange={(v) => setTweak('tabBar', v)} />
        <TweakSection label="Home" />
        <TweakRadio label="Layout" value={t.homeLayout} options={[{ value: 'command', label: 'Command' }, { value: 'receipt', label: 'Receipt' }, { value: 'ledger', label: 'Ledger' }]} onChange={(v) => setTweak('homeLayout', v)} />
        <TweakSection label="Feel" />
        <TweakRadio label="Density" value={t.density} options={[{ value: 'compact', label: 'Compact' }, { value: 'regular', label: 'Regular' }, { value: 'roomy', label: 'Roomy' }]} onChange={(v) => setTweak('density', v)} />
        <TweakRadio label="Visual" value={t.vibe} options={[{ value: 'safe', label: 'Refined' }, { value: 'bold', label: 'Bold' }]} onChange={(v) => setTweak('vibe', v)} />
        <TweakColor label="Accent" value={t.accent} options={['#e94560', '#f5c842', '#4a9eff', '#2ecc71', '#9d7dca']} onChange={(v) => setTweak('accent', v)} />
      </TweaksPanel>
    </div>
  );
}

function distPayload(split, bills) {
  const d = window.TP.distribute(split.rows, bills);
  return { people: d.people, leftover: d.leftover, leftoverTotal: d.leftoverTotal, start: 0 };
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
