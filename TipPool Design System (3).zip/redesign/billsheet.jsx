// BillSheet.jsx — ONE unified bottom-sheet "ledger tape" used for every bill
// operation: close-time pull, remainder allocation, bill exchange, and the
// per-person distribution table. Same chrome everywhere → one mental model.

const { useEffect: useSheetEffect } = React;

// --- Bottom-sheet shell (scrim + slide-up sheet) ---------------------------
function Sheet({ open, onClose, children, tone = 'gold' }) {
  useSheetEffect(() => {
    function onKey(e) { if (e.key === 'Escape') onClose(); }
    if (open) window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  return (
    <div className={'sheet-scrim' + (open ? ' open' : '')} onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={'sheet' + (open ? ' open' : '')} data-tone={tone} onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
}

// --- The ledger table: the shared register-tape rows -----------------------
// rows: [{ label, count, value, tone }]  tone: 'money' | 'plus' | 'minus' | null
function Ledger({ rows, head = ['Denom', 'Count', 'Value'] }) {
  return (
    <div className="ledger">
      <div className="ledger-head">
        <span>{head[0]}</span><span>{head[1]}</span><span>{head[2]}</span>
      </div>
      <div className="ledger-perf" />
      {rows.map((r, i) => (
        <div className="ledger-row" key={i} data-tone={r.tone || ''}>
          <span className="lr-label">{r.label}</span>
          <span className="lr-count">{r.count}</span>
          <span className="lr-value">{r.value}</span>
        </div>
      ))}
    </div>
  );
}

// --- Header / footer atoms --------------------------------------------------
function SheetHead({ title, subtitle, onClose }) {
  return (
    <div className="sheet-head">
      <div className="sheet-drag" />
      <div className="sheet-title-row">
        <div>
          <div className="sheet-title">{title}</div>
          {subtitle ? <div className="sheet-sub">{subtitle}</div> : null}
        </div>
        <button className="sheet-x" onClick={onClose}>✕</button>
      </div>
    </div>
  );
}

// === The router: one component, four shapes ================================
function BillSheet({ kind, payload, open, onClose }) {
  const { fmtMoney } = window.TP;
  const DEN = window.CASH_DENOMS;
  const [who, setWho] = React.useState((payload && payload.start) || 0);

  if (!kind) return <Sheet open={open} onClose={onClose}>{null}</Sheet>;

  // ---- CLOSE-TIME PULL ----------------------------------------------------
  if (kind === 'closetime') {
    const bills = payload.bills || {};
    const rows = DEN.filter((d) => bills[d]).map((d) => ({
      label: '$' + d, count: '×' + bills[d], value: fmtMoney(d * bills[d]), tone: 'money',
    }));
    const total = DEN.reduce((s, d) => s + d * (bills[d] || 0), 0);
    const closers = payload.closers || [];
    return (
      <Sheet open={open} onClose={onClose} tone="accent">
        <SheetHead title="Close-Time Pull" subtitle="Bills counted out of the drawer at close" onClose={onClose} />
        <div className="sheet-body">
          <div className="ct-meta">
            <div className="ct-time"><span className="ct-cap">Close time</span><span className="ct-val">{payload.closeTime || '—'}</span></div>
            <div className="ct-closers">
              <span className="ct-cap">Closing</span>
              {closers.length ? (
                <span className="ct-chips">{closers.map((n, i) => <span className="ct-chip" key={i}>{n.split(' ')[0]}</span>)}</span>
              ) : <span className="ct-none">no closers marked</span>}
            </div>
          </div>
          <Ledger rows={rows.length ? rows : [{ label: '—', count: '', value: 'no bills', tone: '' }]} />
          <div className="ledger-total"><span>Pulled</span><span className="lt-val">{fmtMoney(total)}</span></div>
          <button className="sheet-cta accent" onClick={onClose}>Confirm pull</button>
        </div>
      </Sheet>
    );
  }

  // ---- REMAINDER ALLOCATION ----------------------------------------------
  if (kind === 'remainder') {
    const { amount = 0, leftover = {}, closer } = payload;
    const rows = DEN.filter((d) => leftover[d]).map((d) => ({
      label: '$' + d, count: '×' + leftover[d], value: fmtMoney(d * leftover[d]), tone: 'money',
    }));
    return (
      <Sheet open={open} onClose={onClose} tone="gold">
        <SheetHead title="Remainder" subtitle="Cash that didn't divide evenly" onClose={onClose} />
        <div className="sheet-body">
          <div className="rem-figure">{fmtMoney(amount)}</div>
          <Ledger rows={rows.length ? rows : [{ label: '$1', count: '×' + amount, value: fmtMoney(amount), tone: 'money' }]} />
          <div className="rem-choices">
            <div className="rem-choice active">To closer{closer ? ' · ' + closer : ''}</div>
            <div className="rem-choice">Split evenly</div>
            <div className="rem-choice">Hold for tomorrow</div>
          </div>
          <button className="sheet-cta gold" onClick={onClose}>Allocate {fmtMoney(amount)}</button>
        </div>
      </Sheet>
    );
  }

  // ---- BILL EXCHANGE ------------------------------------------------------
  if (kind === 'exchange') {
    const { give = [], get = [] } = payload;
    const giveRows = give.map((g) => ({ label: '$' + g.denom, count: '×' + g.count, value: fmtMoney(g.denom * g.count), tone: 'minus' }));
    const getRows = get.map((g) => ({ label: '$' + g.denom, count: '×' + g.count, value: fmtMoney(g.denom * g.count), tone: 'plus' }));
    return (
      <Sheet open={open} onClose={onClose} tone="blue">
        <SheetHead title="Bill Exchange" subtitle="Break big bills so the pool divides clean" onClose={onClose} />
        <div className="sheet-body">
          <div className="xch-block"><div className="xch-cap minus">Give to drawer</div>
            <Ledger rows={giveRows.length ? giveRows : [{ label: '—', count: '', value: 'nothing', tone: '' }]} head={['Denom', 'Count', 'Value']} />
          </div>
          <div className="xch-arrow">↓</div>
          <div className="xch-block"><div className="xch-cap plus">Take back</div>
            <Ledger rows={getRows.length ? getRows : [{ label: '—', count: '', value: 'nothing', tone: '' }]} head={['Denom', 'Count', 'Value']} />
          </div>
          <button className="sheet-cta blue" onClick={onClose}>Mark exchanged</button>
        </div>
      </Sheet>
    );
  }

  // ---- DISTRIBUTION (per-person handout) ----------------------------------
  if (kind === 'dist') {
    const { people = [], leftover = {}, leftoverTotal = 0 } = payload;
    const cur = people[who] || people[0];
    return (
      <Sheet open={open} onClose={onClose} tone="gold">
        <SheetHead title="Hand Out" subtitle="Exact bills to count into each hand" onClose={onClose} />
        <div className="sheet-body">
          <div className="dist-people">
            {people.map((p, i) => (
              <button key={p.id} className={'dist-chip' + (i === who ? ' active' : '')} data-role={p.role} onClick={() => setWho(i)}>
                <span className="dc-name">{(p.name || '?').split(' ')[0]}</span>
                <span className="dc-amt">{fmtMoney(p.paid)}</span>
              </button>
            ))}
          </div>
          {cur ? (
            <React.Fragment>
              <Ledger rows={DEN.filter((d) => cur.given[d]).map((d) => ({ label: '$' + d, count: '×' + cur.given[d], value: fmtMoney(d * cur.given[d]), tone: 'money' }))} />
              <div className="ledger-total"><span>{(cur.name || '').split(' ')[0]}'s cut</span><span className="lt-val">{fmtMoney(cur.paid)}</span></div>
            </React.Fragment>
          ) : null}
          {leftoverTotal > 0 ? (
            <div className="dist-left">Remainder after handout: <strong>{fmtMoney(leftoverTotal)}</strong></div>
          ) : null}
          <button className="sheet-cta gold" onClick={onClose}>Mark all paid</button>
        </div>
      </Sheet>
    );
  }

  return <Sheet open={open} onClose={onClose}>{null}</Sheet>;
}

window.BillSheet = BillSheet;
window.TPSheet = { Sheet, Ledger, SheetHead };
