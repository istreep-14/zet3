// CountScreen.jsx — count the drawer. Night = single pool (net-total OR
// per-bill). Day = simplified multi-pool list. Feeds the exchange sheet.

function CountScreen({ shift, setShift, mode, setMode, bills, setBills, netTotal, setNetTotal, dayPools, setDayPools, onSheet }) {
  const { SegmentedControl } = window.TipPoolDesignSystem_bcb6c4;
  const { DenomRow } = window.TipPoolDesignSystem_bcb6c4;
  const { fmtMoney, billsTotal, billsCount, idealBreakdown } = window.TP;
  const DEN = window.CASH_DENOMS;

  const billTotal = billsTotal(bills);
  const total = mode === 'nettotal' ? (Number(netTotal) || 0) : billTotal;
  const ideal = idealBreakdown(netTotal);

  // ---------- DAY: simplified multi-pool ----------
  if (shift === 'day') {
    const dayTotal = dayPools.reduce((s, p) => s + (Number(p.total) || 0), 0);
    return (
      <div className="screen count-screen">
        <SegmentedControl options={[{ value: 'night', label: 'Night' }, { value: 'day', label: 'Day' }]} value={shift} onChange={setShift} />
        <div className="count-total-bar">
          <span className="ctb-label">All pools</span>
          <span className="ctb-val">{dayTotal ? fmtMoney(dayTotal) : '—'}</span>
        </div>
        <div className="day-note">Day shift runs separate pools. Count each one — they split independently.</div>
        <div className="pool-list">
          {dayPools.map((p, i) => (
            <div className="pool-card" key={p.id} data-on={(Number(p.total) > 0).toString()}>
              <div className="pool-card-head">
                <span className="pool-name">{p.name}</span>
                <span className="pool-meta">{p.crew} crew</span>
              </div>
              <div className="pool-input-row">
                <span className="pool-dollar">$</span>
                <input className="pool-input" inputMode="numeric" placeholder="0" value={p.total}
                  onChange={(e) => { const v = e.target.value; setDayPools(dayPools.map((x, j) => j === i ? { ...x, total: v } : x)); }} />
              </div>
            </div>
          ))}
          <button className="add-pool" onClick={() => setDayPools([...dayPools, { id: Date.now(), name: 'Pool ' + (dayPools.length + 1), crew: 0, total: '' }])}>+ Add pool</button>
        </div>
      </div>
    );
  }

  // ---------- NIGHT: single pool ----------
  return (
    <div className="screen count-screen">
      <SegmentedControl options={[{ value: 'night', label: 'Night' }, { value: 'day', label: 'Day' }]} value={shift} onChange={setShift} />

      <div className="count-hero">
        <div className="count-hero-eyebrow">Cash on hand</div>
        <div className={'count-hero-val' + (total ? '' : ' muted')}>{total ? fmtMoney(total) : '$0'}</div>
        <div className="count-hero-sub">{mode === 'perbill' ? billsCount(bills) + ' bills counted' : 'net total entered'}</div>
      </div>

      <SegmentedControl options={[{ value: 'nettotal', label: 'Net Total' }, { value: 'perbill', label: 'Count Bills' }]} value={mode} onChange={setMode} />

      {mode === 'nettotal' ? (
        <div className="net-block">
          <div className="net-input-row">
            <span className="net-dollar">$</span>
            <input className="net-input" inputMode="numeric" placeholder="0" value={netTotal} onChange={(e) => setNetTotal(e.target.value)} autoFocus />
          </div>
          <div className="net-ideal">
            <div className="net-ideal-cap">Ideal breakdown</div>
            {Number(netTotal) > 0 ? (
              <div className="ideal-grid">
                {DEN.filter((d) => ideal[d]).map((d) => (
                  <div className="ideal-chip" key={d}><span className="ic-denom">${d}</span><span className="ic-count">×{ideal[d]}</span></div>
                ))}
              </div>
            ) : <div className="net-ideal-empty">Enter a total to see the cleanest bill split</div>}
          </div>
        </div>
      ) : (
        <div className="bills-block">
          <div className="denom-stack">
            {DEN.map((d) => (
              <DenomRow key={d} denom={d} count={bills[d] || ''} subtotal={bills[d] ? fmtMoney(d * bills[d]) : null}
                onCountChange={(v) => setBills({ ...bills, [d]: v })} />
            ))}
          </div>
          <div className="bills-total-row">
            <span>Total</span>
            <span className={'btr-val' + (billTotal ? '' : ' muted')}>{fmtMoney(billTotal)}</span>
          </div>
        </div>
      )}

      <button className="ghost-action" onClick={() => onSheet('exchange')}>
        <span className="ga-ico">⇄</span> Bill exchange
      </button>
    </div>
  );
}

window.CountScreen = CountScreen;
