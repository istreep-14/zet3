# TipPool Design System

A design system reconstructed from **TipPool** — a mobile-first, back-of-house web app that bartenders and servers use to count a cash tip pool and split it fairly across a shift. The aesthetic is unapologetically utilitarian: a dark, near-black room you can read at the end of a double, where **money is gold, the closer is red, and every number is monospaced** so columns line up like a register tape.

This project packages that product's foundations (color, type, spacing), its reusable React primitives, and a full interactive recreation of the app, so you can design new TipPool screens, marketing, or decks that look native to the product.

---

## Sources

Everything here was reverse-engineered from the live app source. If you have access, read these to go deeper:

- **GitHub:** `istreep-14/zet3` — https://github.com/istreep-14/zet3 (branch `main`)
  - The original task referenced a `cursor` branch and a `component-block-mockups-8f90/` subtree; neither exists on the repo today. The complete, current app lives at the repository root on `main` — that is the source of truth used here.
  - Key files lifted: `css/variables.css` (tokens), `css/*.css` (every screen's styling), `index.html` (structure + SVG icons), `js/cards.js` (computed values), `README.md` + `project-overview.md` (product intent).
- A read-only copy of the original app CSS + markup is vendored under **`reference/`** in this project for fidelity checks. It is NOT part of the shipped system (not reachable from `styles.css`) — treat it as documentation. The reference CSS uses the app's original non-aliased token names (`--surface2`, `--gold2`); the shipped tokens use the hyphenated convention (`--surface-2`, `--gold-2`).

> Explore the repository further to build richer TipPool designs — the `js/` calculation logic and the day-shift multi-pool screens have detail this system only samples.

---

## CONTENT FUNDAMENTALS

How TipPool talks. The voice is a **terse line cook's shorthand** — functional, lowercase-leaning, never chatty.

- **Tone:** Direct and operational. Labels are nouns or noun phrases, not sentences: "Cash on Hand", "Net Total", "Bill Counts", "Add Bartender". Instructions are short imperatives: "Enter cash & staff to calculate", "Calculate first to see bill distribution".
- **Person:** Addresses the user implicitly (imperative) — "Enter total above to see ideal bill breakdown". Rarely "you"; never "we" or "I". The app is a tool, not a personality.
- **Casing:**
  - Section/label microcopy is **UPPERCASE, mono, letter-spaced** ("CASH ON HAND", "REMAINDER", "HOURS").
  - Buttons are UPPERCASE mono ("CALCULATE", "NEW SESSION").
  - Human names and the occasional explanatory sentence are **sentence/title case** in Plex Sans ("Maya Rodriguez", "Support staff share a pool of hours but earn no tips.").
- **Numbers are the content.** Money always carries a `$` and thousands separators ("$1,284"). Hours append a bare `h` ("8.5h"). Times are bare ("5:00–2:00"). Counts are plain ("5 people", "42 bills"). Empty/zero states render as an em dash "—", never "$0.00" noise.
- **Warnings** are flagged with a single ⚠ glyph and a clipped clause: "⚠ Bills cleared — results below are outdated."
- **Emoji:** None, except the one functional ⚠ caution glyph. No decorative emoji, ever.
- **Vibe:** A back-of-house clipboard. If a word doesn't help someone split cash faster, it's cut.

**Copy examples to imitate:**
| Context | Copy |
|---|---|
| Tile label | `CASH ON HAND` |
| Tile sub | `42 bills` / `employees` |
| Empty state | `No data yet` · `Enter cash & staff to calculate` |
| Support note | `Support staff share a pool of hours but earn no tips directly.` |
| Destructive | `New Session` |
| Stale results | `⚠ Bills cleared — results below are outdated.` |

---

## VISUAL FOUNDATIONS

- **Surfaces — near-black navy, stacked lightest-on-top.** A five-step ramp from `--bg #0a0a0f` (page) → `--surface #13131e` (cards) → `--surface-2 #1a1a28` (raised chrome: toggles, headers, caps) → `--surface-3 #202030` (the active toggle segment, avatars). Inputs sink into a darker well, `--input-bg #0d0d18`. There is no white anywhere.
- **Color is rationed and semantic.** The palette is almost monochrome navy; color carries meaning, never decoration:
  - **Gold (`--gold #f5c842`) = money, and only money.** Dollar values, the net-total figure, subtotals. Hours use a brighter gold (`--gold-2 #ffd966`).
  - **Red (`--accent #e94560`) = the closer, danger, the active nav tab, focused inputs.** It's the one hot color and it draws the eye to the single most important control on screen.
  - **Role hues** appear only in staff coding: bartender **blue** (`--blue-2`), server **gold**, support **purple** (`--purple #9d7dca`). Each gets a fg + dim border + near-black tinted fill.
  - **Green (`--green #2ecc71`)** = positive only: the "+$24" closer bonus pill, an "ok" status dot, a ready-to-calculate border.
- **Type — mono-first.** Two families, both IBM Plex. **IBM Plex Mono** sets every number, label, denomination, time, and button — anything that benefits from tabular alignment (`font-variant-numeric: tabular-nums` is used heavily). **IBM Plex Sans** is reserved for human names and the rare explanatory sentence. Weights run 400–800; money values and names are 800 (heavy). The scale is compact and phone-tuned: hero $ total at 40px down to 7px role-badge micro-labels. Uppercase mono labels are always letter-spaced 1.2–1.4px.
- **Spacing — tight and phone-first.** A 480px-max single column. **8px (`--space-4`) does most of the work** as the gap between cards and list rows; inner card padding is 10–16px. Nothing is airy; density is the point.
- **Backgrounds:** Flat near-black. **No gradients, no images, no patterns, no texture** — with exactly one exception: a 2.5%-opacity top-left light **sheen** (`--sheen`) washed over the home stat tiles to give them a faint sense of being lit. That's the only "decoration" in the entire system.
- **Corners & cards:** Cards and large surfaces use `--radius 14px`; inputs, rows, toggles and buttons use `--radius-sm 9px`; tiny role badges use `--radius-chip 4px`; bonus pills are fully round (`--radius-pill`). A card is: `--surface` fill + `1px solid --border (#252538)` + 14px radius. **No drop shadows on cards** — separation comes from the 1px hairline border and the surface-step, not elevation.
- **Borders do the structural work.** Hairlines (`--border #252538`) divide everything; emphasis/hover/focus steps up to `--border-2 #2e2e48`. Dashed borders (`--border-2`) mark "add" affordances and the remainder row. Colored borders signal state: gold-dim for "short", green for "ready", red for focus/closer.
- **Elevation is reserved for overlays only.** Nothing on the page floats. The only shadows in the system are `--shadow-menu` (the session dropdown) and `--shadow-sheet` (the bottom-sheet modal lift). Modals slide up from the bottom as sheets with a `blur(6px)` scrim over `rgba(0,0,0,.75)`.
- **Hover / press states.** Touch-first, so feedback is on `:active`, not hover. Press = the surface steps up one level (`--surface` → `--surface-2`) and the border brightens (`--border` → `--border-2`). Buttons additionally scale to `0.97`. Active nav/icons recolor to red. Disabled = `opacity: 0.4`.
- **Animation.** Minimal and quick: 0.12–0.15s color/border transitions on `--ease` (`cubic-bezier(.4,0,.2,1)`). The one expressive motion is the bottom-sheet slide-in (0.28s on a spring-ish `--ease-sheet`). No bounces, no looping decoration, no parallax.
- **Transparency & blur** are used only for the modal scrim (`rgba(0,0,0,.75)` + `backdrop-filter: blur(6px)`). Surfaces themselves are opaque.
- **Imagery vibe:** There is essentially no photography or illustration — this is a numbers tool. The only brand image is the app icon (a tip-jar/money mark on a dark gradient tile).

---

## ICONOGRAPHY

- **System:** A small set of **Lucide-style line icons** — 24×24 viewBox, `fill: none`, `stroke: currentColor`, round caps/joins, ~1.8–2.2 stroke weight. They're inline `<svg>` in the source (not an icon font, not PNGs), so they inherit text color and recolor to red when their tab is active.
- **Where they appear:** the 5 bottom-tab glyphs (home, wallet/cash, users/staff, list/summary, grid/dist), the shift toggle (moon = night, sun = day), and a clock for "default times". That's the whole set — the app is otherwise text-and-number driven.
- **This system** re-implements that exact set as a tiny React module: **`ui_kits/tippool/icons.jsx`** exposes `window.TipPoolIcons` with `home, cash, staff, summary, dist, moon, sun, clock`. Lift icons from there; if you need one TipPool doesn't have, match it from **Lucide** (https://lucide.dev) — same geometry and stroke weight — and flag the addition.
- **Unicode as icons:** The app leans on a few glyphs in place of icons — `›` (red chevron, "this navigates"), `⋯` (session menu), `—` (em-dash empty state), `⚠` (stale warning), `+` (add). Reuse these rather than drawing new icons for those meanings.
- **Emoji:** Not used. Do not introduce emoji.
- **Logo:** The app icon (tip-jar `$` mark) is in `assets/brand/` at 192px and 512px. The wordmark is the lockup **TIP <span style="color:red">POOL</span>** set in Plex Mono — "POOL" in `--accent`. See the *App icon & wordmark* card.

---

## Index / manifest

**Root**
- `styles.css` — the single entry point consumers link. `@import`s the four token files only.
- `readme.md` — this file.
- `SKILL.md` — Agent-Skill front-matter so this system can be dropped into Claude Code.
- `manifest.json` — the original app's PWA manifest (reference).

**`tokens/`** — all CSS custom properties (hyphenated convention):
- `fonts.css` — IBM Plex Mono + Sans via Google Fonts `@import`.
- `colors.css` — surfaces, borders, accent/gold/role/status, plus semantic aliases.
- `typography.css` — families, weights (`--fw-*`), the size ramp (`--text-*`), tracking, leading.
- `spacing.css` — `--space-*`, radii, layout (`--app-max-w`, `--hdr-h`, `--tab-h`), shadows, motion.

**`components/`** — reusable React primitives (each: `.jsx` + `.d.ts` + `.prompt.md`, with one `*.card.html` specimen per folder):
- `core/` — **Button** (accent/gold/secondary/ghost/danger/dashed), **Badge** (role/closer/bonus/neutral), **SegmentedControl** (the shift/role/mode toggle).
- `money/` — **MoneyValue** (the canonical gold $ figure), **StatCard** (home dashboard tile), **DenomRow** (cash-counter denomination row).
- `people/` — **PersonCard** (the Summary payout row: avatar, hours, gold payout, bonus pill).

**`ui_kits/tippool/`** — interactive, full-app recreation:
- `index.html` — the running app (Home · Cash · Staff · Summary · Dist), seeded with a realistic night shift. Counts cash, adds staff, and splits the pool live.
- `HomeScreen / CashScreen / StaffScreen / SummaryScreen .jsx` — the four built-out tabs.
- `icons.jsx` — the Lucide-style icon set (`window.TipPoolIcons`).

**`guidelines/`** — foundation specimen cards (render in the Design System tab): surfaces, text ramp, money/accent, role coding & status, type scale, mono & sans specimens, spacing scale, radii, elevation, and the brand logo/wordmark.

**`assets/brand/`** — the app icon at 192px and 512px.

**`reference/`** — read-only vendored copy of the original app's CSS + markup for fidelity. Not shipped.

---

## How to build with it

1. Link `styles.css` for tokens + fonts.
2. Compose the React primitives from `window.TipPoolDesignSystem_<hash>` (run `check_design_system` for the exact namespace) — see each component's `*.card.html` for live usage.
3. Stay in the voice: mono numbers, gold for money, red for the closer/danger, 8px gaps, 1px-border cards, no gradients, no emoji.
