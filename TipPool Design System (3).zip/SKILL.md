---
name: tippool-design
description: Use this skill to generate well-branded interfaces and assets for TipPool, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## What's here
- `styles.css` — single entry point; `@import`s the token files (fonts + colors + type + spacing).
- `tokens/` — all CSS custom properties (hyphenated: `--surface-2`, `--gold-2`, `--text-sm`, `--space-4`…).
- `components/` — React primitives (Button, Badge, SegmentedControl, MoneyValue, StatCard, DenomRow, PersonCard). Each folder has a `*.card.html` showing live usage.
- `ui_kits/tippool/` — an interactive recreation of the full app (Home · Cash · Staff · Summary). Best reference for layout, header, and the bottom tab bar.
- `guidelines/` — foundation specimen cards (color, type, spacing, brand).
- `assets/brand/` — the app icon (192/512px).
- `reference/` — read-only copy of the original app source for fidelity (not shipped).

## The one-paragraph brief
TipPool is a dark, back-of-house cash-tip-pool splitter. **Money is gold, the closer/danger is red, everything is monospaced (IBM Plex Mono) except human names (IBM Plex Sans).** Near-black navy surfaces stacked lightest-on-top, 1px hairline-border cards with no drop shadow, 8px gaps, 14px card radius. No gradients (one faint sheen on home tiles), no emoji, no photography. Labels are UPPERCASE tracked-out mono; copy is terse and operational. Icons are Lucide-style line icons (see `ui_kits/tippool/icons.jsx`).
