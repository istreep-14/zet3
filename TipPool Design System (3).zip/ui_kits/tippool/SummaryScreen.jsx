// SummaryScreen — hero pool total + per-person payout rows (PersonCard).
function SummaryScreen({ pool, staff, onGo }) {
  const { PersonCard, MoneyValue } = window.TipPoolDesignSystem_bcb6c4;
  const earners = staff.filter((s) => s.role !== 'support' && s.name.trim());

  if (!pool || earners.length === 0) {
    return (
      <div style={{ textAlign: 'center', padding: '40px 16px', border: '1px dashed var(--border)', borderRadius: 'var(--radius)', color: 'var(--muted)' }}>
        <div style={{ fontFamily: 'var(--font-sans)', fontWeight: 800, fontSize: '0.95rem', color: 'var(--text-2)', marginBottom: '4px' }}>No data yet</div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.66rem' }}>Enter cash &amp; staff to calculate</div>
        <div onClick={() => onGo('cash')} style={{ marginTop: '14px', display: 'inline-block', cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: '0.62rem', fontWeight: 700, color: 'var(--accent)', letterSpacing: '0.5px', textTransform: 'uppercase' }}>Go to Cash ›</div>
      </div>
    );
  }

  // Allocate by hours, with a small closer bonus skim.
  const totalHours = earners.reduce((s, p) => s + (computeHours(p.in, p.out) || 0), 0) || earners.length;
  const closerBonus = 24;
  const closers = earners.filter((p) => p.isCloser).length;
  const bonusPot = closers * closerBonus;
  const base = pool - bonusPot;

  const rows = earners.map((p) => {
    const h = computeHours(p.in, p.out) || (totalHours / earners.length);
    const share = Math.round((h / totalHours) * base);
    const bonus = p.isCloser ? closerBonus : 0;
    return { ...p, h, payout: share + bonus, basePay: share, bonus };
  });
  const paid = rows.reduce((s, r) => s + r.payout, 0);
  const remainder = pool - paid;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
      <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '14px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <MoneyValue label="Pool total" amount={pool} size="hero" />
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.5rem', fontWeight: 700, letterSpacing: '1.4px', textTransform: 'uppercase', color: 'var(--muted)' }}>Splitting</div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.95rem', fontWeight: 700, color: 'var(--text-2)', marginTop: '3px' }}>{earners.length} staff</div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--muted)', marginTop: '2px' }}>{totalHours.toFixed(2)}h total</div>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
        {rows.map((r) => (
          <PersonCard key={r.id} name={r.name} hours={r.h % 1 === 0 ? r.h : r.h.toFixed(2)}
            inTime={r.in || null} outTime={r.out || null}
            payout={r.payout} basePay={r.bonus ? null : r.basePay} bonus={r.bonus || null}
            isCloser={r.isCloser} onClick={() => {}} />
        ))}
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '11px 13px', background: 'var(--surface-2)', border: '1px dashed var(--border-2)', borderRadius: 'var(--radius-sm)' }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.58rem', fontWeight: 700, letterSpacing: '1px', textTransform: 'uppercase', color: 'var(--muted)' }}>Remainder</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.9rem', fontWeight: 800, color: remainder === 0 ? 'var(--muted-2)' : 'var(--text-2)', fontVariantNumeric: 'tabular-nums' }}>${remainder}</span>
      </div>
    </div>
  );
}
window.SummaryScreen = SummaryScreen;
