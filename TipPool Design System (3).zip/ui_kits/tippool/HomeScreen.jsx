// HomeScreen — dashboard with the two stat tiles + a live-tips preview.
function HomeScreen({ cashTotal, billCount, staff, onGo }) {
  const { StatCard } = window.TipPoolDesignSystem_bcb6c4;
  const hasData = cashTotal > 0 && staff.length > 0;
  const perHead = hasData ? Math.round(cashTotal / staff.length) : 0;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
      <div style={{ display: 'flex', gap: '8px' }}>
        <div style={{ flex: 1.4 }}>
          <StatCard label="Cash on Hand" value={'$' + cashTotal.toLocaleString()}
            sub={billCount ? billCount + ' bills' : '—'} onClick={() => onGo('cash')} />
        </div>
        <div style={{ flex: 1 }}>
          <StatCard label="Staff" value={staff.length} sub="employees" tone="neutral" onClick={() => onGo('staff')} />
        </div>
      </div>

      {hasData ? (
        <div style={{ background: 'var(--surface)', border: '1px solid var(--green-border)', borderRadius: 'var(--radius)', padding: '14px 16px' }}>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.52rem', fontWeight: 800, letterSpacing: '1.2px', textTransform: 'uppercase', color: 'var(--muted)' }}>Ready to calculate</div>
          <div style={{ color: 'var(--text)', fontSize: '1.25rem', fontWeight: 800, marginTop: '5px' }}>~${perHead}<span style={{ color: 'var(--muted)', fontSize: '0.7rem', fontWeight: 600, fontFamily: 'var(--font-mono)' }}> / head est.</span></div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px', marginTop: '12px' }}>
            {[['Pool', '$' + cashTotal.toLocaleString()], ['Staff', staff.length], ['Closers', staff.filter(s => s.isCloser).length]].map(([k, v]) => (
              <div key={k} style={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '10px' }}>
                <span style={{ display: 'block', color: 'var(--muted)', fontFamily: 'var(--font-mono)', fontSize: '0.5rem', fontWeight: 800, letterSpacing: '0.8px', textTransform: 'uppercase' }}>{k}</span>
                <strong style={{ display: 'block', color: 'var(--gold)', fontFamily: 'var(--font-mono)', fontSize: '0.9rem', marginTop: '4px', fontWeight: 700 }}>{v}</strong>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div style={{ textAlign: 'center', color: 'var(--muted)', fontFamily: 'var(--font-mono)', fontSize: '0.7rem', padding: '32px 0', border: '1px dashed var(--border)', borderRadius: 'var(--radius)' }}>
          Add cash &amp; staff to see live tips
        </div>
      )}
    </div>
  );
}
window.HomeScreen = HomeScreen;
