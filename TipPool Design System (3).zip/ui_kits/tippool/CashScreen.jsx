// CashScreen — net-total entry with a bill-count mode that uses DenomRow.
const DENOMS = [100, 50, 20, 10, 5, 1];

function CashScreen({ shift, setShift, mode, setMode, bills, setBills, netTotal, setNetTotal }) {
  const { SegmentedControl, DenomRow, Button } = window.TipPoolDesignSystem_bcb6c4;
  const Icons = window.TipPoolIcons;

  const billTotal = DENOMS.reduce((s, d) => s + d * (Number(bills[d]) || 0), 0);
  const billCount = DENOMS.reduce((s, d) => s + (Number(bills[d]) || 0), 0);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      <SegmentedControl
        value={shift} onChange={setShift}
        options={[
          { value: 'night', label: 'Night Shift' },
          { value: 'day', label: 'Day Shift' },
        ]} />

      {mode === 'nettotal' ? (
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '18px 16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '2rem', fontWeight: 800, color: netTotal ? 'var(--gold)' : 'var(--muted-2)' }}>$</span>
            <input type="number" inputMode="numeric" placeholder="0" value={netTotal}
              onChange={(e) => setNetTotal(e.target.value)}
              style={{ flex: 1, minWidth: 0, background: 'transparent', border: 'none', outline: 'none', color: netTotal ? 'var(--gold)' : 'var(--text)', fontFamily: 'var(--font-mono)', fontSize: '2rem', fontWeight: 800, fontVariantNumeric: 'tabular-nums' }} />
          </div>
          <div style={{ marginTop: '12px', paddingTop: '12px', borderTop: '1px solid var(--border)', color: 'var(--muted)', fontFamily: 'var(--font-mono)', fontSize: '0.62rem', lineHeight: 1.5 }}>
            {netTotal ? `Pool of $${Number(netTotal).toLocaleString()} ready to split across the night.` : 'Enter total above to see ideal bill breakdown'}
          </div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
          {DENOMS.map((d) => (
            <DenomRow key={d} denom={d} count={bills[d] || ''}
              subtotal={'$' + (d * (Number(bills[d]) || 0)).toLocaleString()}
              onCountChange={(v) => setBills({ ...bills, [d]: v })} />
          ))}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '4px', padding: '10px 12px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)' }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', fontWeight: 700, letterSpacing: '1px', textTransform: 'uppercase', color: 'var(--muted)' }}>Total</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '1.3rem', fontWeight: 800, color: billTotal ? 'var(--gold)' : 'var(--muted-2)', fontVariantNumeric: 'tabular-nums' }}>${billTotal.toLocaleString()}</span>
          </div>
        </div>
      )}

      <SegmentedControl
        value={mode} onChange={setMode}
        options={[
          { value: 'nettotal', label: 'Net Total' },
          { value: 'perbill', label: 'Bill Counts' },
        ]} />
    </div>
  );
}
window.CashScreen = CashScreen;
window.CASH_DENOMS = DENOMS;
