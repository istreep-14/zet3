// StaffScreen — role toggle + per-role staff rows with name, in/out, hours.
function StaffRow({ person, roleColor, onChange }) {
  const hrs = computeHours(person.in, person.out);
  return (
    <div style={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', overflow: 'hidden' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 9px' }}>
        <input value={person.name} placeholder="Name" onChange={(e) => onChange({ ...person, name: e.target.value })}
          style={{ flex: 1, minWidth: 0, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', color: 'var(--text)', fontFamily: 'var(--font-sans)', fontSize: '0.92rem', fontWeight: 700, padding: '8px 10px', outline: 'none' }} />
        {person.isCloser ? (
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.48rem', fontWeight: 700, letterSpacing: '0.7px', textTransform: 'uppercase', color: 'var(--accent)', border: '1px solid var(--accent)', background: '#1a0608', borderRadius: 'var(--radius-chip)', padding: '2px 5px' }}>Closer</span>
        ) : null}
      </div>
      <div style={{ display: 'flex', borderTop: '1px solid var(--border)' }}>
        <TimeField label="In" value={person.in} onChange={(v) => onChange({ ...person, in: v })} />
        <TimeField label="Out" value={person.out} onChange={(v) => onChange({ ...person, out: v })} border />
        <div style={{ width: 78, flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', borderLeft: '1px solid var(--border)', background: 'var(--surface)' }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.44rem', fontWeight: 800, letterSpacing: '0.5px', textTransform: 'uppercase', color: 'var(--muted-2)' }}>Hours</span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '1rem', fontWeight: 800, color: hrs ? 'var(--gold-2)' : 'var(--muted-2)', lineHeight: 1.1 }}>{hrs ? hrs + 'h' : '—'}</span>
        </div>
      </div>
    </div>
  );
}

function TimeField({ label, value, onChange, border }) {
  return (
    <div style={{ flex: 1, minWidth: 0, display: 'flex', alignItems: 'center', gap: '6px', padding: '7px 10px', borderLeft: border ? '1px solid var(--border)' : 'none' }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.5rem', fontWeight: 700, letterSpacing: '0.5px', textTransform: 'uppercase', color: 'var(--muted)' }}>{label}</span>
      <input value={value} placeholder="—" onChange={(e) => onChange(e.target.value)}
        style={{ flex: 1, minWidth: 0, background: 'transparent', border: 'none', outline: 'none', color: 'var(--text)', fontFamily: 'var(--font-mono)', fontSize: '0.84rem', fontWeight: 600 }} />
    </div>
  );
}

function computeHours(inT, outT) {
  const p = (t) => { const m = /^(\d{1,2})(?::(\d{2}))?$/.exec((t || '').trim()); return m ? Number(m[1]) + (m[2] ? Number(m[2]) / 60 : 0) : null; };
  let a = p(inT), b = p(outT);
  if (a == null || b == null) return null;
  if (b <= a) b += 12; // crude pm wrap for the mock
  const h = b - a;
  return h > 0 && h < 24 ? Math.round(h * 100) / 100 : null;
}

function StaffScreen({ role, setRole, staff, setStaff }) {
  const { SegmentedControl, Button } = window.TipPoolDesignSystem_bcb6c4;
  const list = staff.filter((s) => s.role === role);
  const colorMap = { bartender: 'role-bartender', server: 'role-server', support: 'role-support' };
  const update = (id, next) => setStaff(staff.map((s) => (s.id === id ? next : s)));
  const add = () => setStaff([...staff, { id: Date.now(), name: '', role, in: '', out: '', isCloser: false }]);
  const labels = { bartender: 'Bartender', server: 'Server', support: 'Support' };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      <SegmentedControl
        value={role} onChange={setRole}
        options={[
          { value: 'bartender', label: 'Bartender' },
          { value: 'server', label: 'Server' },
          { value: 'support', label: 'Support' },
        ]}
        accentMap={{
          bartender: { color: 'var(--role-bartender)', border: 'var(--role-bartender-border)' },
          server: { color: 'var(--role-server)', border: 'var(--role-server-border)' },
          support: { color: 'var(--role-support)', border: 'var(--role-support-border)' },
        }} />

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0 2px' }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', fontWeight: 700, letterSpacing: '0.5px', textTransform: 'uppercase', color: `var(--${colorMap[role]})` }}>{list.length} {list.length === 1 ? 'person' : 'people'}</span>
      </div>

      {role === 'support' ? (
        <div style={{ color: 'var(--muted)', fontFamily: 'var(--font-mono)', fontSize: '0.58rem', lineHeight: 1.5, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '9px 11px' }}>
          Support staff share a pool of hours but earn no tips directly — they're tipped out from the bar &amp; server pools.
        </div>
      ) : null}

      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {list.map((p) => (
          <StaffRow key={p.id} person={p} roleColor={colorMap[role]} onChange={(next) => update(p.id, next)} />
        ))}
      </div>

      <Button variant="dashed" fullWidth onClick={add}>+ Add {labels[role]}</Button>
    </div>
  );
}
window.StaffScreen = StaffScreen;
window.computeHours = computeHours;
