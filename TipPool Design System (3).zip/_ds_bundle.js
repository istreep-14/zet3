/* @ds-bundle: {"format":3,"namespace":"TipPoolDesignSystem_bcb6c4","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"SegmentedControl","sourcePath":"components/core/SegmentedControl.jsx"},{"name":"DenomRow","sourcePath":"components/money/DenomRow.jsx"},{"name":"MoneyValue","sourcePath":"components/money/MoneyValue.jsx"},{"name":"StatCard","sourcePath":"components/money/StatCard.jsx"},{"name":"PersonCard","sourcePath":"components/people/PersonCard.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"2cbc31b15b6b","components/core/Button.jsx":"21deac1195e5","components/core/SegmentedControl.jsx":"6c8369ca7e3e","components/money/DenomRow.jsx":"67526676472f","components/money/MoneyValue.jsx":"49e6d742e853","components/money/StatCard.jsx":"77a12d9ac44c","components/people/PersonCard.jsx":"81714643d083","redesign/app.jsx":"efe95ea4e0cb","redesign/billsheet.jsx":"b0cdd61bee0c","redesign/count.jsx":"e829da078b49","redesign/crew.jsx":"5e275ecb7255","redesign/home.jsx":"7299d3353c60","redesign/lib.jsx":"a0e3074beaa2","redesign/split.jsx":"f999b24f810e","redesign/tweaks-panel.jsx":"6591467622ed","ui_kits/tippool/CashScreen.jsx":"ebedeba85cad","ui_kits/tippool/HomeScreen.jsx":"8fd39eeab32a","ui_kits/tippool/StaffScreen.jsx":"3db4fe2f1b23","ui_kits/tippool/SummaryScreen.jsx":"ad3b8efe90d1","ui_kits/tippool/icons.jsx":"56eb76dbd70a","uploads/zet3-main (4)/js/calculator.js":"af569c25a1b0","uploads/zet3-main (4)/js/cards.js":"c55c87cf977c","uploads/zet3-main (4)/js/cash.js":"9d56d6029f1a","uploads/zet3-main (4)/js/cash_day.js":"8b3e8048afb5","uploads/zet3-main (4)/js/dist.js":"1a448041a1bd","uploads/zet3-main (4)/js/engine.js":"81ffbec68412","uploads/zet3-main (4)/js/engine.test.js":"9778d13cffc6","uploads/zet3-main (4)/js/engine_day.js":"5648fcc5247a","uploads/zet3-main (4)/js/engine_day.test.js":"da387274d3bb","uploads/zet3-main (4)/js/main.js":"3ab6dfbbe3c6","uploads/zet3-main (4)/js/modals.js":"72abd7be4e90","uploads/zet3-main (4)/js/persist.js":"84cf92501e96","uploads/zet3-main (4)/js/person.js":"3183afc2d5da","uploads/zet3-main (4)/js/remainder.js":"f32a5fc1022a","uploads/zet3-main (4)/js/shift.js":"c36ea48d6327","uploads/zet3-main (4)/js/staff.js":"a1e601e72875","uploads/zet3-main (4)/js/state.js":"336497d97fac","uploads/zet3-main (4)/js/summary.js":"3feabb8d2afb","uploads/zet3-main (4)/js/summary_day.js":"7b2feed0cf40","uploads/zet3-main (4)/js/support.js":"da8fc5f55932","uploads/zet3-main (4)/js/tabs.js":"9998edfa8ea4","uploads/zet3-main (4)/js/utils.js":"3b5fb9c9c033","uploads/zet3-main (4)/js/utils.test.js":"35c46908e23f"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.TipPoolDesignSystem_bcb6c4 = window.TipPoolDesignSystem_bcb6c4 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TipPool Badge — tiny uppercase mono labels. Covers role tags (bartender /
 * server / support), the closer marker, neutral tags, and the green bonus
 * pill. `pill` makes it fully rounded (used for "+$24" closer bonuses).
 */
function Badge({
  children,
  variant = 'neutral',
  pill = false,
  style = {},
  ...rest
}) {
  const variants = {
    neutral: {
      color: 'var(--muted)',
      borderColor: 'var(--border-2)',
      background: 'transparent'
    },
    bartender: {
      color: 'var(--role-bartender)',
      borderColor: 'var(--role-bartender-border)',
      background: 'var(--role-bartender-bg)'
    },
    server: {
      color: 'var(--role-server)',
      borderColor: 'var(--role-server-border)',
      background: 'var(--role-server-bg)'
    },
    support: {
      color: 'var(--role-support)',
      borderColor: 'var(--role-support-border)',
      background: 'var(--role-support-bg)'
    },
    closer: {
      color: 'var(--accent)',
      borderColor: 'var(--accent)',
      background: '#1a0608'
    },
    bonus: {
      color: 'var(--green)',
      borderColor: 'var(--green-border)',
      background: 'var(--green-bg)'
    }
  };
  const v = variants[variant] || variants.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-mono)',
      fontSize: '0.48rem',
      fontWeight: 700,
      letterSpacing: '0.7px',
      textTransform: 'uppercase',
      lineHeight: 1.4,
      padding: pill ? '1px 6px' : '1px 4px',
      borderRadius: pill ? 'var(--radius-pill)' : 'var(--radius-chip)',
      border: '1px solid',
      color: v.color,
      borderColor: v.borderColor,
      background: v.background,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TipPool Button — mono-label, uppercase, with a tactile press state.
 * Variants: accent (red, primary action), gold (money/confirm), secondary
 * (raised surface), ghost (bare), danger (destructive), dashed (add-row).
 */
function Button({
  children,
  variant = 'secondary',
  size = 'md',
  icon = null,
  disabled = false,
  fullWidth = false,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '7px 11px',
      fontSize: '0.6rem'
    },
    md: {
      padding: '9px 14px',
      fontSize: '0.7rem'
    },
    lg: {
      padding: '12px 18px',
      fontSize: '0.8rem'
    }
  };
  const variants = {
    accent: {
      background: 'var(--accent)',
      color: '#1a0608',
      border: '1px solid var(--accent)'
    },
    gold: {
      background: 'var(--gold)',
      color: '#1a1508',
      border: '1px solid var(--gold)'
    },
    secondary: {
      background: 'var(--surface-2)',
      color: 'var(--text)',
      border: '1px solid var(--border-2)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--muted)',
      border: '1px solid transparent'
    },
    danger: {
      background: '#2a1018',
      color: 'var(--accent-2)',
      border: '1px solid var(--accent)'
    },
    dashed: {
      background: 'transparent',
      color: 'var(--muted)',
      border: '1px dashed var(--border-2)'
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    disabled: disabled,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '7px',
      width: fullWidth ? '100%' : 'auto',
      borderRadius: 'var(--radius-sm)',
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      letterSpacing: '0.6px',
      textTransform: 'uppercase',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.4 : 1,
      transition: 'filter var(--dur) var(--ease), transform var(--dur) var(--ease)',
      ...sizes[size],
      ...variants[variant],
      ...style
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = 'scale(0.97)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = 'scale(1)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
    }
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      width: 14,
      height: 14
    }
  }, icon) : null, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/SegmentedControl.jsx
try { (() => {
/**
 * TipPool SegmentedControl — the toggle pattern used for shift mode, staff
 * role, and cash-entry mode. Options are uppercase mono labels; the active
 * segment lifts onto a raised surface with an optional accent color. An
 * optional `accentMap` tints the active label per option (e.g. role colors).
 */
function SegmentedControl({
  options,
  value,
  onChange = () => {},
  accentMap = null,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      background: 'var(--surface-2)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-sm)',
      padding: '3px',
      gap: '3px',
      ...style
    }
  }, options.map(opt => {
    const val = typeof opt === 'string' ? opt : opt.value;
    const label = typeof opt === 'string' ? opt : opt.label;
    const active = val === value;
    const accent = accentMap && accentMap[val];
    return /*#__PURE__*/React.createElement("button", {
      key: val,
      onClick: () => onChange(val),
      style: {
        flex: 1,
        background: active ? 'var(--surface-3)' : 'none',
        border: active ? '1px solid var(--border-2)' : '1px solid transparent',
        borderColor: active && accent ? accent.border : active ? 'var(--border-2)' : 'transparent',
        color: active ? accent ? accent.color : 'var(--text)' : 'var(--muted)',
        padding: '8px 6px',
        borderRadius: '7px',
        cursor: 'pointer',
        fontSize: '0.64rem',
        fontWeight: 700,
        letterSpacing: '0.6px',
        textTransform: 'uppercase',
        fontFamily: 'var(--font-mono)',
        transition: 'all var(--dur) var(--ease)'
      }
    }, label);
  }));
}
Object.assign(__ds_scope, { SegmentedControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SegmentedControl.jsx", error: String((e && e.message) || e) }); }

// components/money/DenomRow.jsx
try { (() => {
/**
 * TipPool DenomRow — a single denomination row from the cash-entry screen.
 * A gold denomination label on a raised cap, a big centered count input, and
 * a right-aligned subtotal cap. Focus tints the border gold. Used stacked in
 * the per-bill cash counter.
 */
function DenomRow({
  denom,
  count = '',
  subtotal = null,
  onCountChange = () => {},
  style = {}
}) {
  const isZero = !count || Number(count) === 0;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      overflow: 'hidden',
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-sm)',
      transition: 'border-color var(--dur) var(--ease)',
      ...style
    },
    onFocus: e => {
      e.currentTarget.style.borderColor = 'var(--gold-dim)';
    },
    onBlur: e => {
      e.currentTarget.style.borderColor = 'var(--border)';
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '50px',
      flexShrink: 0,
      textAlign: 'center',
      fontFamily: 'var(--font-mono)',
      fontSize: '0.92rem',
      fontWeight: 800,
      color: 'var(--gold)',
      borderRight: '1px solid var(--border)',
      padding: '11px 6px',
      background: 'var(--surface-2)'
    }
  }, "$", denom), /*#__PURE__*/React.createElement("input", {
    type: "number",
    inputMode: "numeric",
    min: "0",
    step: "1",
    placeholder: "0",
    value: count,
    onChange: e => onCountChange(e.target.value),
    style: {
      flex: 1,
      background: 'transparent',
      border: 'none',
      color: 'var(--text)',
      textAlign: 'center',
      padding: '11px 8px',
      fontSize: '1.35rem',
      fontWeight: 700,
      outline: 'none',
      fontFamily: 'var(--font-mono)',
      minWidth: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      width: '62px',
      flexShrink: 0,
      textAlign: 'right',
      padding: '11px 10px',
      fontFamily: 'var(--font-mono)',
      fontSize: '0.8rem',
      fontWeight: 700,
      color: isZero ? 'var(--muted-2)' : 'var(--text-2)',
      borderLeft: '1px solid var(--border)',
      background: 'var(--surface-2)'
    }
  }, subtotal == null ? '—' : isZero ? '—' : subtotal));
}
Object.assign(__ds_scope, { DenomRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/money/DenomRow.jsx", error: String((e && e.message) || e) }); }

// components/money/MoneyValue.jsx
try { (() => {
/**
 * TipPool MoneyValue — the canonical way to show a dollar figure: mono,
 * tabular, gold, with an optional uppercase eyebrow above it. Zero amounts
 * render muted. `size` maps onto the type scale.
 */
function MoneyValue({
  amount,
  label = null,
  size = 'xl',
  bright = false,
  style = {}
}) {
  const sizes = {
    sm: '0.84rem',
    md: '1.05rem',
    lg: '1.22rem',
    xl: '1.4rem',
    '2xl': '1.65rem',
    hero: '2.5rem'
  };
  const isZero = !amount || Number(amount) === 0;
  const formatted = typeof amount === 'number' ? '$' + amount.toLocaleString('en-US') : amount;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.5rem',
      fontWeight: 700,
      letterSpacing: '1.4px',
      textTransform: 'uppercase',
      color: 'var(--muted)',
      marginBottom: '5px'
    }
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: sizes[size],
      fontWeight: 800,
      lineHeight: 1,
      fontVariantNumeric: 'tabular-nums',
      color: isZero ? 'var(--muted-2)' : bright ? 'var(--gold-2)' : 'var(--gold)'
    }
  }, formatted));
}
Object.assign(__ds_scope, { MoneyValue });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/money/MoneyValue.jsx", error: String((e && e.message) || e) }); }

// components/money/StatCard.jsx
try { (() => {
/**
 * TipPool StatCard — the tappable metric tile from the home dashboard
 * ("Cash on Hand", "Staff"). Card surface with the signature top-left sheen,
 * an uppercase eyebrow, a big value, and a small sub-line. A `›` chevron in
 * the corner signals it navigates. `tone` colors the value (gold for money,
 * text for counts).
 */
function StatCard({
  label,
  value,
  sub = null,
  tone = 'money',
  onClick = null,
  style = {}
}) {
  const valueColor = tone === 'money' ? 'var(--gold)' : 'var(--text)';
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    style: {
      position: 'relative',
      overflow: 'hidden',
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius)',
      padding: '10px 12px',
      minHeight: '68px',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      cursor: onClick ? 'pointer' : 'default',
      transition: 'border-color var(--dur) var(--ease), background var(--dur) var(--ease)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--sheen)',
      pointerEvents: 'none'
    }
  }), onClick ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 7,
      right: 9,
      fontSize: '0.65rem',
      color: 'var(--accent)',
      fontWeight: 700
    }
  }, "\u203A") : null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.5rem',
      fontWeight: 700,
      letterSpacing: '1.4px',
      textTransform: 'uppercase',
      color: 'var(--muted)',
      marginBottom: '3px'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '1.4rem',
      fontWeight: 800,
      lineHeight: 1,
      color: valueColor,
      fontVariantNumeric: 'tabular-nums'
    }
  }, value), sub ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.58rem',
      color: 'var(--muted)',
      marginTop: '2px'
    }
  }, sub) : null);
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/money/StatCard.jsx", error: String((e && e.message) || e) }); }

// components/people/PersonCard.jsx
try { (() => {
/**
 * TipPool PersonCard — a per-person payout row from the Summary tab. Avatar
 * with initials, name + optional closer badge, an hours block (gold-2 value
 * over the in/out times), and the payout column (gold) with a base/bonus
 * sub-line. Tapping opens the person profile (pass onClick).
 */
function initials(name) {
  return (name || '?').trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase();
}
function PersonCard({
  name,
  hours,
  inTime = null,
  outTime = null,
  payout,
  basePay = null,
  bonus = null,
  isCloser = false,
  onClick = null,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    style: {
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-sm)',
      overflow: 'hidden',
      cursor: onClick ? 'pointer' : 'default',
      transition: 'border-color var(--dur) var(--ease), background var(--dur) var(--ease)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '9px',
      padding: '10px 11px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 28,
      height: 28,
      borderRadius: '50%',
      background: 'var(--surface-3)',
      border: '1px solid var(--border-2)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '0.62rem',
      fontWeight: 700,
      color: 'var(--text-2)',
      flexShrink: 0,
      fontFamily: 'var(--font-mono)'
    }
  }, initials(name)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '5px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '1rem',
      fontWeight: 800,
      color: 'var(--text)',
      fontFamily: 'var(--font-sans)'
    }
  }, name), isCloser ? /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    variant: "closer"
  }, "Closer") : null)), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right',
      flexShrink: 0,
      width: 74,
      fontVariantNumeric: 'tabular-nums'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '1.05rem',
      fontWeight: 800,
      color: 'var(--gold-2)',
      fontFamily: 'var(--font-mono)',
      lineHeight: 1
    }
  }, hours, "h"), inTime && outTime ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.54rem',
      color: 'var(--text-2)',
      fontFamily: 'var(--font-mono)',
      marginTop: '2px',
      whiteSpace: 'nowrap'
    }
  }, inTime, "\u2013", outTime) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right',
      flexShrink: 0,
      width: 62,
      fontVariantNumeric: 'tabular-nums'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '1.22rem',
      fontWeight: 800,
      color: 'var(--gold)',
      fontFamily: 'var(--font-mono)',
      lineHeight: 1
    }
  }, "$", payout), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'flex-end',
      gap: '4px',
      marginTop: '2px',
      minHeight: 14
    }
  }, bonus ? /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    variant: "bonus",
    pill: true
  }, "+$", bonus) : basePay != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.58rem',
      color: 'var(--muted-2)',
      fontFamily: 'var(--font-mono)'
    }
  }, "$", basePay) : null))));
}
Object.assign(__ds_scope, { PersonCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/people/PersonCard.jsx", error: String((e && e.message) || e) }); }

// redesign/app.jsx
try { (() => {
// app.jsx — shell: header, navigation models (tabs / hybrid / flow), the four
// screens, the unified BillSheet, and the Tweaks panel. Reads design tokens
// via ../styles.css and DS components via the bundle.

const {
  useState,
  useMemo
} = React;
const Icons = window.TipPoolIcons;
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "navModel": "hybrid",
  "homeLayout": "command",
  "density": "regular",
  "tabBar": "labeled",
  "vibe": "safe",
  "accent": "#e94560"
} /*EDITMODE-END*/;
const SEED_STAFF = [{
  id: 1,
  name: 'Maya Rodriguez',
  role: 'bartender',
  in: '5:00',
  out: '2:00',
  isCloser: true
}, {
  id: 2,
  name: 'Devon Clarke',
  role: 'bartender',
  in: '6:00',
  out: '12:00',
  isCloser: false
}, {
  id: 3,
  name: 'Sam Okafor',
  role: 'server',
  in: '5:30',
  out: '12:45',
  isCloser: false
}, {
  id: 4,
  name: 'Priya Anand',
  role: 'server',
  in: '6:00',
  out: '1:30',
  isCloser: false
}, {
  id: 5,
  name: 'Theo Brandt',
  role: 'support',
  in: '7:00',
  out: '1:00',
  isCloser: false
}];
const SEED_DAYPOOLS = [{
  id: 'a',
  name: 'Bar',
  crew: 2,
  total: '640'
}, {
  id: 'b',
  name: 'Patio',
  crew: 3,
  total: '480'
}];
const TABS = [{
  id: 'home',
  label: 'Home',
  icon: 'home'
}, {
  id: 'count',
  label: 'Count',
  icon: 'cash'
}, {
  id: 'crew',
  label: 'Crew',
  icon: 'staff'
}, {
  id: 'split',
  label: 'Split',
  icon: 'summary'
}];
const STEPS = ['count', 'crew', 'split'];
function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [tab, setTab] = useState('home');
  const [shift, setShift] = useState('night');
  const [mode, setMode] = useState('perbill');
  const [netTotal, setNetTotal] = useState('1284');
  const [bills, setBills] = useState({
    100: 6,
    50: 4,
    20: 14,
    10: 8,
    5: 12,
    1: 24
  });
  const [staff, setStaff] = useState(SEED_STAFF);
  const [dayPools, setDayPools] = useState(SEED_DAYPOOLS);
  const [crewRole, setCrewRole] = useState('bartender');
  const [menu, setMenu] = useState(false);
  const [sheet, setSheet] = useState({
    kind: null,
    payload: {},
    seq: 0
  });
  const {
    fmtMoney,
    billsTotal,
    billsCount,
    idealBreakdown,
    splitPool
  } = window.TP;
  const cashTotal = shift === 'day' ? dayPools.reduce((s, p) => s + (Number(p.total) || 0), 0) : mode === 'nettotal' ? Number(netTotal) || 0 : billsTotal(bills);
  const billCount = mode === 'perbill' ? billsCount(bills) : 0;
  const split = useMemo(() => splitPool(cashTotal, staff), [cashTotal, staff]);
  const effectiveBills = mode === 'perbill' ? bills : idealBreakdown(cashTotal);
  function openSheet(kind, payload = {}) {
    if (kind === 'exchange') {
      const {
        exchangeSuggestion,
        distribute
      } = window.TP;
      const d = distribute(split.rows, effectiveBills);
      payload = exchangeSuggestion(d.leftover);
    }
    if (kind === 'closetime') payload = {
      bills: effectiveBills
    };
    setSheet(s => ({
      kind,
      payload,
      seq: s.seq + 1
    }));
  }
  function closeSheet() {
    setSheet(s => ({
      ...s,
      kind: null
    }));
  }
  function newSession() {
    setStaff([]);
    setBills({});
    setNetTotal('');
    setDayPools(SEED_DAYPOOLS.map(p => ({
      ...p,
      total: ''
    })));
    setMenu(false);
    setTab('home');
  }
  const stepIdx = STEPS.indexOf(tab);
  const showTabBar = t.navModel === 'tabs' || t.navModel === 'hybrid';
  const showProgress = t.navModel === 'hybrid' || t.navModel === 'flow';
  const showFlowNav = t.navModel === 'flow';

  // progress completion
  const earners = staff.filter(s => s.role !== 'support' && (s.name || '').trim()).length;
  const done = {
    count: cashTotal > 0,
    crew: earners > 0,
    split: cashTotal > 0 && earners > 0
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "app",
    "data-vibe": t.vibe,
    "data-density": t.density,
    "data-tabbar": t.tabBar,
    "data-nav": t.navModel,
    style: {
      '--accent': t.accent
    },
    onClick: () => menu && setMenu(false)
  }, /*#__PURE__*/React.createElement("div", {
    className: "hdr"
  }, /*#__PURE__*/React.createElement("button", {
    className: "hdr-mark",
    onClick: () => setTab('home')
  }, "TIP ", /*#__PURE__*/React.createElement("span", null, "POOL")), /*#__PURE__*/React.createElement("div", {
    className: "hdr-right",
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("span", {
    className: "hdr-date"
  }, "Fri \xB7 Jun 6"), /*#__PURE__*/React.createElement("button", {
    className: "hdr-btn",
    onClick: () => setMenu(!menu)
  }, "\u22EF"), menu ? /*#__PURE__*/React.createElement("div", {
    className: "session-menu"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setMenu(false)
  }, "Save session"), /*#__PURE__*/React.createElement("button", {
    onClick: () => setMenu(false)
  }, "History"), /*#__PURE__*/React.createElement("button", {
    className: "danger",
    onClick: newSession
  }, "New session")) : null)), showProgress ? /*#__PURE__*/React.createElement("div", {
    className: "progress-strip"
  }, STEPS.map((s, i) => /*#__PURE__*/React.createElement("button", {
    key: s,
    className: 'ps-step' + (tab === s ? ' current' : '') + (done[s] ? ' done' : ''),
    onClick: () => setTab(s)
  }, /*#__PURE__*/React.createElement("span", {
    className: "ps-dot"
  }, done[s] ? '✓' : i + 1), /*#__PURE__*/React.createElement("span", {
    className: "ps-label"
  }, s), i < STEPS.length - 1 ? /*#__PURE__*/React.createElement("span", {
    className: "ps-line"
  }) : null))) : null, /*#__PURE__*/React.createElement("div", {
    className: "content"
  }, tab === 'home' && /*#__PURE__*/React.createElement(window.RDHomeScreen, {
    layout: t.homeLayout,
    shift: shift,
    date: "Fri, Jun 6",
    cashTotal: cashTotal,
    billCount: billCount,
    staff: staff,
    split: split,
    onGo: setTab,
    onSheet: openSheet
  }), tab === 'count' && /*#__PURE__*/React.createElement(window.CountScreen, {
    shift: shift,
    setShift: setShift,
    mode: mode,
    setMode: setMode,
    bills: bills,
    setBills: setBills,
    netTotal: netTotal,
    setNetTotal: setNetTotal,
    dayPools: dayPools,
    setDayPools: setDayPools,
    onSheet: openSheet
  }), tab === 'crew' && /*#__PURE__*/React.createElement(window.CrewScreen, {
    role: crewRole,
    setRole: setCrewRole,
    staff: staff,
    setStaff: setStaff
  }), tab === 'split' && /*#__PURE__*/React.createElement(window.SplitScreen, {
    pool: cashTotal,
    staff: staff,
    effectiveBills: effectiveBills,
    split: split,
    onSheet: openSheet,
    onGo: setTab
  })), showFlowNav ? /*#__PURE__*/React.createElement("div", {
    className: "flow-nav"
  }, /*#__PURE__*/React.createElement("button", {
    className: "flow-back",
    disabled: stepIdx <= 0,
    onClick: () => stepIdx > 0 && setTab(STEPS[stepIdx - 1])
  }, "\u2039 Back"), stepIdx < STEPS.length - 1 ? /*#__PURE__*/React.createElement("button", {
    className: "flow-next",
    onClick: () => setTab(STEPS[Math.max(0, stepIdx) + 1] || 'split')
  }, stepIdx < 0 ? 'Start counting' : 'Next', " \u203A") : /*#__PURE__*/React.createElement("button", {
    className: "flow-next gold",
    onClick: () => openSheet('dist', distPayload(split, effectiveBills))
  }, "Hand out \u2192")) : null, showTabBar ? /*#__PURE__*/React.createElement("div", {
    className: "tab-bar"
  }, TABS.map(tb => {
    const TIcon = Icons[tb.icon];
    const active = tb.id === tab;
    let sub = '',
      cls = '';
    if (tb.id === 'count') {
      sub = cashTotal ? fmtMoney(cashTotal) : '—';
      cls = cashTotal ? 'gold' : '';
    }
    if (tb.id === 'crew') {
      sub = earners ? earners + '' : '—';
      cls = earners ? 'blue' : '';
    }
    if (tb.id === 'split') {
      sub = done.split ? fmtMoney(split.perHead) : '—';
      cls = done.split ? 'gold' : '';
    }
    return /*#__PURE__*/React.createElement("button", {
      key: tb.id,
      className: 'tab-btn' + (active ? ' active' : ''),
      onClick: () => setTab(tb.id)
    }, /*#__PURE__*/React.createElement("span", {
      className: "tab-ico-wrap"
    }, /*#__PURE__*/React.createElement(TIcon, {
      size: 19
    }), tb.id === 'count' && cashTotal || tb.id === 'crew' && earners ? /*#__PURE__*/React.createElement("span", {
      className: "tab-dot"
    }) : null), /*#__PURE__*/React.createElement("span", {
      className: "tab-label"
    }, tb.label), sub ? /*#__PURE__*/React.createElement("span", {
      className: 'tab-sub ' + cls
    }, sub) : /*#__PURE__*/React.createElement("span", {
      className: "tab-sub"
    }));
  })) : null, /*#__PURE__*/React.createElement(window.BillSheet, {
    key: sheet.seq,
    kind: sheet.kind,
    payload: sheet.payload,
    open: !!sheet.kind,
    onClose: closeSheet
  }), /*#__PURE__*/React.createElement(TweaksPanel, null, /*#__PURE__*/React.createElement(TweakSection, {
    label: "Navigation"
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Model",
    value: t.navModel,
    options: [{
      value: 'tabs',
      label: 'Tabs'
    }, {
      value: 'hybrid',
      label: 'Hybrid'
    }, {
      value: 'flow',
      label: 'Wizard'
    }],
    onChange: v => setTweak('navModel', v)
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Tab bar",
    value: t.tabBar,
    options: [{
      value: 'labeled',
      label: 'Labeled'
    }, {
      value: 'minimal',
      label: 'Minimal'
    }, {
      value: 'pill',
      label: 'Pill'
    }],
    onChange: v => setTweak('tabBar', v)
  }), /*#__PURE__*/React.createElement(TweakSection, {
    label: "Home"
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Layout",
    value: t.homeLayout,
    options: [{
      value: 'command',
      label: 'Command'
    }, {
      value: 'receipt',
      label: 'Receipt'
    }, {
      value: 'ledger',
      label: 'Ledger'
    }],
    onChange: v => setTweak('homeLayout', v)
  }), /*#__PURE__*/React.createElement(TweakSection, {
    label: "Feel"
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Density",
    value: t.density,
    options: [{
      value: 'compact',
      label: 'Compact'
    }, {
      value: 'regular',
      label: 'Regular'
    }, {
      value: 'roomy',
      label: 'Roomy'
    }],
    onChange: v => setTweak('density', v)
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Visual",
    value: t.vibe,
    options: [{
      value: 'safe',
      label: 'Refined'
    }, {
      value: 'bold',
      label: 'Bold'
    }],
    onChange: v => setTweak('vibe', v)
  }), /*#__PURE__*/React.createElement(TweakColor, {
    label: "Accent",
    value: t.accent,
    options: ['#e94560', '#f5c842', '#4a9eff', '#2ecc71', '#9d7dca'],
    onChange: v => setTweak('accent', v)
  })));
}
function distPayload(split, bills) {
  const d = window.TP.distribute(split.rows, bills);
  return {
    people: d.people,
    leftover: d.leftover,
    leftoverTotal: d.leftoverTotal,
    start: 0
  };
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "redesign/app.jsx", error: String((e && e.message) || e) }); }

// redesign/billsheet.jsx
try { (() => {
// BillSheet.jsx — ONE unified bottom-sheet "ledger tape" used for every bill
// operation: close-time pull, remainder allocation, bill exchange, and the
// per-person distribution table. Same chrome everywhere → one mental model.

const {
  useEffect: useSheetEffect
} = React;

// --- Bottom-sheet shell (scrim + slide-up sheet) ---------------------------
function Sheet({
  open,
  onClose,
  children,
  tone = 'gold'
}) {
  useSheetEffect(() => {
    function onKey(e) {
      if (e.key === 'Escape') onClose();
    }
    if (open) window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  return /*#__PURE__*/React.createElement("div", {
    className: 'sheet-scrim' + (open ? ' open' : ''),
    onClick: e => {
      if (e.target === e.currentTarget) onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: 'sheet' + (open ? ' open' : ''),
    "data-tone": tone,
    onClick: e => e.stopPropagation()
  }, children));
}

// --- The ledger table: the shared register-tape rows -----------------------
// rows: [{ label, count, value, tone }]  tone: 'money' | 'plus' | 'minus' | null
function Ledger({
  rows,
  head = ['Denom', 'Count', 'Value']
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ledger"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ledger-head"
  }, /*#__PURE__*/React.createElement("span", null, head[0]), /*#__PURE__*/React.createElement("span", null, head[1]), /*#__PURE__*/React.createElement("span", null, head[2])), /*#__PURE__*/React.createElement("div", {
    className: "ledger-perf"
  }), rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    className: "ledger-row",
    key: i,
    "data-tone": r.tone || ''
  }, /*#__PURE__*/React.createElement("span", {
    className: "lr-label"
  }, r.label), /*#__PURE__*/React.createElement("span", {
    className: "lr-count"
  }, r.count), /*#__PURE__*/React.createElement("span", {
    className: "lr-value"
  }, r.value))));
}

// --- Header / footer atoms --------------------------------------------------
function SheetHead({
  title,
  subtitle,
  onClose
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "sheet-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sheet-drag"
  }), /*#__PURE__*/React.createElement("div", {
    className: "sheet-title-row"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "sheet-title"
  }, title), subtitle ? /*#__PURE__*/React.createElement("div", {
    className: "sheet-sub"
  }, subtitle) : null), /*#__PURE__*/React.createElement("button", {
    className: "sheet-x",
    onClick: onClose
  }, "\u2715")));
}

// === The router: one component, four shapes ================================
function BillSheet({
  kind,
  payload,
  open,
  onClose
}) {
  const {
    fmtMoney
  } = window.TP;
  const DEN = window.CASH_DENOMS;
  const [who, setWho] = React.useState(payload && payload.start || 0);
  if (!kind) return /*#__PURE__*/React.createElement(Sheet, {
    open: open,
    onClose: onClose
  }, null);

  // ---- CLOSE-TIME PULL ----------------------------------------------------
  if (kind === 'closetime') {
    const bills = payload.bills || {};
    const rows = DEN.filter(d => bills[d]).map(d => ({
      label: '$' + d,
      count: '×' + bills[d],
      value: fmtMoney(d * bills[d]),
      tone: 'money'
    }));
    const total = DEN.reduce((s, d) => s + d * (bills[d] || 0), 0);
    return /*#__PURE__*/React.createElement(Sheet, {
      open: open,
      onClose: onClose,
      tone: "accent"
    }, /*#__PURE__*/React.createElement(SheetHead, {
      title: "Close-Time Pull",
      subtitle: "Bills counted out of the drawer at close",
      onClose: onClose
    }), /*#__PURE__*/React.createElement("div", {
      className: "sheet-body"
    }, /*#__PURE__*/React.createElement(Ledger, {
      rows: rows.length ? rows : [{
        label: '—',
        count: '',
        value: 'no bills',
        tone: ''
      }]
    }), /*#__PURE__*/React.createElement("div", {
      className: "ledger-total"
    }, /*#__PURE__*/React.createElement("span", null, "Pulled"), /*#__PURE__*/React.createElement("span", {
      className: "lt-val"
    }, fmtMoney(total))), /*#__PURE__*/React.createElement("button", {
      className: "sheet-cta accent",
      onClick: onClose
    }, "Confirm pull")));
  }

  // ---- REMAINDER ALLOCATION ----------------------------------------------
  if (kind === 'remainder') {
    const {
      amount = 0,
      leftover = {},
      closer
    } = payload;
    const rows = DEN.filter(d => leftover[d]).map(d => ({
      label: '$' + d,
      count: '×' + leftover[d],
      value: fmtMoney(d * leftover[d]),
      tone: 'money'
    }));
    return /*#__PURE__*/React.createElement(Sheet, {
      open: open,
      onClose: onClose,
      tone: "gold"
    }, /*#__PURE__*/React.createElement(SheetHead, {
      title: "Remainder",
      subtitle: "Cash that didn't divide evenly",
      onClose: onClose
    }), /*#__PURE__*/React.createElement("div", {
      className: "sheet-body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "rem-figure"
    }, fmtMoney(amount)), /*#__PURE__*/React.createElement(Ledger, {
      rows: rows.length ? rows : [{
        label: '$1',
        count: '×' + amount,
        value: fmtMoney(amount),
        tone: 'money'
      }]
    }), /*#__PURE__*/React.createElement("div", {
      className: "rem-choices"
    }, /*#__PURE__*/React.createElement("div", {
      className: "rem-choice active"
    }, "To closer", closer ? ' · ' + closer : ''), /*#__PURE__*/React.createElement("div", {
      className: "rem-choice"
    }, "Split evenly"), /*#__PURE__*/React.createElement("div", {
      className: "rem-choice"
    }, "Hold for tomorrow")), /*#__PURE__*/React.createElement("button", {
      className: "sheet-cta gold",
      onClick: onClose
    }, "Allocate ", fmtMoney(amount))));
  }

  // ---- BILL EXCHANGE ------------------------------------------------------
  if (kind === 'exchange') {
    const {
      give = [],
      get = []
    } = payload;
    const giveRows = give.map(g => ({
      label: '$' + g.denom,
      count: '×' + g.count,
      value: fmtMoney(g.denom * g.count),
      tone: 'minus'
    }));
    const getRows = get.map(g => ({
      label: '$' + g.denom,
      count: '×' + g.count,
      value: fmtMoney(g.denom * g.count),
      tone: 'plus'
    }));
    return /*#__PURE__*/React.createElement(Sheet, {
      open: open,
      onClose: onClose,
      tone: "blue"
    }, /*#__PURE__*/React.createElement(SheetHead, {
      title: "Bill Exchange",
      subtitle: "Break big bills so the pool divides clean",
      onClose: onClose
    }), /*#__PURE__*/React.createElement("div", {
      className: "sheet-body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "xch-block"
    }, /*#__PURE__*/React.createElement("div", {
      className: "xch-cap minus"
    }, "Give to drawer"), /*#__PURE__*/React.createElement(Ledger, {
      rows: giveRows.length ? giveRows : [{
        label: '—',
        count: '',
        value: 'nothing',
        tone: ''
      }],
      head: ['Denom', 'Count', 'Value']
    })), /*#__PURE__*/React.createElement("div", {
      className: "xch-arrow"
    }, "\u2193"), /*#__PURE__*/React.createElement("div", {
      className: "xch-block"
    }, /*#__PURE__*/React.createElement("div", {
      className: "xch-cap plus"
    }, "Take back"), /*#__PURE__*/React.createElement(Ledger, {
      rows: getRows.length ? getRows : [{
        label: '—',
        count: '',
        value: 'nothing',
        tone: ''
      }],
      head: ['Denom', 'Count', 'Value']
    })), /*#__PURE__*/React.createElement("button", {
      className: "sheet-cta blue",
      onClick: onClose
    }, "Mark exchanged")));
  }

  // ---- DISTRIBUTION (per-person handout) ----------------------------------
  if (kind === 'dist') {
    const {
      people = [],
      leftover = {},
      leftoverTotal = 0
    } = payload;
    const cur = people[who] || people[0];
    return /*#__PURE__*/React.createElement(Sheet, {
      open: open,
      onClose: onClose,
      tone: "gold"
    }, /*#__PURE__*/React.createElement(SheetHead, {
      title: "Hand Out",
      subtitle: "Exact bills to count into each hand",
      onClose: onClose
    }), /*#__PURE__*/React.createElement("div", {
      className: "sheet-body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "dist-people"
    }, people.map((p, i) => /*#__PURE__*/React.createElement("button", {
      key: p.id,
      className: 'dist-chip' + (i === who ? ' active' : ''),
      "data-role": p.role,
      onClick: () => setWho(i)
    }, /*#__PURE__*/React.createElement("span", {
      className: "dc-name"
    }, (p.name || '?').split(' ')[0]), /*#__PURE__*/React.createElement("span", {
      className: "dc-amt"
    }, fmtMoney(p.paid))))), cur ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Ledger, {
      rows: DEN.filter(d => cur.given[d]).map(d => ({
        label: '$' + d,
        count: '×' + cur.given[d],
        value: fmtMoney(d * cur.given[d]),
        tone: 'money'
      }))
    }), /*#__PURE__*/React.createElement("div", {
      className: "ledger-total"
    }, /*#__PURE__*/React.createElement("span", null, (cur.name || '').split(' ')[0], "'s cut"), /*#__PURE__*/React.createElement("span", {
      className: "lt-val"
    }, fmtMoney(cur.paid)))) : null, leftoverTotal > 0 ? /*#__PURE__*/React.createElement("div", {
      className: "dist-left"
    }, "Remainder after handout: ", /*#__PURE__*/React.createElement("strong", null, fmtMoney(leftoverTotal))) : null, /*#__PURE__*/React.createElement("button", {
      className: "sheet-cta gold",
      onClick: onClose
    }, "Mark all paid")));
  }
  return /*#__PURE__*/React.createElement(Sheet, {
    open: open,
    onClose: onClose
  }, null);
}
window.BillSheet = BillSheet;
window.TPSheet = {
  Sheet,
  Ledger,
  SheetHead
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "redesign/billsheet.jsx", error: String((e && e.message) || e) }); }

// redesign/count.jsx
try { (() => {
// CountScreen.jsx — count the drawer. Night = single pool (net-total OR
// per-bill). Day = simplified multi-pool list. Feeds the exchange sheet.

function CountScreen({
  shift,
  setShift,
  mode,
  setMode,
  bills,
  setBills,
  netTotal,
  setNetTotal,
  dayPools,
  setDayPools,
  onSheet
}) {
  const {
    SegmentedControl
  } = window.TipPoolDesignSystem_bcb6c4;
  const {
    DenomRow
  } = window.TipPoolDesignSystem_bcb6c4;
  const {
    fmtMoney,
    billsTotal,
    billsCount,
    idealBreakdown
  } = window.TP;
  const DEN = window.CASH_DENOMS;
  const billTotal = billsTotal(bills);
  const total = mode === 'nettotal' ? Number(netTotal) || 0 : billTotal;
  const ideal = idealBreakdown(netTotal);

  // ---------- DAY: simplified multi-pool ----------
  if (shift === 'day') {
    const dayTotal = dayPools.reduce((s, p) => s + (Number(p.total) || 0), 0);
    return /*#__PURE__*/React.createElement("div", {
      className: "screen count-screen"
    }, /*#__PURE__*/React.createElement(SegmentedControl, {
      options: [{
        value: 'night',
        label: 'Night'
      }, {
        value: 'day',
        label: 'Day'
      }],
      value: shift,
      onChange: setShift
    }), /*#__PURE__*/React.createElement("div", {
      className: "count-total-bar"
    }, /*#__PURE__*/React.createElement("span", {
      className: "ctb-label"
    }, "All pools"), /*#__PURE__*/React.createElement("span", {
      className: "ctb-val"
    }, dayTotal ? fmtMoney(dayTotal) : '—')), /*#__PURE__*/React.createElement("div", {
      className: "day-note"
    }, "Day shift runs separate pools. Count each one \u2014 they split independently."), /*#__PURE__*/React.createElement("div", {
      className: "pool-list"
    }, dayPools.map((p, i) => /*#__PURE__*/React.createElement("div", {
      className: "pool-card",
      key: p.id,
      "data-on": (Number(p.total) > 0).toString()
    }, /*#__PURE__*/React.createElement("div", {
      className: "pool-card-head"
    }, /*#__PURE__*/React.createElement("span", {
      className: "pool-name"
    }, p.name), /*#__PURE__*/React.createElement("span", {
      className: "pool-meta"
    }, p.crew, " crew")), /*#__PURE__*/React.createElement("div", {
      className: "pool-input-row"
    }, /*#__PURE__*/React.createElement("span", {
      className: "pool-dollar"
    }, "$"), /*#__PURE__*/React.createElement("input", {
      className: "pool-input",
      inputMode: "numeric",
      placeholder: "0",
      value: p.total,
      onChange: e => {
        const v = e.target.value;
        setDayPools(dayPools.map((x, j) => j === i ? {
          ...x,
          total: v
        } : x));
      }
    })))), /*#__PURE__*/React.createElement("button", {
      className: "add-pool",
      onClick: () => setDayPools([...dayPools, {
        id: Date.now(),
        name: 'Pool ' + (dayPools.length + 1),
        crew: 0,
        total: ''
      }])
    }, "+ Add pool")));
  }

  // ---------- NIGHT: single pool ----------
  return /*#__PURE__*/React.createElement("div", {
    className: "screen count-screen"
  }, /*#__PURE__*/React.createElement(SegmentedControl, {
    options: [{
      value: 'night',
      label: 'Night'
    }, {
      value: 'day',
      label: 'Day'
    }],
    value: shift,
    onChange: setShift
  }), /*#__PURE__*/React.createElement("div", {
    className: "count-hero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "count-hero-eyebrow"
  }, "Cash on hand"), /*#__PURE__*/React.createElement("div", {
    className: 'count-hero-val' + (total ? '' : ' muted')
  }, total ? fmtMoney(total) : '$0'), /*#__PURE__*/React.createElement("div", {
    className: "count-hero-sub"
  }, mode === 'perbill' ? billsCount(bills) + ' bills counted' : 'net total entered')), /*#__PURE__*/React.createElement(SegmentedControl, {
    options: [{
      value: 'nettotal',
      label: 'Net Total'
    }, {
      value: 'perbill',
      label: 'Count Bills'
    }],
    value: mode,
    onChange: setMode
  }), mode === 'nettotal' ? /*#__PURE__*/React.createElement("div", {
    className: "net-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "net-input-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "net-dollar"
  }, "$"), /*#__PURE__*/React.createElement("input", {
    className: "net-input",
    inputMode: "numeric",
    placeholder: "0",
    value: netTotal,
    onChange: e => setNetTotal(e.target.value),
    autoFocus: true
  })), /*#__PURE__*/React.createElement("div", {
    className: "net-ideal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "net-ideal-cap"
  }, "Ideal breakdown"), Number(netTotal) > 0 ? /*#__PURE__*/React.createElement("div", {
    className: "ideal-grid"
  }, DEN.filter(d => ideal[d]).map(d => /*#__PURE__*/React.createElement("div", {
    className: "ideal-chip",
    key: d
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic-denom"
  }, "$", d), /*#__PURE__*/React.createElement("span", {
    className: "ic-count"
  }, "\xD7", ideal[d])))) : /*#__PURE__*/React.createElement("div", {
    className: "net-ideal-empty"
  }, "Enter a total to see the cleanest bill split"))) : /*#__PURE__*/React.createElement("div", {
    className: "bills-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "denom-stack"
  }, DEN.map(d => /*#__PURE__*/React.createElement(DenomRow, {
    key: d,
    denom: d,
    count: bills[d] || '',
    subtotal: bills[d] ? fmtMoney(d * bills[d]) : null,
    onCountChange: v => setBills({
      ...bills,
      [d]: v
    })
  }))), /*#__PURE__*/React.createElement("div", {
    className: "bills-total-row"
  }, /*#__PURE__*/React.createElement("span", null, "Total"), /*#__PURE__*/React.createElement("span", {
    className: 'btr-val' + (billTotal ? '' : ' muted')
  }, fmtMoney(billTotal)))), /*#__PURE__*/React.createElement("button", {
    className: "ghost-action",
    onClick: () => onSheet('exchange')
  }, /*#__PURE__*/React.createElement("span", {
    className: "ga-ico"
  }, "\u21C4"), " Bill exchange"));
}
window.CountScreen = CountScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "redesign/count.jsx", error: String((e && e.message) || e) }); }

// redesign/crew.jsx
try { (() => {
// CrewScreen.jsx — the roster. Role-coded (bartender/server/support), inline
// editable names + shift times, closer toggle, live hours. Add/remove people.

function CrewScreen({
  role,
  setRole,
  staff,
  setStaff
}) {
  const {
    SegmentedControl
  } = window.TipPoolDesignSystem_bcb6c4;
  const {
    computeHours,
    fmtHours
  } = window.TP;
  const roleAccent = {
    bartender: {
      color: 'var(--role-bartender)',
      border: 'var(--role-bartender-border)'
    },
    server: {
      color: 'var(--role-server)',
      border: 'var(--role-server-border)'
    },
    support: {
      color: 'var(--role-support)',
      border: 'var(--role-support-border)'
    }
  };
  const list = staff.filter(s => s.role === role);
  const labels = {
    bartender: 'Bartender',
    server: 'Server',
    support: 'Support'
  };
  function update(id, patch) {
    setStaff(staff.map(s => s.id === id ? {
      ...s,
      ...patch
    } : s));
  }
  function remove(id) {
    setStaff(staff.filter(s => s.id !== id));
  }
  function add() {
    setStaff([...staff, {
      id: Date.now(),
      name: '',
      role,
      in: '',
      out: '',
      isCloser: false
    }]);
  }
  const initials = n => (n || '?').trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase() || '?';
  return /*#__PURE__*/React.createElement("div", {
    className: "screen crew-screen"
  }, /*#__PURE__*/React.createElement(SegmentedControl, {
    options: [{
      value: 'bartender',
      label: 'Bar'
    }, {
      value: 'server',
      label: 'Server'
    }, {
      value: 'support',
      label: 'Support'
    }],
    value: role,
    onChange: setRole,
    accentMap: roleAccent
  }), /*#__PURE__*/React.createElement("div", {
    className: "crew-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "crew-count"
  }, list.length, " ", labels[role].toLowerCase(), list.length === 1 ? '' : 's'), role === 'support' ? /*#__PURE__*/React.createElement("span", {
    className: "crew-note"
  }, "share hours \xB7 no direct tips") : /*#__PURE__*/React.createElement("span", {
    className: "crew-note"
  }, "split by hours worked")), /*#__PURE__*/React.createElement("div", {
    className: "crew-list"
  }, list.map(p => {
    const h = computeHours(p.in, p.out);
    return /*#__PURE__*/React.createElement("div", {
      className: "crew-row",
      key: p.id,
      "data-role": p.role,
      "data-closer": p.isCloser ? 'true' : 'false'
    }, /*#__PURE__*/React.createElement("div", {
      className: "crew-spine"
    }), /*#__PURE__*/React.createElement("div", {
      className: "crew-avatar"
    }, initials(p.name)), /*#__PURE__*/React.createElement("div", {
      className: "crew-body"
    }, /*#__PURE__*/React.createElement("input", {
      className: "crew-name",
      placeholder: "Name",
      value: p.name,
      onChange: e => update(p.id, {
        name: e.target.value
      })
    }), /*#__PURE__*/React.createElement("div", {
      className: "crew-times"
    }, /*#__PURE__*/React.createElement("input", {
      className: "crew-time",
      placeholder: "in",
      value: p.in,
      onChange: e => update(p.id, {
        in: e.target.value
      })
    }), /*#__PURE__*/React.createElement("span", {
      className: "crew-dash"
    }, "\u2013"), /*#__PURE__*/React.createElement("input", {
      className: "crew-time",
      placeholder: "out",
      value: p.out,
      onChange: e => update(p.id, {
        out: e.target.value
      })
    }), /*#__PURE__*/React.createElement("span", {
      className: "crew-hours"
    }, h ? fmtHours(h) : '—'))), /*#__PURE__*/React.createElement("div", {
      className: "crew-actions"
    }, role !== 'support' ? /*#__PURE__*/React.createElement("button", {
      className: 'closer-btn' + (p.isCloser ? ' on' : ''),
      title: "Closer",
      onClick: () => update(p.id, {
        isCloser: !p.isCloser
      })
    }, "\u2605") : null, /*#__PURE__*/React.createElement("button", {
      className: "crew-remove",
      title: "Remove",
      onClick: () => remove(p.id)
    }, "\u2715")));
  }), list.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "crew-empty"
  }, "No ", labels[role].toLowerCase(), "s yet") : null, /*#__PURE__*/React.createElement("button", {
    className: "add-btn",
    onClick: add
  }, "+ Add ", labels[role])));
}
window.CrewScreen = CrewScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "redesign/crew.jsx", error: String((e && e.message) || e) }); }

// redesign/home.jsx
try { (() => {
// HomeScreen.jsx — the "Tonight" command center. Three layouts (homeLayout
// tweak): 'command' (progress spine), 'receipt' (register tape), 'ledger'
// (dense dashboard). The hero moment is the per-head reveal.

function RDHomeScreen({
  layout = 'command',
  shift,
  date,
  cashTotal,
  billCount,
  staff,
  split,
  onGo,
  onSheet
}) {
  const {
    fmtMoney
  } = window.TP;
  const earners = staff.filter(s => s.role !== 'support' && (s.name || '').trim());
  const counted = cashTotal > 0;
  const crewed = earners.length > 0;
  const ready = counted && crewed;
  const Step = ({
    n,
    id,
    label,
    done,
    value,
    sub,
    active
  }) => /*#__PURE__*/React.createElement("button", {
    className: 'step-row' + (done ? ' done' : active ? ' active' : ''),
    onClick: () => onGo(id)
  }, /*#__PURE__*/React.createElement("span", {
    className: "step-dot"
  }, done ? '✓' : n), /*#__PURE__*/React.createElement("span", {
    className: "step-main"
  }, /*#__PURE__*/React.createElement("span", {
    className: "step-label"
  }, label), /*#__PURE__*/React.createElement("span", {
    className: "step-sub"
  }, sub)), /*#__PURE__*/React.createElement("span", {
    className: "step-val"
  }, value), /*#__PURE__*/React.createElement("span", {
    className: "step-chev"
  }, "\u203A"));

  // ---------- COMMAND ----------
  if (layout === 'command') {
    return /*#__PURE__*/React.createElement("div", {
      className: "screen home-command"
    }, /*#__PURE__*/React.createElement("div", {
      className: "tonight-head"
    }, /*#__PURE__*/React.createElement("div", {
      className: "tonight-eyebrow"
    }, "Tonight"), /*#__PURE__*/React.createElement("div", {
      className: "tonight-date"
    }, date, " \xB7 ", shift === 'night' ? 'Night' : 'Day', " shift")), /*#__PURE__*/React.createElement("div", {
      className: 'hero-card' + (ready ? ' ready' : '')
    }, /*#__PURE__*/React.createElement("div", {
      className: "hero-sheen"
    }), ready ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: "hero-eyebrow"
    }, "Per head"), /*#__PURE__*/React.createElement("div", {
      className: "hero-figure"
    }, fmtMoney(split.perHead)), /*#__PURE__*/React.createElement("div", {
      className: "hero-sub"
    }, fmtMoney(cashTotal), " pool \xB7 ", earners.length, " earners"), /*#__PURE__*/React.createElement("button", {
      className: "hero-cta",
      onClick: () => onGo('split')
    }, "See the split \u203A")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: "hero-eyebrow"
    }, "Pool"), /*#__PURE__*/React.createElement("div", {
      className: "hero-figure muted"
    }, counted ? fmtMoney(cashTotal) : '—'), /*#__PURE__*/React.createElement("div", {
      className: "hero-sub"
    }, counted ? 'Add your crew to split it' : 'Count the drawer to begin'), /*#__PURE__*/React.createElement("button", {
      className: "hero-cta",
      onClick: () => onGo(counted ? 'crew' : 'count')
    }, counted ? 'Add crew ›' : 'Count cash ›'))), /*#__PURE__*/React.createElement("div", {
      className: "step-spine"
    }, /*#__PURE__*/React.createElement(Step, {
      n: "1",
      id: "count",
      label: "Count",
      sub: billCount ? billCount + ' bills' : 'cash on hand',
      done: counted,
      active: !counted,
      value: counted ? fmtMoney(cashTotal) : '—'
    }), /*#__PURE__*/React.createElement(Step, {
      n: "2",
      id: "crew",
      label: "Crew",
      sub: crewed ? earners.length + ' on the floor' : 'who worked',
      done: crewed,
      active: counted && !crewed,
      value: crewed ? earners.length : '—'
    }), /*#__PURE__*/React.createElement(Step, {
      n: "3",
      id: "split",
      label: "Split",
      sub: ready ? 'ready to pay out' : 'payout & handout',
      done: ready,
      active: ready,
      value: ready ? fmtMoney(split.perHead) + '/ea' : '—'
    })), /*#__PURE__*/React.createElement("button", {
      className: "ghost-action",
      onClick: () => onSheet('closetime')
    }, /*#__PURE__*/React.createElement("span", {
      className: "ga-ico"
    }, "\u2298"), " Close-time bills"));
  }

  // ---------- RECEIPT ----------
  if (layout === 'receipt') {
    return /*#__PURE__*/React.createElement("div", {
      className: "screen home-receipt"
    }, /*#__PURE__*/React.createElement("div", {
      className: "receipt"
    }, /*#__PURE__*/React.createElement("div", {
      className: "receipt-perf top"
    }), /*#__PURE__*/React.createElement("div", {
      className: "receipt-mark"
    }, "TIP ", /*#__PURE__*/React.createElement("span", null, "POOL")), /*#__PURE__*/React.createElement("div", {
      className: "receipt-meta"
    }, date, " \u2014 ", shift === 'night' ? 'NIGHT' : 'DAY', " SHIFT"), /*#__PURE__*/React.createElement("div", {
      className: "receipt-rule"
    }), /*#__PURE__*/React.createElement("div", {
      className: "receipt-line"
    }, /*#__PURE__*/React.createElement("span", null, "POOL"), /*#__PURE__*/React.createElement("span", {
      className: "dots"
    }), /*#__PURE__*/React.createElement("span", {
      className: "rc-val"
    }, counted ? fmtMoney(cashTotal) : '—')), /*#__PURE__*/React.createElement("div", {
      className: "receipt-line"
    }, /*#__PURE__*/React.createElement("span", null, "EARNERS"), /*#__PURE__*/React.createElement("span", {
      className: "dots"
    }), /*#__PURE__*/React.createElement("span", {
      className: "rc-val plain"
    }, crewed ? earners.length : '—')), /*#__PURE__*/React.createElement("div", {
      className: "receipt-line"
    }, /*#__PURE__*/React.createElement("span", null, "BILLS"), /*#__PURE__*/React.createElement("span", {
      className: "dots"
    }), /*#__PURE__*/React.createElement("span", {
      className: "rc-val plain"
    }, billCount || '—')), /*#__PURE__*/React.createElement("div", {
      className: "receipt-rule"
    }), /*#__PURE__*/React.createElement("div", {
      className: "receipt-total"
    }, /*#__PURE__*/React.createElement("div", {
      className: "rt-label"
    }, "PER HEAD"), /*#__PURE__*/React.createElement("div", {
      className: "rt-figure"
    }, ready ? fmtMoney(split.perHead) : '—')), /*#__PURE__*/React.createElement("div", {
      className: "receipt-perf bottom"
    })), /*#__PURE__*/React.createElement("button", {
      className: "receipt-cta",
      onClick: () => onGo(ready ? 'split' : counted ? 'crew' : 'count')
    }, ready ? 'View split' : counted ? 'Add crew' : 'Count cash', " \u2192"));
  }

  // ---------- LEDGER ----------
  const rows = split.rows.slice(0, 4);
  return /*#__PURE__*/React.createElement("div", {
    className: "screen home-ledger"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ledger-tiles"
  }, /*#__PURE__*/React.createElement("button", {
    className: "ltile",
    onClick: () => onGo('count')
  }, /*#__PURE__*/React.createElement("span", {
    className: "lt-eyebrow"
  }, "Cash on hand"), /*#__PURE__*/React.createElement("span", {
    className: "lt-figure gold"
  }, counted ? fmtMoney(cashTotal) : '—'), /*#__PURE__*/React.createElement("span", {
    className: "lt-sub"
  }, billCount ? billCount + ' bills' : 'not counted'), /*#__PURE__*/React.createElement("span", {
    className: "lt-chev"
  }, "\u203A")), /*#__PURE__*/React.createElement("button", {
    className: "ltile",
    onClick: () => onGo('crew')
  }, /*#__PURE__*/React.createElement("span", {
    className: "lt-eyebrow"
  }, "Crew"), /*#__PURE__*/React.createElement("span", {
    className: "lt-figure"
  }, crewed ? earners.length : '—'), /*#__PURE__*/React.createElement("span", {
    className: "lt-sub"
  }, crewed ? 'earners' : 'add staff'), /*#__PURE__*/React.createElement("span", {
    className: "lt-chev"
  }, "\u203A"))), /*#__PURE__*/React.createElement("div", {
    className: "live-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "live-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "live-title"
  }, "Live split"), /*#__PURE__*/React.createElement("span", {
    className: "live-perhead"
  }, ready ? fmtMoney(split.perHead) + ' /head' : 'pending')), ready ? /*#__PURE__*/React.createElement("div", {
    className: "live-rows"
  }, rows.map(r => /*#__PURE__*/React.createElement("div", {
    className: "live-row",
    key: r.id,
    "data-role": r.role
  }, /*#__PURE__*/React.createElement("span", {
    className: "lr-name"
  }, r.name), r.isCloser ? /*#__PURE__*/React.createElement("span", {
    className: "lr-closer"
  }, "closer") : null, /*#__PURE__*/React.createElement("span", {
    className: "lr-pay"
  }, fmtMoney(r.payout)))), split.rows.length > 4 ? /*#__PURE__*/React.createElement("div", {
    className: "live-more",
    onClick: () => onGo('split')
  }, "+", split.rows.length - 4, " more \xB7 see all \u203A") : null) : /*#__PURE__*/React.createElement("div", {
    className: "live-empty"
  }, "Count cash & add crew to see live tips")));
}
window.RDHomeScreen = RDHomeScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "redesign/home.jsx", error: String((e && e.message) || e) }); }

// redesign/lib.jsx
try { (() => {
// lib.jsx — TipPool redesign shared engine + helpers (exported to window).
// Pure functions: hours, money formatting, the pool split, and the bill
// distribution that powers the unified BillSheet (dist / remainder / exchange).

const DENOMS = [100, 50, 20, 10, 5, 1];

// "5:00"/"2:00" style shift times → decimal hours, handling PM→AM wrap.
function computeHours(inT, outT) {
  const p = s => {
    if (!s) return null;
    const m = String(s).trim().match(/^(\d{1,2})(?::(\d{1,2}))?/);
    if (!m) return null;
    return Number(m[1]) + (m[2] ? Number(m[2]) / 60 : 0);
  };
  let a = p(inT),
    b = p(outT);
  if (a == null || b == null) return 0;
  // Evening-into-night: an "in" of 5 means 17:00, "out" of 2 means 02:00.
  let ain = a < 12 ? a + 12 : a; // treat small in as PM
  let bout = b <= 6 ? b + 24 : b < 12 ? b + 12 : b; // small out = next-day AM
  let h = bout - ain;
  if (h <= 0) h += 24;
  return Math.round(h * 100) / 100;
}
function fmtMoney(n) {
  const v = Math.round(Number(n) || 0);
  return '$' + v.toLocaleString('en-US');
}
function fmtHours(h) {
  if (!h) return '0h';
  return (h % 1 === 0 ? h : h.toFixed(2)) + 'h';
}

// Pool split: earners (bar+server) split by hours; each closer skims a flat bonus.
function splitPool(pool, staff, opts = {}) {
  const closerBonus = opts.closerBonus ?? 24;
  const earners = staff.filter(s => s.role !== 'support' && (s.name || '').trim());
  if (!pool || earners.length === 0) return {
    rows: [],
    remainder: pool || 0,
    totalHours: 0,
    perHead: 0
  };
  const withH = earners.map(p => ({
    ...p,
    h: computeHours(p.in, p.out) || 0
  }));
  let totalHours = withH.reduce((s, p) => s + p.h, 0);
  const evenFallback = totalHours === 0;
  if (evenFallback) totalHours = earners.length;
  const closers = withH.filter(p => p.isCloser).length;
  const base = pool - closers * closerBonus;
  const rows = withH.map(p => {
    const weight = evenFallback ? 1 : p.h;
    const share = Math.round(weight / totalHours * base);
    const bonus = p.isCloser ? closerBonus : 0;
    return {
      ...p,
      basePay: share,
      bonus,
      payout: share + bonus
    };
  });
  const paid = rows.reduce((s, r) => s + r.payout, 0);
  return {
    rows,
    remainder: pool - paid,
    totalHours: evenFallback ? 0 : totalHours,
    perHead: Math.round(pool / earners.length)
  };
}

// Bill counts {100:n,...} → total + count.
function billsTotal(bills) {
  return DENOMS.reduce((s, d) => s + d * (Number(bills[d]) || 0), 0);
}
function billsCount(bills) {
  return DENOMS.reduce((s, d) => s + (Number(bills[d]) || 0), 0);
}

// Ideal breakdown of a target amount into clean bills (for net-total mode).
function idealBreakdown(total) {
  let rem = Math.round(Number(total) || 0);
  const out = {};
  for (const d of DENOMS) {
    out[d] = Math.floor(rem / d);
    rem -= out[d] * d;
  }
  return out;
}

// Distribute physical bills across payouts (greedy, largest-first), returning a
// per-person bill map and the leftover bills nobody could be paid cleanly.
function distribute(rows, bills) {
  const pool = {};
  DENOMS.forEach(d => {
    pool[d] = Number(bills[d]) || 0;
  });
  const people = rows.map(r => ({
    id: r.id,
    name: r.name,
    role: r.role,
    target: r.payout,
    given: {},
    paid: 0
  }));
  // Largest payouts first so big bills land where they fit.
  const order = [...people].sort((a, b) => b.target - a.target);
  for (const p of order) {
    for (const d of DENOMS) {
      while (pool[d] > 0 && p.paid + d <= p.target) {
        pool[d]--;
        p.given[d] = (p.given[d] || 0) + 1;
        p.paid += d;
      }
    }
  }
  const leftover = {};
  DENOMS.forEach(d => {
    if (pool[d] > 0) leftover[d] = pool[d];
  });
  const leftoverTotal = DENOMS.reduce((s, d) => s + d * (pool[d] || 0), 0);
  return {
    people,
    leftover,
    leftoverTotal
  };
}

// Exchange suggestion: break the largest leftover bills into smaller ones so the
// remainder can be split (illustrative — what to grab from the register drawer).
function exchangeSuggestion(leftover) {
  const give = [],
    get = [];
  DENOMS.forEach(d => {
    if (leftover[d] && d >= 20) give.push({
      denom: d,
      count: leftover[d]
    });
  });
  let smallNeed = give.reduce((s, g) => s + g.denom * g.count, 0);
  if (smallNeed > 0) {
    let rem = smallNeed;
    [5, 1].forEach(d => {
      const n = Math.floor(rem / d);
      if (n) {
        get.push({
          denom: d,
          count: n
        });
        rem -= n * d;
      }
    });
  }
  return {
    give,
    get
  };
}
Object.assign(window, {
  CASH_DENOMS: DENOMS,
  TP: {
    computeHours,
    fmtMoney,
    fmtHours,
    splitPool,
    billsTotal,
    billsCount,
    idealBreakdown,
    distribute,
    exchangeSuggestion
  }
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "redesign/lib.jsx", error: String((e && e.message) || e) }); }

// redesign/split.jsx
try { (() => {
// SplitScreen.jsx — Summary + Distribution merged. Sub-toggle: Payout (per
// person) / Handout (bills to count out). Remainder + per-person handout open
// the unified BillSheet. This is the reveal.

function SplitScreen({
  pool,
  staff,
  effectiveBills,
  split,
  onSheet,
  onGo
}) {
  const {
    PersonCard,
    MoneyValue
  } = window.TipPoolDesignSystem_bcb6c4;
  const {
    fmtMoney,
    distribute
  } = window.TP;
  const DEN = window.CASH_DENOMS;
  const [view, setView] = React.useState('payout');
  if (!pool || split.rows.length === 0) {
    return /*#__PURE__*/React.createElement("div", {
      className: "screen split-screen"
    }, /*#__PURE__*/React.createElement("div", {
      className: "split-empty"
    }, /*#__PURE__*/React.createElement("div", {
      className: "se-icon"
    }, "\u25C7"), /*#__PURE__*/React.createElement("div", {
      className: "se-title"
    }, "Nothing to split yet"), /*#__PURE__*/React.createElement("div", {
      className: "se-sub"
    }, "Count cash and add crew first"), /*#__PURE__*/React.createElement("div", {
      className: "se-actions"
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => onGo('count')
    }, "Count cash \u203A"), /*#__PURE__*/React.createElement("button", {
      onClick: () => onGo('crew')
    }, "Add crew \u203A"))));
  }
  const dist = distribute(split.rows, effectiveBills);
  return /*#__PURE__*/React.createElement("div", {
    className: "screen split-screen"
  }, /*#__PURE__*/React.createElement("div", {
    className: "split-hero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "split-hero-main"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sh-eyebrow"
  }, "Per head"), /*#__PURE__*/React.createElement("div", {
    className: "sh-figure"
  }, fmtMoney(split.perHead))), /*#__PURE__*/React.createElement("div", {
    className: "split-hero-side"
  }, /*#__PURE__*/React.createElement("div", {
    className: "shs-row"
  }, /*#__PURE__*/React.createElement("span", null, "Pool"), /*#__PURE__*/React.createElement("span", {
    className: "gold"
  }, fmtMoney(pool))), /*#__PURE__*/React.createElement("div", {
    className: "shs-row"
  }, /*#__PURE__*/React.createElement("span", null, "Earners"), /*#__PURE__*/React.createElement("span", null, split.rows.length)), /*#__PURE__*/React.createElement("div", {
    className: "shs-row"
  }, /*#__PURE__*/React.createElement("span", null, "Hours"), /*#__PURE__*/React.createElement("span", null, split.totalHours ? split.totalHours.toFixed(1) + 'h' : 'even')))), /*#__PURE__*/React.createElement("div", {
    className: "split-toggle"
  }, /*#__PURE__*/React.createElement("button", {
    className: view === 'payout' ? 'active' : '',
    onClick: () => setView('payout')
  }, "Payout"), /*#__PURE__*/React.createElement("button", {
    className: view === 'handout' ? 'active' : '',
    onClick: () => setView('handout')
  }, "Handout")), view === 'payout' ? /*#__PURE__*/React.createElement("div", {
    className: "payout-list"
  }, split.rows.map(r => /*#__PURE__*/React.createElement(PersonCard, {
    key: r.id,
    name: r.name,
    hours: r.h % 1 === 0 ? r.h : r.h.toFixed(2),
    inTime: r.in || null,
    outTime: r.out || null,
    payout: r.payout,
    basePay: r.bonus ? null : r.basePay,
    bonus: r.bonus || null,
    isCloser: r.isCloser,
    onClick: () => {}
  })), /*#__PURE__*/React.createElement("button", {
    className: 'remainder-row' + (split.remainder === 0 ? ' zero' : ''),
    onClick: () => split.remainder !== 0 && onSheet('remainder', {
      amount: split.remainder,
      leftover: dist.leftover,
      closer: (split.rows.find(r => r.isCloser) || {}).name
    })
  }, /*#__PURE__*/React.createElement("span", {
    className: "rr-label"
  }, "Remainder"), /*#__PURE__*/React.createElement("span", {
    className: "rr-val"
  }, fmtMoney(split.remainder)), split.remainder !== 0 ? /*#__PURE__*/React.createElement("span", {
    className: "rr-chev"
  }, "allocate \u203A") : /*#__PURE__*/React.createElement("span", {
    className: "rr-ok"
  }, "\u2713 clean"))) : /*#__PURE__*/React.createElement("div", {
    className: "handout-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "handout-cap"
  }, "Bills leaving the drawer"), /*#__PURE__*/React.createElement("div", {
    className: "handout-grid"
  }, DEN.map(d => {
    const out = dist.people.reduce((s, p) => s + (p.given[d] || 0), 0);
    return /*#__PURE__*/React.createElement("div", {
      className: 'handout-cell' + (out ? '' : ' empty'),
      key: d
    }, /*#__PURE__*/React.createElement("span", {
      className: "hc-denom"
    }, "$", d), /*#__PURE__*/React.createElement("span", {
      className: "hc-count"
    }, out ? '×' + out : '—'));
  })), /*#__PURE__*/React.createElement("div", {
    className: "handout-people"
  }, dist.people.map((p, i) => /*#__PURE__*/React.createElement("button", {
    className: "handout-person",
    key: p.id,
    "data-role": p.role,
    onClick: () => onSheet('dist', {
      people: dist.people,
      leftover: dist.leftover,
      leftoverTotal: dist.leftoverTotal,
      start: i
    })
  }, /*#__PURE__*/React.createElement("span", {
    className: "hp-name"
  }, p.name), /*#__PURE__*/React.createElement("span", {
    className: "hp-bills"
  }, DEN.filter(d => p.given[d]).map(d => '$' + d + '×' + p.given[d]).join(' · ') || '—'), /*#__PURE__*/React.createElement("span", {
    className: "hp-amt"
  }, fmtMoney(p.paid))))), /*#__PURE__*/React.createElement("button", {
    className: "handout-cta",
    onClick: () => onSheet('dist', {
      people: dist.people,
      leftover: dist.leftover,
      leftoverTotal: dist.leftoverTotal,
      start: 0
    })
  }, "Hand out bills \u2192")));
}
window.SplitScreen = SplitScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "redesign/split.jsx", error: String((e && e.message) || e) }); }

// redesign/tweaks-panel.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)

/* BEGIN USAGE */
// tweaks-panel.jsx
// Reusable Tweaks shell + form-control helpers.
// Exports (to window): useTweaks, TweaksPanel, TweakSection, TweakRow, TweakSlider,
//   TweakToggle, TweakRadio, TweakSelect, TweakText, TweakNumber, TweakColor, TweakButton.
//
// Owns the host protocol (listens for __activate_edit_mode / __deactivate_edit_mode,
// posts __edit_mode_available / __edit_mode_set_keys / __edit_mode_dismissed) so
// individual prototypes don't re-roll it. Ships a consistent set of controls so you
// don't hand-draw <input type="range">, segmented radios, steppers, etc.
//
// Usage (in an HTML file that loads React + Babel):
//
//   const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
//     "primaryColor": "#D97757",
//     "palette": ["#D97757", "#29261b", "#f6f4ef"],
//     "fontSize": 16,
//     "density": "regular",
//     "dark": false
//   }/*EDITMODE-END*/;
//
//   function App() {
//     const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
//     return (
//       <div style={{ fontSize: t.fontSize, color: t.primaryColor }}>
//         Hello
//         <TweaksPanel>
//           <TweakSection label="Typography" />
//           <TweakSlider label="Font size" value={t.fontSize} min={10} max={32} unit="px"
//                        onChange={(v) => setTweak('fontSize', v)} />
//           <TweakRadio  label="Density" value={t.density}
//                        options={['compact', 'regular', 'comfy']}
//                        onChange={(v) => setTweak('density', v)} />
//           <TweakSection label="Theme" />
//           <TweakColor  label="Primary" value={t.primaryColor}
//                        options={['#D97757', '#2A6FDB', '#1F8A5B', '#7A5AE0']}
//                        onChange={(v) => setTweak('primaryColor', v)} />
//           <TweakColor  label="Palette" value={t.palette}
//                        options={[['#D97757', '#29261b', '#f6f4ef'],
//                                  ['#475569', '#0f172a', '#f1f5f9']]}
//                        onChange={(v) => setTweak('palette', v)} />
//           <TweakToggle label="Dark mode" value={t.dark}
//                        onChange={(v) => setTweak('dark', v)} />
//         </TweaksPanel>
//       </div>
//     );
//   }
//
// TweakRadio is the segmented control for 2–3 short options (auto-falls-back to
// TweakSelect past ~16/~10 chars per label); reach for TweakSelect directly when
// options are many or long. For color tweaks always curate 3-4 options rather than
// a free picker; an option can also be a whole 2–5 color palette (the stored value
// is the array). The Tweak* controls are a floor, not a ceiling — build custom
// controls inside the panel if a tweak calls for UI they don't cover.
/* END USAGE */
// ─────────────────────────────────────────────────────────────────────────────

const __TWEAKS_STYLE = `
  .twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:280px;
    max-height:calc(100vh - 32px);display:flex;flex-direction:column;
    transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom right;
    background:rgba(250,249,247,.78);color:#29261b;
    -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
    border:.5px solid rgba(255,255,255,.6);border-radius:14px;
    box-shadow:0 1px 0 rgba(255,255,255,.5) inset,0 12px 40px rgba(0,0,0,.18);
    font:11.5px/1.4 ui-sans-serif,system-ui,-apple-system,sans-serif;overflow:hidden}
  .twk-hd{display:flex;align-items:center;justify-content:space-between;
    padding:10px 8px 10px 14px;cursor:move;user-select:none}
  .twk-hd b{font-size:12px;font-weight:600;letter-spacing:.01em}
  .twk-x{appearance:none;border:0;background:transparent;color:rgba(41,38,27,.55);
    width:22px;height:22px;border-radius:6px;cursor:default;font-size:13px;line-height:1}
  .twk-x:hover{background:rgba(0,0,0,.06);color:#29261b}
  .twk-body{padding:2px 14px 14px;display:flex;flex-direction:column;gap:10px;
    overflow-y:auto;overflow-x:hidden;min-height:0;
    scrollbar-width:thin;scrollbar-color:rgba(0,0,0,.15) transparent}
  .twk-body::-webkit-scrollbar{width:8px}
  .twk-body::-webkit-scrollbar-track{background:transparent;margin:2px}
  .twk-body::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px;
    border:2px solid transparent;background-clip:content-box}
  .twk-body::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.25);
    border:2px solid transparent;background-clip:content-box}
  .twk-row{display:flex;flex-direction:column;gap:5px}
  .twk-row-h{flex-direction:row;align-items:center;justify-content:space-between;gap:10px}
  .twk-lbl{display:flex;justify-content:space-between;align-items:baseline;
    color:rgba(41,38,27,.72)}
  .twk-lbl>span:first-child{font-weight:500}
  .twk-val{color:rgba(41,38,27,.5);font-variant-numeric:tabular-nums}

  .twk-sect{font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
    color:rgba(41,38,27,.45);padding:10px 0 0}
  .twk-sect:first-child{padding-top:0}

  .twk-field{appearance:none;box-sizing:border-box;width:100%;min-width:0;height:26px;padding:0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;
    background:rgba(255,255,255,.6);color:inherit;font:inherit;outline:none}
  .twk-field:focus{border-color:rgba(0,0,0,.25);background:rgba(255,255,255,.85)}
  select.twk-field{padding-right:22px;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='rgba(0,0,0,.5)' d='M0 0h10L5 6z'/></svg>");
    background-repeat:no-repeat;background-position:right 8px center}

  .twk-slider{appearance:none;-webkit-appearance:none;width:100%;height:4px;margin:6px 0;
    border-radius:999px;background:rgba(0,0,0,.12);outline:none}
  .twk-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
    width:14px;height:14px;border-radius:50%;background:#fff;
    border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}
  .twk-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
    background:#fff;border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}

  .twk-seg{position:relative;display:flex;padding:2px;border-radius:8px;
    background:rgba(0,0,0,.06);user-select:none}
  .twk-seg-thumb{position:absolute;top:2px;bottom:2px;border-radius:6px;
    background:rgba(255,255,255,.9);box-shadow:0 1px 2px rgba(0,0,0,.12);
    transition:left .15s cubic-bezier(.3,.7,.4,1),width .15s}
  .twk-seg.dragging .twk-seg-thumb{transition:none}
  .twk-seg button{appearance:none;position:relative;z-index:1;flex:1;border:0;
    background:transparent;color:inherit;font:inherit;font-weight:500;min-height:22px;
    border-radius:6px;cursor:default;padding:4px 6px;line-height:1.2;
    overflow-wrap:anywhere}

  .twk-toggle{position:relative;width:32px;height:18px;border:0;border-radius:999px;
    background:rgba(0,0,0,.15);transition:background .15s;cursor:default;padding:0}
  .twk-toggle[data-on="1"]{background:#34c759}
  .twk-toggle i{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;
    background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}
  .twk-toggle[data-on="1"] i{transform:translateX(14px)}

  .twk-num{display:flex;align-items:center;box-sizing:border-box;min-width:0;height:26px;padding:0 0 0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;background:rgba(255,255,255,.6)}
  .twk-num-lbl{font-weight:500;color:rgba(41,38,27,.6);cursor:ew-resize;
    user-select:none;padding-right:8px}
  .twk-num input{flex:1;min-width:0;height:100%;border:0;background:transparent;
    font:inherit;font-variant-numeric:tabular-nums;text-align:right;padding:0 8px 0 0;
    outline:none;color:inherit;-moz-appearance:textfield}
  .twk-num input::-webkit-inner-spin-button,.twk-num input::-webkit-outer-spin-button{
    -webkit-appearance:none;margin:0}
  .twk-num-unit{padding-right:8px;color:rgba(41,38,27,.45)}

  .twk-btn{appearance:none;height:26px;padding:0 12px;border:0;border-radius:7px;
    background:rgba(0,0,0,.78);color:#fff;font:inherit;font-weight:500;cursor:default}
  .twk-btn:hover{background:rgba(0,0,0,.88)}
  .twk-btn.secondary{background:rgba(0,0,0,.06);color:inherit}
  .twk-btn.secondary:hover{background:rgba(0,0,0,.1)}

  .twk-swatch{appearance:none;-webkit-appearance:none;width:56px;height:22px;
    border:.5px solid rgba(0,0,0,.1);border-radius:6px;padding:0;cursor:default;
    background:transparent;flex-shrink:0}
  .twk-swatch::-webkit-color-swatch-wrapper{padding:0}
  .twk-swatch::-webkit-color-swatch{border:0;border-radius:5.5px}
  .twk-swatch::-moz-color-swatch{border:0;border-radius:5.5px}

  .twk-chips{display:flex;gap:6px}
  .twk-chip{position:relative;appearance:none;flex:1;min-width:0;height:46px;
    padding:0;border:0;border-radius:6px;overflow:hidden;cursor:default;
    box-shadow:0 0 0 .5px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.06);
    transition:transform .12s cubic-bezier(.3,.7,.4,1),box-shadow .12s}
  .twk-chip:hover{transform:translateY(-1px);
    box-shadow:0 0 0 .5px rgba(0,0,0,.18),0 4px 10px rgba(0,0,0,.12)}
  .twk-chip[data-on="1"]{box-shadow:0 0 0 1.5px rgba(0,0,0,.85),
    0 2px 6px rgba(0,0,0,.15)}
  .twk-chip>span{position:absolute;top:0;bottom:0;right:0;width:34%;
    display:flex;flex-direction:column;box-shadow:-1px 0 0 rgba(0,0,0,.1)}
  .twk-chip>span>i{flex:1;box-shadow:0 -1px 0 rgba(0,0,0,.1)}
  .twk-chip>span>i:first-child{box-shadow:none}
  .twk-chip svg{position:absolute;top:6px;left:6px;width:13px;height:13px;
    filter:drop-shadow(0 1px 1px rgba(0,0,0,.3))}
`;

// ── useTweaks ───────────────────────────────────────────────────────────────
// Single source of truth for tweak values. setTweak persists via the host
// (__edit_mode_set_keys → host rewrites the EDITMODE block on disk).
function useTweaks(defaults) {
  const [values, setValues] = React.useState(defaults);
  // Accepts either setTweak('key', value) or setTweak({ key: value, ... }) so a
  // useState-style call doesn't write a "[object Object]" key into the persisted
  // JSON block.
  const setTweak = React.useCallback((keyOrEdits, val) => {
    const edits = typeof keyOrEdits === 'object' && keyOrEdits !== null ? keyOrEdits : {
      [keyOrEdits]: val
    };
    setValues(prev => ({
      ...prev,
      ...edits
    }));
    window.parent.postMessage({
      type: '__edit_mode_set_keys',
      edits
    }, '*');
    // Same-window signal so in-page listeners (deck-stage rail thumbnails)
    // can react — the parent message only reaches the host, not peers.
    window.dispatchEvent(new CustomEvent('tweakchange', {
      detail: edits
    }));
  }, []);
  return [values, setTweak];
}

// ── TweaksPanel ─────────────────────────────────────────────────────────────
// Floating shell. Registers the protocol listener BEFORE announcing
// availability — if the announce ran first, the host's activate could land
// before our handler exists and the toolbar toggle would silently no-op.
// The close button posts __edit_mode_dismissed so the host's toolbar toggle
// flips off in lockstep; the host echoes __deactivate_edit_mode back which
// is what actually hides the panel.
function TweaksPanel({
  title = 'Tweaks',
  children
}) {
  const [open, setOpen] = React.useState(false);
  const dragRef = React.useRef(null);
  const offsetRef = React.useRef({
    x: 16,
    y: 16
  });
  const PAD = 16;
  const clampToViewport = React.useCallback(() => {
    const panel = dragRef.current;
    if (!panel) return;
    const w = panel.offsetWidth,
      h = panel.offsetHeight;
    const maxRight = Math.max(PAD, window.innerWidth - w - PAD);
    const maxBottom = Math.max(PAD, window.innerHeight - h - PAD);
    offsetRef.current = {
      x: Math.min(maxRight, Math.max(PAD, offsetRef.current.x)),
      y: Math.min(maxBottom, Math.max(PAD, offsetRef.current.y))
    };
    panel.style.right = offsetRef.current.x + 'px';
    panel.style.bottom = offsetRef.current.y + 'px';
  }, []);
  React.useEffect(() => {
    if (!open) return;
    clampToViewport();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', clampToViewport);
      return () => window.removeEventListener('resize', clampToViewport);
    }
    const ro = new ResizeObserver(clampToViewport);
    ro.observe(document.documentElement);
    return () => ro.disconnect();
  }, [open, clampToViewport]);
  React.useEffect(() => {
    const onMsg = e => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') setOpen(true);else if (t === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({
      type: '__edit_mode_available'
    }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const dismiss = () => {
    setOpen(false);
    window.parent.postMessage({
      type: '__edit_mode_dismissed'
    }, '*');
  };
  const onDragStart = e => {
    const panel = dragRef.current;
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    const sx = e.clientX,
      sy = e.clientY;
    const startRight = window.innerWidth - r.right;
    const startBottom = window.innerHeight - r.bottom;
    const move = ev => {
      offsetRef.current = {
        x: startRight - (ev.clientX - sx),
        y: startBottom - (ev.clientY - sy)
      };
      clampToViewport();
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, __TWEAKS_STYLE), /*#__PURE__*/React.createElement("div", {
    ref: dragRef,
    className: "twk-panel",
    "data-omelette-chrome": "",
    style: {
      right: offsetRef.current.x,
      bottom: offsetRef.current.y
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-hd",
    onMouseDown: onDragStart
  }, /*#__PURE__*/React.createElement("b", null, title), /*#__PURE__*/React.createElement("button", {
    className: "twk-x",
    "aria-label": "Close tweaks",
    onMouseDown: e => e.stopPropagation(),
    onClick: dismiss
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "twk-body"
  }, children)));
}

// ── Layout helpers ──────────────────────────────────────────────────────────

function TweakSection({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "twk-sect"
  }, label), children);
}
function TweakRow({
  label,
  value,
  children,
  inline = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: inline ? 'twk-row twk-row-h' : 'twk-row'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label), value != null && /*#__PURE__*/React.createElement("span", {
    className: "twk-val"
  }, value)), children);
}

// ── Controls ────────────────────────────────────────────────────────────────

function TweakSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  unit = '',
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label,
    value: `${value}${unit}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "range",
    className: "twk-slider",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }));
}
function TweakToggle({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "twk-toggle",
    "data-on": value ? '1' : '0',
    role: "switch",
    "aria-checked": !!value,
    onClick: () => onChange(!value)
  }, /*#__PURE__*/React.createElement("i", null)));
}
function TweakRadio({
  label,
  value,
  options,
  onChange
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  // The active value is read by pointer-move handlers attached for the lifetime
  // of a drag — ref it so a stale closure doesn't fire onChange for every move.
  const valueRef = React.useRef(value);
  valueRef.current = value;

  // Segments wrap mid-word once per-segment width runs out. The track is
  // ~248px (280 panel − 28 body pad − 4 seg pad), each button loses 12px
  // to its own padding, and 11.5px system-ui averages ~6.3px/char — so 2
  // options fit ~16 chars each, 3 fit ~10. Past that (or >3 options), fall
  // back to a dropdown rather than wrap.
  const labelLen = o => String(typeof o === 'object' ? o.label : o).length;
  const maxLen = options.reduce((m, o) => Math.max(m, labelLen(o)), 0);
  const fitsAsSegments = maxLen <= ({
    2: 16,
    3: 10
  }[options.length] ?? 0);
  if (!fitsAsSegments) {
    // <select> emits strings — map back to the original option value so the
    // fallback stays type-preserving (numbers, booleans) like the segment path.
    const resolve = s => {
      const m = options.find(o => String(typeof o === 'object' ? o.value : o) === s);
      return m === undefined ? s : typeof m === 'object' ? m.value : m;
    };
    return /*#__PURE__*/React.createElement(TweakSelect, {
      label: label,
      value: value,
      options: options,
      onChange: s => onChange(resolve(s))
    });
  }
  const opts = options.map(o => typeof o === 'object' ? o : {
    value: o,
    label: o
  });
  const idx = Math.max(0, opts.findIndex(o => o.value === value));
  const n = opts.length;
  const segAt = clientX => {
    const r = trackRef.current.getBoundingClientRect();
    const inner = r.width - 4;
    const i = Math.floor((clientX - r.left - 2) / inner * n);
    return opts[Math.max(0, Math.min(n - 1, i))].value;
  };
  const onPointerDown = e => {
    setDragging(true);
    const v0 = segAt(e.clientX);
    if (v0 !== valueRef.current) onChange(v0);
    const move = ev => {
      if (!trackRef.current) return;
      const v = segAt(ev.clientX);
      if (v !== valueRef.current) onChange(v);
    };
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    role: "radiogroup",
    onPointerDown: onPointerDown,
    className: dragging ? 'twk-seg dragging' : 'twk-seg'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-seg-thumb",
    style: {
      left: `calc(2px + ${idx} * (100% - 4px) / ${n})`,
      width: `calc((100% - 4px) / ${n})`
    }
  }), opts.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    role: "radio",
    "aria-checked": o.value === value
  }, o.label))));
}
function TweakSelect({
  label,
  value,
  options,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("select", {
    className: "twk-field",
    value: value,
    onChange: e => onChange(e.target.value)
  }, options.map(o => {
    const v = typeof o === 'object' ? o.value : o;
    const l = typeof o === 'object' ? o.label : o;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })));
}
function TweakText({
  label,
  value,
  placeholder,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("input", {
    className: "twk-field",
    type: "text",
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakNumber({
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange
}) {
  const clamp = n => {
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  const startRef = React.useRef({
    x: 0,
    val: 0
  });
  const onScrubStart = e => {
    e.preventDefault();
    startRef.current = {
      x: e.clientX,
      val: value
    };
    const decimals = (String(step).split('.')[1] || '').length;
    const move = ev => {
      const dx = ev.clientX - startRef.current.x;
      const raw = startRef.current.val + dx * step;
      const snapped = Math.round(raw / step) * step;
      onChange(clamp(Number(snapped.toFixed(decimals))));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "twk-num-lbl",
    onPointerDown: onScrubStart
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "number",
    value: value,
    min: min,
    max: max,
    step: step,
    onChange: e => onChange(clamp(Number(e.target.value)))
  }), unit && /*#__PURE__*/React.createElement("span", {
    className: "twk-num-unit"
  }, unit));
}

// Relative-luminance contrast pick — checkmarks drawn over a swatch need to
// read on both #111 and #fafafa without per-option configuration. Hex input
// only (#rgb / #rrggbb); named or rgb()/hsl() colors fall through to "light".
function __twkIsLight(hex) {
  const h = String(hex).replace('#', '');
  const x = h.length === 3 ? h.replace(/./g, c => c + c) : h.padEnd(6, '0');
  const n = parseInt(x.slice(0, 6), 16);
  if (Number.isNaN(n)) return true;
  const r = n >> 16 & 255,
    g = n >> 8 & 255,
    b = n & 255;
  return r * 299 + g * 587 + b * 114 > 148000;
}
const __TwkCheck = ({
  light
}) => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 14 14",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("path", {
  d: "M3 7.2 5.8 10 11 4.2",
  fill: "none",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  stroke: light ? 'rgba(0,0,0,.78)' : '#fff'
}));

// TweakColor — curated color/palette picker. Each option is either a single
// hex string or an array of 1-5 hex strings; the card adapts — a lone color
// renders solid, a palette renders colors[0] as the hero (left ~2/3) with the
// rest stacked in a sharp column on the right. onChange emits the
// option in the shape it was passed (string stays string, array stays array).
// Without options it falls back to the native color input for back-compat.
function TweakColor({
  label,
  value,
  options,
  onChange
}) {
  if (!options || !options.length) {
    return /*#__PURE__*/React.createElement("div", {
      className: "twk-row twk-row-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "twk-lbl"
    }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("input", {
      type: "color",
      className: "twk-swatch",
      value: value,
      onChange: e => onChange(e.target.value)
    }));
  }
  // Native <input type=color> emits lowercase hex per the HTML spec, so
  // compare case-insensitively. String() guards JSON.stringify(undefined),
  // which returns the primitive undefined (no .toLowerCase).
  const key = o => String(JSON.stringify(o)).toLowerCase();
  const cur = key(value);
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-chips",
    role: "radiogroup"
  }, options.map((o, i) => {
    const colors = Array.isArray(o) ? o : [o];
    const [hero, ...rest] = colors;
    const sup = rest.slice(0, 4);
    const on = key(o) === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      className: "twk-chip",
      role: "radio",
      "aria-checked": on,
      "data-on": on ? '1' : '0',
      "aria-label": colors.join(', '),
      title: colors.join(' · '),
      style: {
        background: hero
      },
      onClick: () => onChange(o)
    }, sup.length > 0 && /*#__PURE__*/React.createElement("span", null, sup.map((c, j) => /*#__PURE__*/React.createElement("i", {
      key: j,
      style: {
        background: c
      }
    }))), on && /*#__PURE__*/React.createElement(__TwkCheck, {
      light: __twkIsLight(hero)
    }));
  })));
}
function TweakButton({
  label,
  onClick,
  secondary = false
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: secondary ? 'twk-btn secondary' : 'twk-btn',
    onClick: onClick
  }, label);
}
Object.assign(window, {
  useTweaks,
  TweaksPanel,
  TweakSection,
  TweakRow,
  TweakSlider,
  TweakToggle,
  TweakRadio,
  TweakSelect,
  TweakText,
  TweakNumber,
  TweakColor,
  TweakButton
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "redesign/tweaks-panel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tippool/CashScreen.jsx
try { (() => {
// CashScreen — net-total entry with a bill-count mode that uses DenomRow.
const DENOMS = [100, 50, 20, 10, 5, 1];
function CashScreen({
  shift,
  setShift,
  mode,
  setMode,
  bills,
  setBills,
  netTotal,
  setNetTotal
}) {
  const {
    SegmentedControl,
    DenomRow,
    Button
  } = window.TipPoolDesignSystem_bcb6c4;
  const Icons = window.TipPoolIcons;
  const billTotal = DENOMS.reduce((s, d) => s + d * (Number(bills[d]) || 0), 0);
  const billCount = DENOMS.reduce((s, d) => s + (Number(bills[d]) || 0), 0);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement(SegmentedControl, {
    value: shift,
    onChange: setShift,
    options: [{
      value: 'night',
      label: 'Night Shift'
    }, {
      value: 'day',
      label: 'Day Shift'
    }]
  }), mode === 'nettotal' ? /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius)',
      padding: '18px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '4px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '2rem',
      fontWeight: 800,
      color: netTotal ? 'var(--gold)' : 'var(--muted-2)'
    }
  }, "$"), /*#__PURE__*/React.createElement("input", {
    type: "number",
    inputMode: "numeric",
    placeholder: "0",
    value: netTotal,
    onChange: e => setNetTotal(e.target.value),
    style: {
      flex: 1,
      minWidth: 0,
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: netTotal ? 'var(--gold)' : 'var(--text)',
      fontFamily: 'var(--font-mono)',
      fontSize: '2rem',
      fontWeight: 800,
      fontVariantNumeric: 'tabular-nums'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: '12px',
      paddingTop: '12px',
      borderTop: '1px solid var(--border)',
      color: 'var(--muted)',
      fontFamily: 'var(--font-mono)',
      fontSize: '0.62rem',
      lineHeight: 1.5
    }
  }, netTotal ? `Pool of $${Number(netTotal).toLocaleString()} ready to split across the night.` : 'Enter total above to see ideal bill breakdown')) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '5px'
    }
  }, DENOMS.map(d => /*#__PURE__*/React.createElement(DenomRow, {
    key: d,
    denom: d,
    count: bills[d] || '',
    subtotal: '$' + (d * (Number(bills[d]) || 0)).toLocaleString(),
    onCountChange: v => setBills({
      ...bills,
      [d]: v
    })
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginTop: '4px',
      padding: '10px 12px',
      background: 'var(--surface-2)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-sm)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.6rem',
      fontWeight: 700,
      letterSpacing: '1px',
      textTransform: 'uppercase',
      color: 'var(--muted)'
    }
  }, "Total"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '1.3rem',
      fontWeight: 800,
      color: billTotal ? 'var(--gold)' : 'var(--muted-2)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, "$", billTotal.toLocaleString()))), /*#__PURE__*/React.createElement(SegmentedControl, {
    value: mode,
    onChange: setMode,
    options: [{
      value: 'nettotal',
      label: 'Net Total'
    }, {
      value: 'perbill',
      label: 'Bill Counts'
    }]
  }));
}
window.CashScreen = CashScreen;
window.CASH_DENOMS = DENOMS;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tippool/CashScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tippool/HomeScreen.jsx
try { (() => {
// HomeScreen — dashboard with the two stat tiles + a live-tips preview.
function HomeScreen({
  cashTotal,
  billCount,
  staff,
  onGo
}) {
  const {
    StatCard
  } = window.TipPoolDesignSystem_bcb6c4;
  const hasData = cashTotal > 0 && staff.length > 0;
  const perHead = hasData ? Math.round(cashTotal / staff.length) : 0;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '10px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '8px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1.4
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Cash on Hand",
    value: '$' + cashTotal.toLocaleString(),
    sub: billCount ? billCount + ' bills' : '—',
    onClick: () => onGo('cash')
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Staff",
    value: staff.length,
    sub: "employees",
    tone: "neutral",
    onClick: () => onGo('staff')
  }))), hasData ? /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface)',
      border: '1px solid var(--green-border)',
      borderRadius: 'var(--radius)',
      padding: '14px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.52rem',
      fontWeight: 800,
      letterSpacing: '1.2px',
      textTransform: 'uppercase',
      color: 'var(--muted)'
    }
  }, "Ready to calculate"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text)',
      fontSize: '1.25rem',
      fontWeight: 800,
      marginTop: '5px'
    }
  }, "~$", perHead, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted)',
      fontSize: '0.7rem',
      fontWeight: 600,
      fontFamily: 'var(--font-mono)'
    }
  }, " / head est.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: '8px',
      marginTop: '12px'
    }
  }, [['Pool', '$' + cashTotal.toLocaleString()], ['Staff', staff.length], ['Closers', staff.filter(s => s.isCloser).length]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      background: 'var(--surface-2)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-sm)',
      padding: '10px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      color: 'var(--muted)',
      fontFamily: 'var(--font-mono)',
      fontSize: '0.5rem',
      fontWeight: 800,
      letterSpacing: '0.8px',
      textTransform: 'uppercase'
    }
  }, k), /*#__PURE__*/React.createElement("strong", {
    style: {
      display: 'block',
      color: 'var(--gold)',
      fontFamily: 'var(--font-mono)',
      fontSize: '0.9rem',
      marginTop: '4px',
      fontWeight: 700
    }
  }, v))))) : /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      color: 'var(--muted)',
      fontFamily: 'var(--font-mono)',
      fontSize: '0.7rem',
      padding: '32px 0',
      border: '1px dashed var(--border)',
      borderRadius: 'var(--radius)'
    }
  }, "Add cash & staff to see live tips"));
}
window.HomeScreen = HomeScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tippool/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tippool/StaffScreen.jsx
try { (() => {
// StaffScreen — role toggle + per-role staff rows with name, in/out, hours.
function StaffRow({
  person,
  roleColor,
  onChange
}) {
  const hrs = computeHours(person.in, person.out);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-2)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-sm)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      padding: '8px 9px'
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: person.name,
    placeholder: "Name",
    onChange: e => onChange({
      ...person,
      name: e.target.value
    }),
    style: {
      flex: 1,
      minWidth: 0,
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-sm)',
      color: 'var(--text)',
      fontFamily: 'var(--font-sans)',
      fontSize: '0.92rem',
      fontWeight: 700,
      padding: '8px 10px',
      outline: 'none'
    }
  }), person.isCloser ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.48rem',
      fontWeight: 700,
      letterSpacing: '0.7px',
      textTransform: 'uppercase',
      color: 'var(--accent)',
      border: '1px solid var(--accent)',
      background: '#1a0608',
      borderRadius: 'var(--radius-chip)',
      padding: '2px 5px'
    }
  }, "Closer") : null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      borderTop: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement(TimeField, {
    label: "In",
    value: person.in,
    onChange: v => onChange({
      ...person,
      in: v
    })
  }), /*#__PURE__*/React.createElement(TimeField, {
    label: "Out",
    value: person.out,
    onChange: v => onChange({
      ...person,
      out: v
    }),
    border: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 78,
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      borderLeft: '1px solid var(--border)',
      background: 'var(--surface)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.44rem',
      fontWeight: 800,
      letterSpacing: '0.5px',
      textTransform: 'uppercase',
      color: 'var(--muted-2)'
    }
  }, "Hours"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '1rem',
      fontWeight: 800,
      color: hrs ? 'var(--gold-2)' : 'var(--muted-2)',
      lineHeight: 1.1
    }
  }, hrs ? hrs + 'h' : '—'))));
}
function TimeField({
  label,
  value,
  onChange,
  border
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      alignItems: 'center',
      gap: '6px',
      padding: '7px 10px',
      borderLeft: border ? '1px solid var(--border)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.5rem',
      fontWeight: 700,
      letterSpacing: '0.5px',
      textTransform: 'uppercase',
      color: 'var(--muted)'
    }
  }, label), /*#__PURE__*/React.createElement("input", {
    value: value,
    placeholder: "\u2014",
    onChange: e => onChange(e.target.value),
    style: {
      flex: 1,
      minWidth: 0,
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: 'var(--text)',
      fontFamily: 'var(--font-mono)',
      fontSize: '0.84rem',
      fontWeight: 600
    }
  }));
}
function computeHours(inT, outT) {
  const p = t => {
    const m = /^(\d{1,2})(?::(\d{2}))?$/.exec((t || '').trim());
    return m ? Number(m[1]) + (m[2] ? Number(m[2]) / 60 : 0) : null;
  };
  let a = p(inT),
    b = p(outT);
  if (a == null || b == null) return null;
  if (b <= a) b += 12; // crude pm wrap for the mock
  const h = b - a;
  return h > 0 && h < 24 ? Math.round(h * 100) / 100 : null;
}
function StaffScreen({
  role,
  setRole,
  staff,
  setStaff
}) {
  const {
    SegmentedControl,
    Button
  } = window.TipPoolDesignSystem_bcb6c4;
  const list = staff.filter(s => s.role === role);
  const colorMap = {
    bartender: 'role-bartender',
    server: 'role-server',
    support: 'role-support'
  };
  const update = (id, next) => setStaff(staff.map(s => s.id === id ? next : s));
  const add = () => setStaff([...staff, {
    id: Date.now(),
    name: '',
    role,
    in: '',
    out: '',
    isCloser: false
  }]);
  const labels = {
    bartender: 'Bartender',
    server: 'Server',
    support: 'Support'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement(SegmentedControl, {
    value: role,
    onChange: setRole,
    options: [{
      value: 'bartender',
      label: 'Bartender'
    }, {
      value: 'server',
      label: 'Server'
    }, {
      value: 'support',
      label: 'Support'
    }],
    accentMap: {
      bartender: {
        color: 'var(--role-bartender)',
        border: 'var(--role-bartender-border)'
      },
      server: {
        color: 'var(--role-server)',
        border: 'var(--role-server-border)'
      },
      support: {
        color: 'var(--role-support)',
        border: 'var(--role-support-border)'
      }
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '0 2px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.6rem',
      fontWeight: 700,
      letterSpacing: '0.5px',
      textTransform: 'uppercase',
      color: `var(--${colorMap[role]})`
    }
  }, list.length, " ", list.length === 1 ? 'person' : 'people')), role === 'support' ? /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--muted)',
      fontFamily: 'var(--font-mono)',
      fontSize: '0.58rem',
      lineHeight: 1.5,
      background: 'var(--surface-2)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-sm)',
      padding: '9px 11px'
    }
  }, "Support staff share a pool of hours but earn no tips directly \u2014 they're tipped out from the bar & server pools.") : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '8px'
    }
  }, list.map(p => /*#__PURE__*/React.createElement(StaffRow, {
    key: p.id,
    person: p,
    roleColor: colorMap[role],
    onChange: next => update(p.id, next)
  }))), /*#__PURE__*/React.createElement(Button, {
    variant: "dashed",
    fullWidth: true,
    onClick: add
  }, "+ Add ", labels[role]));
}
window.StaffScreen = StaffScreen;
window.computeHours = computeHours;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tippool/StaffScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tippool/SummaryScreen.jsx
try { (() => {
// SummaryScreen — hero pool total + per-person payout rows (PersonCard).
function SummaryScreen({
  pool,
  staff,
  onGo
}) {
  const {
    PersonCard,
    MoneyValue
  } = window.TipPoolDesignSystem_bcb6c4;
  const earners = staff.filter(s => s.role !== 'support' && s.name.trim());
  if (!pool || earners.length === 0) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: 'center',
        padding: '40px 16px',
        border: '1px dashed var(--border)',
        borderRadius: 'var(--radius)',
        color: 'var(--muted)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontWeight: 800,
        fontSize: '0.95rem',
        color: 'var(--text-2)',
        marginBottom: '4px'
      }
    }, "No data yet"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: '0.66rem'
      }
    }, "Enter cash & staff to calculate"), /*#__PURE__*/React.createElement("div", {
      onClick: () => onGo('cash'),
      style: {
        marginTop: '14px',
        display: 'inline-block',
        cursor: 'pointer',
        fontFamily: 'var(--font-mono)',
        fontSize: '0.62rem',
        fontWeight: 700,
        color: 'var(--accent)',
        letterSpacing: '0.5px',
        textTransform: 'uppercase'
      }
    }, "Go to Cash \u203A"));
  }

  // Allocate by hours, with a small closer bonus skim.
  const totalHours = earners.reduce((s, p) => s + (computeHours(p.in, p.out) || 0), 0) || earners.length;
  const closerBonus = 24;
  const closers = earners.filter(p => p.isCloser).length;
  const bonusPot = closers * closerBonus;
  const base = pool - bonusPot;
  const rows = earners.map(p => {
    const h = computeHours(p.in, p.out) || totalHours / earners.length;
    const share = Math.round(h / totalHours * base);
    const bonus = p.isCloser ? closerBonus : 0;
    return {
      ...p,
      h,
      payout: share + bonus,
      basePay: share,
      bonus
    };
  });
  const paid = rows.reduce((s, r) => s + r.payout, 0);
  const remainder = pool - paid;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '10px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius)',
      padding: '14px 16px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(MoneyValue, {
    label: "Pool total",
    amount: pool,
    size: "hero"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.5rem',
      fontWeight: 700,
      letterSpacing: '1.4px',
      textTransform: 'uppercase',
      color: 'var(--muted)'
    }
  }, "Splitting"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.95rem',
      fontWeight: 700,
      color: 'var(--text-2)',
      marginTop: '3px'
    }
  }, earners.length, " staff"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.6rem',
      color: 'var(--muted)',
      marginTop: '2px'
    }
  }, totalHours.toFixed(2), "h total"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)'
    }
  }, rows.map(r => /*#__PURE__*/React.createElement(PersonCard, {
    key: r.id,
    name: r.name,
    hours: r.h % 1 === 0 ? r.h : r.h.toFixed(2),
    inTime: r.in || null,
    outTime: r.out || null,
    payout: r.payout,
    basePay: r.bonus ? null : r.basePay,
    bonus: r.bonus || null,
    isCloser: r.isCloser,
    onClick: () => {}
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '11px 13px',
      background: 'var(--surface-2)',
      border: '1px dashed var(--border-2)',
      borderRadius: 'var(--radius-sm)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.58rem',
      fontWeight: 700,
      letterSpacing: '1px',
      textTransform: 'uppercase',
      color: 'var(--muted)'
    }
  }, "Remainder"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.9rem',
      fontWeight: 800,
      color: remainder === 0 ? 'var(--muted-2)' : 'var(--text-2)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, "$", remainder)));
}
window.SummaryScreen = SummaryScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tippool/SummaryScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tippool/icons.jsx
try { (() => {
// TipPool icon set — Lucide-style stroke icons lifted from the source app.
// All 24×24, fill:none, currentColor stroke. Tab bar uses 1.8 stroke.
function Icon({
  d,
  children,
  size = 19,
  sw = 1.8,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    width: size,
    height: size,
    fill: "none",
    stroke: "currentColor",
    strokeWidth: sw,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: style
  }, d ? /*#__PURE__*/React.createElement("path", {
    d: d
  }) : children);
}
const Icons = {
  home: p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
    d: "M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "9 22 9 12 15 12 15 22"
  })),
  cash: p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "6",
    width: "20",
    height: "12",
    rx: "2"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M6 12h.01M18 12h.01"
  })),
  staff: p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
    d: "M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "9",
    cy: "7",
    r: "4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"
  })),
  summary: p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("line", {
    x1: "8",
    y1: "6",
    x2: "21",
    y2: "6"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "8",
    y1: "12",
    x2: "21",
    y2: "12"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "8",
    y1: "18",
    x2: "21",
    y2: "18"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "3",
    y1: "6",
    x2: "3.01",
    y2: "6"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "3",
    y1: "12",
    x2: "3.01",
    y2: "12"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "3",
    y1: "18",
    x2: "3.01",
    y2: "18"
  })),
  dist: p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "3",
    width: "18",
    height: "18",
    rx: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M3 9h18M9 21V9"
  })),
  moon: p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("path", {
    d: "M21 12.79A9 9 0 1111.21 3a7 7 0 009.79 9.79z"
  })),
  sun: p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"
  })),
  clock: p => /*#__PURE__*/React.createElement(Icon, p, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "9"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 7v5l3 2"
  }))
};
window.TipPoolIcons = Icons;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tippool/icons.jsx", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/calculator.js
try { (() => {
// ── Debounced auto-calculate ──────────────────────────────────────────────────

let _calcTimer = null;
function scheduleCalculate() {
  if (_calcTimer) clearTimeout(_calcTimer);
  _calcTimer = setTimeout(autoCalculate, 120);
}

// ── Shared UI helpers ─────────────────────────────────────────────────────────

function setStaleBanners(reason) {
  const message = '⚠ ' + reason + ' Results below are outdated.';
  document.querySelectorAll('.stale-banner').forEach(b => {
    b.textContent = message;
    b.classList.add('visible');
  });
}
function clearStaleBanners() {
  document.querySelectorAll('.stale-banner').forEach(b => b.classList.remove('visible'));
}
function renderBlockedPlaceholders(reason) {
  const safe = escapeHTML(reason);
  const summary = $('summary-content');
  const dist = $('dist-content');
  if (summary) summary.innerHTML = `<div class="warn-box">⚠ ${safe}</div>`;
  if (dist) dist.innerHTML = `<div class="warn-box">⚠ ${safe}</div>`;
}
function blockCalculation(reason, options = {}) {
  currentInputError = options.inputError ? reason : '';
  updateHomeLive(null);
  clearStaleBanners();
  if (lastStaff.length || lastDayResult || options.showPlaceholder) {
    renderBlockedPlaceholders(reason);
  }
}

// ── Input collection ──────────────────────────────────────────────────────────

function collectNamedStaffRows() {
  // Night shift: collect bartenders (staffList) + servers (nightServerList), exclude support
  const selectors = ['#staffList .staff-row-modal', '#nightServerList .staff-row-modal'];
  const allRows = selectors.flatMap(sel => [...document.querySelectorAll(sel)]);
  const gcIn = $('gc-in').value.trim(),
    gcOut = $('gc-out').value.trim();
  const errors = [];
  const gcInParsed = parseTimeString(gcIn),
    gcOutParsed = parseTimeString(gcOut);
  setInputInvalid($('gc-in'), !!gcIn && !gcInParsed.valid);
  setInputInvalid($('gc-out'), !!gcOut && !gcOutParsed.valid);
  if (gcIn && !gcInParsed.valid) errors.push('Default In must be a valid time (e.g. 5, 11, 12.5).');
  if (gcOut && !gcOutParsed.valid) errors.push('Default Out must be a valid time (e.g. 5, 11, 12.5).');
  ['bartender', 'server'].forEach(role => {
    const defs = roleDefaults[role] || {};
    const inParsed = parseTimeString(defs.in || '');
    const outParsed = parseTimeString(defs.out || '');
    if (defs.in && !inParsed.valid) errors.push(role + ' default In must be a valid time.');
    if (defs.out && !outParsed.valid) errors.push(role + ' default Out must be a valid time.');
  });
  const rawData = [];
  allRows.forEach(r => {
    const name = r.querySelector('[data-field="name"]').value.trim();
    const inEl = r.querySelector('[data-field="in"]');
    const outEl = r.querySelector('[data-field="out"]');
    const inStr = inEl.value.trim();
    const outStr = outEl.value.trim();
    const inParsed = parseTimeString(inStr);
    const outParsed = parseTimeString(outStr);
    setInputInvalid(inEl, !!inStr && !inParsed.valid);
    setInputInvalid(outEl, !!outStr && !outParsed.valid);
    if (!name) return;
    if (inStr && !inParsed.valid) errors.push(name + ' has an invalid In time.');
    if (outStr && !outParsed.valid) errors.push(name + ' has an invalid Out time.');
    rawData.push({
      name,
      inStr,
      outStr,
      hasIn: !!inStr,
      hasOut: !!outStr,
      rowId: r.id.replace('staff', '')
    });
  });
  return {
    rawData,
    gcIn,
    gcOut,
    errors
  };
}

// ── Night shift: pure computation ─────────────────────────────────────────────
//
// Returns one of:
//   { ok: false, reason: string, inputError?: true }
//   { ok: true, staff, total, totH, rate, leftover, pool }
//
// No globals written. No DOM written. No renders triggered.

function computeNightShift() {
  const {
    rawData,
    gcIn,
    gcOut,
    errors
  } = collectNamedStaffRows();
  if (errors.length) {
    return {
      ok: false,
      reason: errors[0],
      inputError: true
    };
  }
  if (!rawData.length) {
    return {
      ok: false,
      reason: 'Add staff with names.'
    };
  }

  // Effective in/out: explicit value → role default → global default
  rawData.forEach(r => {
    const role = getRoleForList(_listIdForRowId(r.rowId));
    const rDef = roleDefaults[role] || {};
    r.effIn = r.inStr || rDef.in || gcIn;
    r.effOut = r.outStr || rDef.out || gcOut;
  });
  let maxEo = 0;
  rawData.forEach(r => {
    if (r.effIn && r.effOut) {
      const i = parseTimeString(r.effIn).value;
      const o = parseTimeString(r.effOut).value;
      const eo = o < i ? o + 12 : o;
      if (eo > maxEo) maxEo = eo;
    }
  });
  const defaultIn = 5;
  const defaultOut = maxEo > 0 ? maxEo > 12 ? maxEo - 12 : maxEo : 2;

  // First pass: build staff with times, no closer yet
  const staff = rawData.map(r => {
    const inParsed = parseTimeString(r.effIn);
    const outParsed = parseTimeString(r.effOut);
    const inVal = inParsed.empty ? defaultIn : inParsed.value;
    const outVal = outParsed.empty ? defaultOut : outParsed.value;
    let h = outVal - inVal;
    if (h < 0) h += 12;
    const eo = outVal < inVal ? outVal + 12 : outVal;
    return {
      n: r.name,
      i: inVal,
      o: outVal,
      h,
      eo,
      _rowId: r.rowId,
      _autoCloser: false,
      closer: false,
      bills: {
        100: 0,
        50: 0,
        20: 0,
        10: 0,
        5: 0,
        1: 0
      }
    };
  });

  // Closer logic: the person(s) with the latest effective out time are closers.
  // Tied at the max → all are closers. Manual toggle (ct button) also forces closer.
  const peakEo = staff.length ? Math.max(...staff.map(p => p.eo)) : 0;
  staff.forEach(p => {
    const ctEl = document.getElementById('ct' + p._rowId);
    const manualOn = ctEl ? ctEl.classList.contains('on') : false;
    const autoClose = peakEo > 0 && p.eo >= peakEo;
    p._autoCloser = autoClose;
    p.closer = manualOn || autoClose;
  });
  const invalidStaff = staff.find(p => p.h <= 0 || p.h > 12);
  if (invalidStaff) {
    return {
      ok: false,
      reason: invalidStaff.n + ' has invalid shift hours.',
      inputError: true
    };
  }
  const total = getTotal();
  const totH = staff.reduce((s, p) => s + p.h, 0);
  if (totH <= 0) {
    return {
      ok: false,
      reason: 'Add valid staff hours.',
      inputError: true
    };
  }
  const rate = total / totH;
  staff.forEach(p => {
    p.exact = p.h * rate;
    p.base = Math.floor(p.exact);
    p.bonus = 0;
  });
  const floored = staff.reduce((s, p) => s + p.base, 0);
  const remainder = total - floored;
  const remAlloc = applyRemainderAllocation(staff, remainder);
  const leftover = remAlloc.leftover;
  staff.forEach(p => {
    p.final = p.base + p.bonus;
    p.rem = p.final;
  });
  return {
    ok: true,
    staff,
    total,
    totH,
    rate,
    leftover,
    remainderPool: remainder,
    pool: getInputPool()
  };
}

// ── Night shift: distribution ─────────────────────────────────────────────────
//
// Runs distributeBills (which has side effects on globals) and captures its
// outputs into an explicit object returned to the caller.

function runDistribution(staff, pool, leftover) {
  const sc = staff.map(p => ({
    ...p,
    bills: {},
    rem: p.final
  }));
  const dist = distributeBills(sc, {
    ...pool
  }, leftover);
  return {
    staffWithBills: sc,
    poolAfter: dist.poolAfter,
    remainderBills: dist.remainderBills,
    distributionError: dist.distributionError
  };
}

// ── Night shift: render ───────────────────────────────────────────────────────
//
// Receives all data explicitly — does not read globals for computation results.

function renderNightShift(computeResult, distResult) {
  const {
    staff,
    total,
    totH,
    rate,
    leftover,
    pool
  } = computeResult;
  const {
    staffWithBills,
    poolAfter,
    remainderBills,
    distributionError
  } = distResult;
  currentInputError = '';
  renderSummary(staffWithBills, staff, total, totH, rate, leftover, poolAfter, {
    remainderBills,
    distributionError,
    pool
  });
  renderDist(staffWithBills, poolAfter, {
    remainderBills,
    distributionError,
    leftover,
    pool
  });
  updateHomeLive(staff, {
    rate,
    totH,
    leftover,
    distributionError
  });
}

// ── Night shift: orchestration ────────────────────────────────────────────────

function autoCalculate() {
  if (shiftMode === 'day') {
    autoCalculateDay();
    return;
  }
  if (cashMode === 'nettotal' && !isUpdatingNetTotal) refreshNetTotalBreakdown();
  const cashValidation = validateCashInputs();
  if (!cashValidation.valid) {
    updateStockCards();
    updateTabIndicators();
    blockCalculation(cashValidation.message, {
      inputError: true,
      showPlaceholder: true
    });
    saveState();
    return;
  }
  const {
    rawData
  } = collectNamedStaffRows();
  const hasName = rawData.length > 0;
  const total = cashValidation.total;
  if (!hasName || total === 0) {
    currentInputError = '';
    updateStockCards();
    updateTabIndicators();
    updateHomeLive(null);
    clearStaleBanners();
    if (lastStaff.length) {
      renderBlockedPlaceholders(total === 0 ? 'Cash is zero.' : 'No named staff rows remain.');
    }
    saveState();
    return;
  }
  calculate(true);
  saveState();
}
function calculate(silent) {
  const result = computeNightShift();
  if (!result.ok) {
    blockCalculation(result.reason, {
      inputError: !!result.inputError,
      showPlaceholder: true
    });
    if (!silent) alert(result.reason);
    return;
  }

  // Persist computation results to globals consumed by legacy callers
  // (person modal, tab indicators, home cards). This is the single place
  // globals are written for night shift.
  livePool = result.pool;
  lastStaff = result.staff;
  lastTotal = result.total;
  lastTotH = result.totH;
  lastRate = result.rate;
  lastLeftover = result.leftover;
  lastRemainderPool = result.remainderPool;
  const distResult = runDistribution(result.staff, result.pool, result.leftover);

  // Persist distribution outputs to globals consumed by person modal + dist tab.
  lastRemainderBills = distResult.remainderBills;
  lastDistributionError = distResult.distributionError;
  lastPoolAfter = distResult.poolAfter;
  _lastDistStaff = distResult.staffWithBills;
  renderNightShift(result, distResult);
  if ($('remainderSidebar')?.classList.contains('open')) renderRemainderSidebar();
  if (!silent) switchTab('summary', $('tb-summary'));
}
function _listIdForRowId(rowId) {
  const lists = ['staffList', 'nightServerList', 'bartenderList', 'serverList', 'supportList'];
  for (const lid of lists) {
    const el = document.querySelector('#' + lid + ' #staff' + rowId);
    if (el) return lid;
  }
  return 'staffList';
}

// ── Day shift: input collection ───────────────────────────────────────────────

function collectDayStaffRows(listId, role) {
  const rows = document.querySelectorAll('#' + listId + ' .staff-row-modal');
  const gcIn = ($('gc-in').value || '').trim();
  const gcOut = ($('gc-out').value || '').trim();
  // Use role-specific defaults, falling back to global
  const rDef = typeof roleDefaults !== 'undefined' && roleDefaults[role] || {};
  const defIn = rDef.in || gcIn;
  const defOut = rDef.out || gcOut;
  const result = [];
  rows.forEach(r => {
    const name = r.querySelector('[data-field="name"]').value.trim();
    const inEl = r.querySelector('[data-field="in"]');
    const outEl = r.querySelector('[data-field="out"]');
    const inStr = inEl.value.trim() || defIn;
    const outStr = outEl.value.trim() || defOut;
    const ctEl = r.querySelector('.sri-closer');
    if (!name) return;
    result.push({
      name,
      inStr,
      outStr,
      rowId: r.id.replace('staff', '').replace('server', ''),
      closer: ctEl ? ctEl.classList.contains('on') : false,
      role
    });
  });
  return result;
}
function getDayPoolCash() {
  return {
    morning: getDayPoolTotal('morning'),
    middle: getDayPoolTotal('middle'),
    party1: dayPools.party1.enabled ? getDayPoolTotal('party1') : null,
    party2: dayPools.party2.enabled ? getDayPoolTotal('party2') : null
  };
}
function getDayPoolTotal(poolId) {
  const pool = dayPools[poolId];
  if (!pool) return 0;
  if (pool.cashMode === 'nettotal') {
    const el = $('dp-net-' + poolId);
    const parsed = parseWholeNumberString(el?.value ?? '');
    return parsed.valid ? parsed.value : 0;
  }
  return ['100', '50', '20', '10', '5', '1'].reduce((sum, d) => {
    const el = $('dp-b' + d + '-' + poolId);
    const parsed = parseWholeNumberString(el?.value ?? '');
    return sum + (parsed.valid ? parsed.value * Number(d) : 0);
  }, 0);
}
function getDayPoolBills(poolId) {
  const pool = dayPools[poolId];
  if (!pool) return {
    100: 0,
    50: 0,
    20: 0,
    10: 0,
    5: 0,
    1: 0
  };
  if (pool.cashMode === 'nettotal') {
    const snap = pool.netBillSnapshot || {};
    const out = {};
    DENOMS.forEach(d => {
      const parsed = parseWholeNumberString(snap[d] ?? '');
      out[d] = parsed.valid ? parsed.value : 0;
    });
    return out;
  }
  const out = {};
  DENOMS.forEach(d => {
    const el = $('dp-b' + d + '-' + poolId);
    const parsed = parseWholeNumberString(el?.value ?? '');
    out[d] = parsed.valid ? parsed.value : 0;
  });
  return out;
}
function mergeBillPools(poolIds) {
  const merged = {
    100: 0,
    50: 0,
    20: 0,
    10: 0,
    5: 0,
    1: 0
  };
  for (const id of poolIds) {
    const bills = getDayPoolBills(id);
    DENOMS.forEach(d => {
      merged[d] += bills[d] || 0;
    });
  }
  return merged;
}

// ── Day shift: orchestration ──────────────────────────────────────────────────

function autoCalculateDay() {
  const bartenderRows = collectDayStaffRows('bartenderList', 'bartender');
  const serverRows = collectDayStaffRows('serverList', 'server');
  const partyConfig = {
    party1: {
      enabled: dayPools.party1.enabled,
      start: dayPools.party1.windowStart,
      end: dayPools.party1.windowEnd
    },
    party2: {
      enabled: dayPools.party2.enabled,
      start: dayPools.party2.windowStart,
      end: dayPools.party2.windowEnd
    }
  };
  const rawPoolCash = getDayPoolCash();

  // ── Support tip-outs: compute and subtract from each cut's total ──────────
  const supportRows = collectSupportRows();
  const supportTipOuts = computeAllSupportTipOuts(rawPoolCash, partyConfig, supportRows);

  // Reduce each cut's cash by its support tip-out total
  const poolCash = {
    ...rawPoolCash
  };
  Object.entries(supportTipOuts).forEach(([cutId, items]) => {
    const totalTipOut = items.reduce((s, x) => s + x.tipOut, 0);
    if (cutId === 'morning' || cutId === 'middle' || cutId === 'party1' || cutId === 'party2') {
      if (poolCash[cutId] !== null && poolCash[cutId] !== undefined) {
        poolCash[cutId] = Math.max(0, (poolCash[cutId] || 0) - totalTipOut);
      }
    }
  });
  if (!bartenderRows.length && !serverRows.length) {
    currentInputError = '';
    updateHomeLiveDay(null);
    clearStaleBanners();
    if (lastDayResult) renderBlockedPlaceholders('Add day shift staff.');
    saveState();
    return;
  }

  // Pure computation — no side effects
  const engineResult = calculateDayShift(bartenderRows, serverRows, poolCash, partyConfig);
  if (engineResult.error) {
    blockCalculation(engineResult.error, {
      inputError: true,
      showPlaceholder: true
    });
    saveState();
    return;
  }
  const activePoolIds = ['morning', 'middle'];
  if (dayPools.party1.enabled) activePoolIds.push('party1');
  if (dayPools.party2.enabled) activePoolIds.push('party2');

  // Build support people for distribution (have final = sum of tip-outs across cuts)
  const supportForDist = aggregateSupportForDist(supportTipOuts);

  // Distribute bills across ALL people (tipped staff + support)
  const allPeople = [...engineResult.people, ...supportForDist];

  // Compute ideal merged bills from actual person targets so the distribution
  // engine always gets the right small-bill mix regardless of cash entry mode.
  // (Net-total mode fills hidden per-bill inputs with targets=[total], which
  // produces zero $1s/$5s — wrong. Use real person finals instead.)
  const totalCash = activePoolIds.reduce((s, id) => s + (rawPoolCash[id] || 0), 0);
  const targets = [...allPeople.map(p => p.final).filter(v => v > 0), ...(engineResult.leftover > 0 ? [engineResult.leftover] : [])];
  const mergedBills = computeIdealBillsForTargets(totalCash, targets);
  const sc = allPeople.map(p => ({
    ...p,
    bills: {
      100: 0,
      50: 0,
      20: 0,
      10: 0,
      5: 0,
      1: 0
    },
    rem: p.final
  }));
  const dist = distributeBills(sc, mergedBills, engineResult.leftover);

  // Split sc back into regular staff and support
  const nRegular = engineResult.people.length;
  engineResult.people.forEach((p, i) => {
    p.bills = {
      ...sc[i].bills
    };
  });
  const supportWithBills = supportForDist.map((p, i) => ({
    ...p,
    bills: {
      ...sc[nRegular + i].bills
    },
    rem: sc[nRegular + i].rem
  }));
  engineResult.supportPeople = supportWithBills;
  const distResult = {
    staffWithBills: sc,
    // all people including support (for dist tab)
    remainderBills: dist.remainderBills,
    distributionError: dist.distributionError,
    poolAfter: dist.poolAfter,
    mergedBills
  };

  // Attach support tip-out data for rendering/modal use
  engineResult.supportTipOuts = supportTipOuts;
  engineResult.rawPoolCash = rawPoolCash;

  // Write globals — single location for day shift
  lastDayResult = engineResult;
  livePool = mergedBills;
  currentInputError = '';
  lastRemainderBills = distResult.remainderBills;
  lastDistributionError = distResult.distributionError;
  lastPoolAfter = distResult.poolAfter;
  // Expose all staff (including support) for person modal lookup
  _lastDistStaff = distResult.staffWithBills;

  // Render: pass data explicitly
  renderDaySummary(engineResult, distResult);
  renderDayDist(engineResult, distResult);
  updateHomeLiveDay(engineResult, distResult);
  updateSupportTipOutButtons();
  saveState();
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/calculator.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/cards.js
try { (() => {
function updateStockCards() {
  const total = getTotal();
  $('sc-total').textContent = '$' + total;
  const bc = DENOMS.map(d => ({
    d,
    n: getVal('b' + d)
  })).filter(x => x.n > 0);
  $('sc-billcount').textContent = bc.length ? bc.reduce((s, x) => s + x.n, 0) + ' bills' : '—';
  const rows = document.querySelectorAll('#staffList .staff-row-modal, #nightServerList .staff-row-modal');
  let nc = 0;
  rows.forEach(r => {
    if (r.querySelector('[data-field="name"]').value.trim()) nc++;
  });
  $('sc-staffcount').textContent = nc;
  const spc = $('staffPageCount');
  if (spc) spc.textContent = nc + (nc === 1 ? ' person' : ' people');
}

// updateHomeLive — night shift home dashboard
//
// Parameters:
//   staffArr — computed staff array, or null when nothing is ready
//   metrics  — { rate, totH, leftover, distributionError }
//              Falls back to globals when not supplied, so existing callers
//              that pass only staffArr continue to work.

function updateHomeLive(staffArr, metrics) {
  const sec = $('home-live-section');
  if (!sec) return;

  // Resolve metrics — prefer explicit params, fall back to globals.
  const rate = metrics?.rate ?? lastRate ?? 0;
  const totH = metrics?.totH ?? lastTotH ?? 0;
  const leftover = metrics?.leftover ?? lastLeftover ?? 0;
  const distributionError = metrics?.distributionError ?? lastDistributionError ?? '';
  const total = getTotal();
  const rows = document.querySelectorAll('#staffList .staff-row-modal, #nightServerList .staff-row-modal');
  let named = 0;
  rows.forEach(r => {
    if (r.querySelector('[data-field="name"]').value.trim()) named++;
  });
  const ready = total > 0 && !!staffArr && staffArr.length > 0;
  const distOk = ready && !distributionError;
  const remainderText = ready && leftover > 0 ? '$' + leftover : '—';
  const rateText = ready ? '$' + rate.toFixed(2) + '/hr' : '—';
  const paidText = ready ? '$' + staffArr.reduce((s, p) => s + p.final, 0) : '—';
  const statusText = currentInputError || (!total ? 'Enter cash to start' : !named ? 'Add staff to calculate' : !ready ? 'Fix staff hours to calculate' : distOk ? 'Distribution ready' : 'Adjust bill counts in Cash');
  const statusClass = currentInputError ? 'warn' : distOk ? 'ok' : ready ? 'warn' : 'idle';
  sec.innerHTML = `
    <div class="home-dashboard">
      <div class="home-status-card ${statusClass}">
        <div class="home-status-label">Session status</div>
        <div class="home-status-title">${statusText}</div>
        <div class="home-status-sub">${ready ? named + ' staff · ' + fmtHrs(totH) + ' hrs' : 'Cash and staff drive the live payout preview'}</div>
      </div>
      <div class="home-metric-grid">
        <div class="home-metric"><span>Rate</span><strong>${rateText}</strong></div>
        <div class="home-metric"><span>Paid out</span><strong>${paidText}</strong></div>
        <div class="home-metric"><span>Remainder</span><strong>${remainderText}</strong></div>
      </div>
      <div class="home-action-grid">
        <button onclick="switchTab('cash', $('tb-cash'))"><span>Cash</span><em>${total ? '$' + total : 'missing'}</em></button>
        <button onclick="switchTab('staff', $('tb-staff'))"><span>Staff</span><em>${named || 'missing'}</em></button>
        <button onclick="switchTab('summary', $('tb-summary'))"><span>Summary</span><em>${ready ? 'view payouts' : 'pending'}</em></button>
        <button onclick="switchTab('dist', $('tb-dist'))"><span>Dist</span><em>${distOk ? 'ready' : 'check bills'}</em></button>
      </div>
    </div>`;
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/cards.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/cash.js
try { (() => {
function getTotal() {
  return getVal('b100') * 100 + getVal('b50') * 50 + getVal('b20') * 20 + getVal('b10') * 10 + getVal('b5') * 5 + getVal('b1');
}
function getInputPool() {
  return {
    100: getVal('b100'),
    50: getVal('b50'),
    20: getVal('b20'),
    10: getVal('b10'),
    5: getVal('b5'),
    1: getVal('b1')
  };
}
function readBillInputSnapshot() {
  const snap = {};
  DENOMS.forEach(d => {
    snap[d] = $('b' + d)?.value ?? '';
  });
  return snap;
}
function writeBillInputSnapshot(snap) {
  DENOMS.forEach(d => {
    const el = $('b' + d);
    if (el) el.value = snap?.[d] ?? '';
  });
}
function snapshotCurrentCashMode() {
  if (cashMode === 'nettotal') {
    netTotalSnapshot = $('net-total-input')?.value ?? '';
    netBillSnapshot = readBillInputSnapshot();
  } else {
    perBillSnapshot = readBillInputSnapshot();
  }
}
function refreshCashTotals(total) {
  const pbot = $('cash-total-bottom');
  if (pbot) {
    pbot.textContent = '$' + total;
    pbot.className = 'cash-total-val' + (total ? '' : ' zero');
  }
}
function setCashError(message) {
  const el = $('cash-error');
  if (!el) return;
  el.textContent = message || '';
  el.classList.toggle('visible', !!message);
}
function validateCashInputs() {
  let valid = true;
  let total = 0;
  if (cashMode === 'nettotal') {
    const el = $('net-total-input');
    const parsed = parseWholeNumberString(el?.value ?? '');
    valid = parsed.valid;
    total = parsed.valid ? parsed.value : 0;
    setInputInvalid(el, !parsed.valid);
    DENOMS.forEach(d => setInputInvalid($('b' + d), false));
    setCashError(valid ? '' : 'Net total must be a whole-dollar amount.');
    return {
      valid,
      total,
      message: 'Net total must be a whole-dollar amount.'
    };
  }
  setInputInvalid($('net-total-input'), false);
  DENOMS.forEach(d => {
    const el = $('b' + d);
    const parsed = parseWholeNumberString(el?.value ?? '');
    setInputInvalid(el, !parsed.valid);
    if (!parsed.valid) valid = false;
    total += parsed.valid ? parsed.value * d : 0;
  });
  setCashError(valid ? '' : 'Bill counts must be whole numbers.');
  return {
    valid,
    total,
    message: 'Bill counts must be whole numbers.'
  };
}
function onBillsChange() {
  if (cashMode === 'nettotal') return;
  perBillSnapshot = readBillInputSnapshot();
  const validation = validateCashInputs();
  const total = validation.total;
  DENOMS.forEach(d => {
    const parsed = parseWholeNumberString($('b' + d)?.value ?? '');
    const n = parsed.valid ? parsed.value : 0,
      sub = n * d;
    const el = $('sub' + d);
    if (el) {
      el.textContent = parsed.valid ? sub > 0 ? '$' + sub : '—' : '!';
      el.className = 'cash-denom-subtotal' + (sub > 0 && parsed.valid ? '' : ' zero');
    }
  });
  refreshCashTotals(total);
  updateStockCards();
  updateTabIndicators();
  scheduleCalculate();
}
function setCashMode(mode) {
  if (mode !== cashMode) snapshotCurrentCashMode();
  cashMode = mode;
  document.querySelector('.cash-mode-toggle')?.classList.remove('open');
  const perBillEl = $('cash-per-bill');
  const netEl = $('cash-net-total');
  const btnPer = $('cmb-perbill');
  const btnNet = $('cmb-nettotal');
  if (perBillEl) perBillEl.style.display = mode === 'perbill' ? '' : 'none';
  if (netEl) netEl.style.display = mode === 'nettotal' ? '' : 'none';
  if (btnPer) btnPer.classList.toggle('active', mode === 'perbill');
  if (btnNet) btnNet.classList.toggle('active', mode === 'nettotal');
  if (mode === 'nettotal') {
    const inp = $('net-total-input');
    if (inp) inp.value = netTotalSnapshot || '';
    onNetTotalChange({
      fromModeSwitch: true
    });
    setTimeout(() => $('net-total-input')?.focus(), 50);
  } else {
    writeBillInputSnapshot(perBillSnapshot);
    onBillsChange();
  }
}
function onCashModeButtonClick(mode) {
  const toggle = document.querySelector('.cash-mode-toggle');
  if (mode === cashMode && toggle && !toggle.classList.contains('open')) {
    toggle.classList.add('open');
    return;
  }
  setCashMode(mode);
}
function getIdealTargetsForTotal(total) {
  const rows = document.querySelectorAll('#staffList .staff-row-modal, #nightServerList .staff-row-modal');
  const rawData = [];
  const gcIn = $('gc-in')?.value.trim() || '',
    gcOut = $('gc-out')?.value.trim() || '';
  rows.forEach(r => {
    const name = r.querySelector('[data-field="name"]')?.value.trim();
    if (!name) return;
    const rowId = r.id.replace('staff', '');
    const inStr = r.querySelector('[data-field="in"]')?.value.trim() || '';
    const outStr = r.querySelector('[data-field="out"]')?.value.trim() || '';
    const role = typeof getRoleForList === 'function' && typeof _listIdForRowId === 'function' ? getRoleForList(_listIdForRowId(rowId)) : 'bartender';
    const rDef = roleDefaults[role] || {};
    rawData.push({
      inStr,
      outStr,
      hasOut: !!outStr,
      rowId,
      role,
      rDef
    });
  });
  if (!rawData.length) return [total];
  rawData.forEach(r => {
    r.effIn = r.inStr || r.rDef.in || gcIn;
    r.effOut = r.outStr || r.rDef.out || gcOut;
  });
  let maxEo = 0;
  rawData.forEach(r => {
    if (!r.effIn || !r.effOut) return;
    const inParsed = parseTimeString(r.effIn),
      outParsed = parseTimeString(r.effOut);
    if (!inParsed.valid || !outParsed.valid || inParsed.empty || outParsed.empty) return;
    const i = inParsed.value,
      o = outParsed.value;
    const eo = o < i ? o + 12 : o;
    if (eo > maxEo) maxEo = eo;
  });
  const defaultIn = 5;
  const defaultOut = maxEo > 0 ? maxEo > 12 ? maxEo - 12 : maxEo : 2;
  const staff = rawData.map(r => {
    const inParsed = parseTimeString(r.effIn);
    const outParsed = parseTimeString(r.effOut);
    if (!inParsed.valid || !outParsed.valid) return null;
    const inVal = inParsed.empty ? defaultIn : inParsed.value;
    const outVal = outParsed.empty ? defaultOut : outParsed.value;
    let h = outVal - inVal;
    if (h < 0) h += 12;
    if (h <= 0 || h > 12) return null;
    const ctEl = document.getElementById('ct' + r.rowId);
    const manualCloser = ctEl ? ctEl.classList.contains('on') : false;
    return {
      h,
      closer: manualCloser || !r.hasOut
    };
  }).filter(Boolean);
  const totH = staff.reduce((s, p) => s + p.h, 0);
  if (totH <= 0) return [total];
  const rate = total / totH;
  staff.forEach(p => {
    p.base = Math.floor(p.h * rate);
    p.bonus = 0;
  });
  const floored = staff.reduce((s, p) => s + p.base, 0);
  const remainder = total - floored;
  const closers = staff.filter(p => p.closer);
  const perCloser = closers.length ? Math.floor(remainder / closers.length) : 0;
  const leftover = remainder - perCloser * closers.length;
  closers.forEach(p => {
    p.bonus = perCloser;
  });
  const targets = staff.map(p => p.base + p.bonus);
  if (leftover > 0) targets.push(leftover);
  return targets.filter(v => v > 0);
}
function computeIdealFromTotal(total) {
  const pool = {
    100: 0,
    50: 0,
    20: 0,
    10: 0,
    5: 0,
    1: 0
  };
  if (total <= 0) return {
    pool,
    targets: [],
    minimums: {
      ones: 0,
      fives: 0,
      tens: 0
    }
  };
  const targets = getIdealTargetsForTotal(total);
  const minOnes = targets.reduce((sum, amt) => sum + amt % 5, 0);
  const minMod10Val = targets.reduce((sum, amt) => sum + amt % 10, 0);
  const minFives = Math.max(0, (minMod10Val - minOnes) / 5);
  const minTens = targets.filter(amt => Math.floor(amt / 10) % 2 !== 0).length;
  const reserved = minOnes + minFives * 5 + minTens * 10;
  if (reserved <= total) {
    pool[1] = minOnes;
    pool[5] = minFives;
    pool[10] = minTens;
    pool[20] = Math.floor((total - reserved) / 20);
    return {
      pool,
      targets,
      minimums: {
        ones: minOnes,
        fives: minFives,
        tens: minTens
      }
    };
  }
  let rem = total;
  pool[20] = Math.floor(rem / 20);
  rem -= pool[20] * 20;
  pool[10] = Math.floor(rem / 10);
  rem -= pool[10] * 10;
  pool[5] = Math.floor(rem / 5);
  rem -= pool[5] * 5;
  pool[1] = rem;
  return {
    pool,
    targets,
    minimums: {
      ones: pool[1],
      fives: pool[5],
      tens: pool[10]
    }
  };
}

// Compute ideal bill breakdown for a given total and explicit target array.
// Unlike computeIdealFromTotal, this takes targets directly (no DOM read).
function computeIdealBillsForTargets(total, targets) {
  const pool = {
    100: 0,
    50: 0,
    20: 0,
    10: 0,
    5: 0,
    1: 0
  };
  if (total <= 0 || !targets.length) return pool;
  const minOnes = targets.reduce((s, amt) => s + amt % 5, 0);
  const minMod10Val = targets.reduce((s, amt) => s + amt % 10, 0);
  const minFives = Math.max(0, (minMod10Val - minOnes) / 5);
  const minTens = targets.filter(amt => Math.floor(amt / 10) % 2 !== 0).length;
  const reserved = minOnes + minFives * 5 + minTens * 10;
  if (reserved <= total) {
    pool[1] = minOnes;
    pool[5] = minFives;
    pool[10] = minTens;
    pool[20] = Math.floor((total - reserved) / 20);
    return pool;
  }
  // fallback: greedy
  let rem = total;
  pool[20] = Math.floor(rem / 20);
  rem -= pool[20] * 20;
  pool[10] = Math.floor(rem / 10);
  rem -= pool[10] * 10;
  pool[5] = Math.floor(rem / 5);
  rem -= pool[5] * 5;
  pool[1] = rem;
  return pool;
}
function renderNetBreakdown(total, ideal) {
  const bd = $('net-breakdown');
  if (!bd) return;
  if (total <= 0) {
    bd.innerHTML = '<div class="net-empty-hint">Enter total above to see ideal breakdown</div>';
    return;
  }
  const labels = {
    20: 'fill after minimums',
    1: 'minimum $1s',
    5: 'minimum $5s',
    10: 'minimum $10s'
  };
  const denomRows = [20, 1, 5, 10].map(d => {
    const n = ideal.pool[d] || 0;
    if (!n) return '';
    const sub = n * d;
    return `<div class="net-denom-row"><span class="ndr-lbl">$${d}</span><span class="ndr-times">×</span><span class="ndr-count">${n}<span class="ndr-note">${labels[d]}</span></span><span class="ndr-sub">$${sub}</span></div>`;
  }).filter(Boolean).join('');
  const targetLabel = ideal.targets.length > 1 ? ideal.targets.length + ' targets incl. remainder' : 'single total target';
  bd.innerHTML = `<div class="net-breakdown-hdr">Ideal breakdown · $${total} total · ${targetLabel}</div>${denomRows || '<div class="net-empty-hint">—</div>'}`;
}
function refreshNetTotalBreakdown() {
  if (cashMode !== 'nettotal') return;
  isUpdatingNetTotal = true;
  onNetTotalChange();
  isUpdatingNetTotal = false;
}

// ── Bill trade helpers ────────────────────────────────────────────────────────

// Computes a "trade-up" plan: convert excess $1s/$5s/$10s into $20s.
// Returns { newPool, delta, new20s } or null if no $20s can be gained.
function computeTradeUp(pool, req) {
  const minFives = Math.max(0, (req.minOneFiveValue - req.minOnes) / 5);
  const minTens = Math.max(0, (req.minOneFiveTenValue - req.minOneFiveValue) / 10);
  const excessOnes = Math.max(0, (pool[1] || 0) - req.minOnes);
  const excessFives = Math.max(0, (pool[5] || 0) - minFives);
  const excessTens = Math.max(0, (pool[10] || 0) - minTens);
  const totalExcess = excessOnes + excessFives * 5 + excessTens * 10;
  const new20s = Math.floor(totalExcess / 20);
  if (new20s <= 0) return null;

  // Distribute remaining excess (< $20) back into smallest denominations
  let rem = totalExcess - new20s * 20;
  const keepExtra10 = Math.min(excessTens, Math.floor(rem / 10));
  rem -= keepExtra10 * 10;
  const keepExtra5 = Math.min(excessFives, Math.floor(rem / 5));
  rem -= keepExtra5 * 5;

  // Build new pool by removing only the excess that was traded, then adding back kept amounts.
  // Using pool[d] - excess[d] + kept[d] instead of min[d] + kept[d] prevents phantom bills
  // when pool[d] < min[d] (distribution still succeeded via other denominations).
  const newPool = {
    100: pool[100] || 0,
    50: pool[50] || 0,
    20: (pool[20] || 0) + new20s,
    10: (pool[10] || 0) - excessTens + keepExtra10,
    5: (pool[5] || 0) - excessFives + keepExtra5,
    1: (pool[1] || 0) - excessOnes + rem
  };
  const delta = {};
  DENOMS.forEach(d => {
    delta[d] = (newPool[d] || 0) - (pool[d] || 0);
  });
  return {
    newPool,
    delta,
    new20s
  };
}

// Writes a new bill count pool to the per-bill inputs and triggers recalculation.
// Switches to per-bill mode if currently in net-total mode.
function applyBillTradeToInputs(newPool) {
  if (cashMode !== 'perbill') setCashMode('perbill');
  DENOMS.forEach(d => {
    const el = $('b' + d);
    if (el) el.value = (newPool[d] || 0) > 0 ? String(newPool[d]) : '';
  });
  perBillSnapshot = readBillInputSnapshot();
  onBillsChange();
}
function onNetTotalChange() {
  const validation = validateCashInputs();
  const total = validation.total;
  netTotalSnapshot = $('net-total-input').value || '';
  if (!validation.valid) {
    DENOMS.forEach(d => {
      const el = $('b' + d);
      if (el) el.value = '';
    });
    netBillSnapshot = readBillInputSnapshot();
    refreshCashTotals(0);
    updateStockCards();
    updateTabIndicators();
    renderNetBreakdown(0, {
      pool: {},
      targets: []
    });
    if (!isUpdatingNetTotal) scheduleCalculate();
    return;
  }
  const ideal = computeIdealFromTotal(total);
  const pool = ideal.pool;
  DENOMS.forEach(d => {
    const el = $('b' + d);
    if (el) el.value = (pool[d] || 0) > 0 ? pool[d] : '';
  });
  netBillSnapshot = readBillInputSnapshot();
  refreshCashTotals(total);
  updateStockCards();
  updateTabIndicators();
  renderNetBreakdown(total, ideal);
  if (!isUpdatingNetTotal) scheduleCalculate();
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/cash.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/cash_day.js
try { (() => {
// Day shift multi-pool cash entry handlers

function getDayPoolActiveIds() {
  const ids = ['morning', 'middle'];
  if (dayPools.party1.enabled) ids.push('party1');
  if (dayPools.party2.enabled) ids.push('party2');
  return ids;
}

// ── Per-pool bill input handlers ──────────────────────────────────────────────

function onDayPoolBillsChange(poolId) {
  const pool = dayPools[poolId];
  if (!pool || pool.cashMode === 'nettotal') return;
  DENOMS.forEach(d => {
    const el = $('dp-b' + d + '-' + poolId);
    const subEl = $('dp-sub' + d + '-' + poolId);
    if (!el || !subEl) return;
    const parsed = parseWholeNumberString(el.value ?? '');
    const n = parsed.valid ? parsed.value : 0;
    const sub = n * d;
    subEl.textContent = parsed.valid ? sub > 0 ? '$' + sub : '—' : '!';
    subEl.className = 'dp-subtotal' + (sub > 0 && parsed.valid ? '' : ' zero');
    setInputInvalid(el, !parsed.valid);
  });

  // Snapshot so re-renders restore the live values
  pool.perBillSnapshot = {};
  DENOMS.forEach(d => {
    const el = $('dp-b' + d + '-' + poolId);
    pool.perBillSnapshot[d] = el ? el.value || '' : '';
  });
  refreshDayPoolTotal(poolId);
  scheduleCalculate();
}
function onDayPoolNetTotalChange(poolId) {
  const pool = dayPools[poolId];
  if (!pool) return;
  const el = $('dp-net-' + poolId);
  const parsed = parseWholeNumberString(el?.value ?? '');
  const total = parsed.valid ? parsed.value : 0;
  setInputInvalid(el, !parsed.valid);
  pool.netTotalSnapshot = el?.value || '';
  if (parsed.valid && total > 0) {
    const ideal = computeIdealFromTotal(total);
    DENOMS.forEach(d => {
      const hiddenEl = $('dp-b' + d + '-' + poolId);
      if (hiddenEl) hiddenEl.value = (ideal.pool[d] || 0) > 0 ? ideal.pool[d] : '';
    });
    pool.netBillSnapshot = {};
    DENOMS.forEach(d => {
      pool.netBillSnapshot[d] = $('dp-b' + d + '-' + poolId)?.value ?? '';
    });
  } else {
    DENOMS.forEach(d => {
      const hiddenEl = $('dp-b' + d + '-' + poolId);
      if (hiddenEl) hiddenEl.value = '';
    });
    pool.netBillSnapshot = {
      100: '',
      50: '',
      20: '',
      10: '',
      5: '',
      1: ''
    };
  }
  refreshDayPoolTotal(poolId);
  scheduleCalculate();
}
function refreshDayPoolTotal(poolId) {
  const total = getDayPoolTotal(poolId);
  const el = $('dp-total-' + poolId);
  if (el) {
    el.textContent = '$' + total;
    el.className = 'dp-pool-total' + (total ? '' : ' zero');
  }
}
function setDayPoolCashMode(poolId, mode) {
  const pool = dayPools[poolId];
  if (!pool) return;
  pool.cashMode = mode;
  const perBillEl = $('dp-perbill-' + poolId);
  const netEl = $('dp-nettotal-' + poolId);
  const btnPer = $('dp-cmb-per-' + poolId);
  const btnNet = $('dp-cmb-net-' + poolId);
  if (perBillEl) perBillEl.style.display = mode === 'perbill' ? '' : 'none';
  if (netEl) netEl.style.display = mode === 'nettotal' ? '' : 'none';
  if (btnPer) btnPer.classList.toggle('active', mode === 'perbill');
  if (btnNet) btnNet.classList.toggle('active', mode === 'nettotal');
  if (mode === 'nettotal') {
    const netInput = $('dp-net-' + poolId);
    if (netInput) netInput.value = pool.netTotalSnapshot || '';
    onDayPoolNetTotalChange(poolId);
  } else {
    DENOMS.forEach(d => {
      const el = $('dp-b' + d + '-' + poolId);
      if (el) el.value = pool.perBillSnapshot?.[d] ?? '';
    });
    onDayPoolBillsChange(poolId);
  }
}

// ── Party pool toggle ─────────────────────────────────────────────────────────

function togglePartyPool(pid) {
  dayPools[pid].enabled = !dayPools[pid].enabled;
  // Auto-open newly enabled party pools
  if (dayPools[pid].enabled) selectedDayPool = pid;
  renderDayPoolCashPanels();
  autoCalculate();
}
function onPartyWindowChange(pid, field) {
  const el = $('dp-pw-' + field + '-' + pid);
  if (!el) return;
  dayPools[pid]['window' + (field === 'start' ? 'Start' : 'End')] = el.value.trim();
  // Keep the collapsed-state header subtitle in sync while typing
  const card = $('dp-card-' + pid);
  if (card) {
    const sub = card.querySelector('.dp-window-auto');
    if (sub) {
      const pool = dayPools[pid];
      sub.textContent = (pool.windowStart || '?') + ' \u2013 ' + (pool.windowEnd || '?');
    }
  }
  autoCalculate();
}

// ── Accordion: expand one pool at a time without re-rendering ─────────────────

function selectDayPool(poolId) {
  if (selectedDayPool === poolId) return;
  selectedDayPool = poolId;
  document.querySelectorAll('#day-cash-panels .dp-pool-card').forEach(card => {
    const id = card.id.replace('dp-card-', '');
    const open = id === poolId;
    card.classList.toggle('dp-pool-card--open', open);
    const body = card.querySelector('.dp-pool-body');
    if (body) body.style.display = open ? '' : 'none';
  });
}

// ── Render the day shift cash tab ─────────────────────────────────────────────

function renderDayPoolCashPanels() {
  const container = $('day-cash-panels');
  if (!container) return;
  const poolDefs = [{
    id: 'morning',
    label: 'Morning Cut',
    windowLabel: 'Earliest in \u2192 last server out',
    optional: false
  }, {
    id: 'middle',
    label: 'Middle Cut',
    windowLabel: 'Morning end \u2192 latest bartender out',
    optional: false
  }, {
    id: 'party1',
    label: 'Party 1',
    windowLabel: null,
    optional: true
  }, {
    id: 'party2',
    label: 'Party 2',
    windowLabel: null,
    optional: true
  }];
  container.innerHTML = poolDefs.map(def => {
    const pool = dayPools[def.id];

    // Disabled optional pool — render an add-button placeholder
    if (def.optional && !pool.enabled) {
      return `<button class="dp-add-party-btn" onclick="togglePartyPool('${def.id}')">+ Add ${def.label}</button>`;
    }
    const isOpen = selectedDayPool === def.id;
    const total = getDayPoolTotal(def.id);
    pool.cashMode = 'nettotal'; // day shift always uses net total

    // Header subtitle — auto label for fixed pools, live times for party pools
    const headerSub = def.optional ? escapeHTML((pool.windowStart || '?') + ' \u2013 ' + (pool.windowEnd || '?')) : def.windowLabel;

    // Window time inputs — only rendered inside the body of optional pools
    const windowBodyHTML = def.optional ? `<div class="dp-window-row">
          <div class="dp-window-field">
            <span class="dp-window-lbl">Start</span>
            <input class="dp-window-input" id="dp-pw-start-${def.id}" type="text" inputmode="decimal"
              placeholder="e.g. 11" value="${escapeHTML(pool.windowStart || '')}"
              oninput="onPartyWindowChange('${def.id}','start')">
          </div>
          <span class="dp-window-sep">&ndash;</span>
          <div class="dp-window-field">
            <span class="dp-window-lbl">End</span>
            <input class="dp-window-input" id="dp-pw-end-${def.id}" type="text" inputmode="decimal"
              placeholder="e.g. 3" value="${escapeHTML(pool.windowEnd || '')}"
              oninput="onPartyWindowChange('${def.id}','end')">
          </div>
          <button class="dp-remove-party-btn" onclick="togglePartyPool('${def.id}')" title="Remove">&#x2715;</button>
        </div>` : '';

    // Per-bill denomination rows
    const perBillRows = DENOMS.map(d => `<div class="dp-denom-row">
        <div class="dp-denom-label">$${d}</div>
        <input class="dp-denom-input" id="dp-b${d}-${def.id}" type="number" min="0" step="1"
          placeholder="0" inputmode="numeric"
          value="${escapeHTML(pool.perBillSnapshot?.[d] ?? '')}"
          oninput="onDayPoolBillsChange('${def.id}')">
        <div class="dp-subtotal zero" id="dp-sub${d}-${def.id}">&mdash;</div>
      </div>`).join('');

    // Net total input
    const netRow = `<div class="dp-net-row">
      <span class="dp-net-sign">$</span>
      <input type="number" id="dp-net-${def.id}" class="dp-net-input"
        min="0" step="1" placeholder="0" inputmode="numeric"
        value="${escapeHTML(pool.netTotalSnapshot || '')}"
        oninput="onDayPoolNetTotalChange('${def.id}')">
    </div>`;
    return `<div class="dp-pool-card${isOpen ? ' dp-pool-card--open' : ''}" id="dp-card-${def.id}">
      <button class="dp-pool-card-hdr" onclick="selectDayPool('${def.id}')">
        <div class="dp-pool-card-left">
          <span class="dp-pool-card-name">${escapeHTML(def.label)}</span>
          <span class="dp-window-auto">${headerSub}</span>
        </div>
        <div class="dp-pool-hdr-right">
          <span class="dp-pool-total${total ? '' : ' zero'}" id="dp-total-${def.id}">$${total}</span>
          <span class="dp-pool-chevron"></span>
        </div>
      </button>
      <div class="dp-pool-body"${isOpen ? '' : ' style="display:none"'}>
        ${windowBodyHTML}
        <div id="dp-perbill-${def.id}" style="display:none">${perBillRows}</div>
        <div id="dp-nettotal-${def.id}">${netRow}</div>
        <button class="dp-support-btn" id="dp-sup-btn-${def.id}" onclick="openSupportTipOutModal('${def.id}')" style="display:none">Support Tip-Out</button>
      </div>
    </div>`;
  }).join('');
  getDayPoolActiveIds().forEach(id => refreshDayPoolTotal(id));
}

// ── Support tip-out button visibility ────────────────────────────────────────

function updateSupportTipOutButtons() {
  const activeIds = getDayPoolActiveIds();
  activeIds.forEach(cutId => {
    const btn = $('dp-sup-btn-' + cutId);
    if (!btn) return;
    const rows = document.querySelectorAll('#supportList .staff-row-modal');
    const hasAssigned = [...rows].some(r => {
      const rowId = r.id.replace('staff', '');
      const name = r.querySelector('[data-field="name"]').value.trim();
      return name && (supportCutAssignments[rowId] || []).includes(cutId);
    });
    btn.style.display = hasAssigned ? '' : 'none';
    if (hasAssigned) {
      const tipOuts = lastDayResult?.supportTipOuts?.[cutId] || [];
      const total = tipOuts.reduce((s, x) => s + x.tipOut, 0);
      btn.textContent = total > 0 ? 'Support Tip-Out · $' + total + ' out' : 'Support Tip-Out';
    }
  });
}

// ── Day shift stock card update ───────────────────────────────────────────────

function updateDayStockCards() {
  const total = getDayPoolActiveIds().reduce((s, id) => s + getDayPoolTotal(id), 0);
  const sc = $('sc-total');
  if (sc) sc.textContent = '$' + total;
  const scSub = $('sc-billcount');
  if (scSub) scSub.textContent = total > 0 ? 'combined' : '—';

  // Use bartenderList for day-shift bartenders (not staffList, which is night-shift only)
  const bartRows = document.querySelectorAll('#bartenderList .staff-row-modal');
  const servRows = document.querySelectorAll('#serverList .staff-row-modal');
  let named = 0;
  [...bartRows, ...servRows].forEach(r => {
    if (r.querySelector('[data-field="name"]').value.trim()) named++;
  });
  const sc2 = $('sc-staffcount');
  if (sc2) sc2.textContent = named;
  const spc = $('staffPageCount2');
  if (spc) spc.textContent = named + (named === 1 ? ' person' : ' people');
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/cash_day.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/dist.js
try { (() => {
// renderDist — night shift distribution tab
//
// Parameters:
//   swb      — staff array post-distribution (has .bills assigned)
//   pa       — poolAfter (bill counts remaining)
//   distCtx  — { remainderBills, distributionError, leftover, pool }
//
// No computation globals are read here. All data arrives via parameters.

// Pending trade state — set by renderDistTable, consumed by apply button handlers.
let _pendingTradeUp = null;
let _pendingTradeDown = null;
function renderDist(swb, pa, distCtx) {
  _lastDistStaff = swb;
  renderDistTable(swb, pa, distCtx);
}

// ── Close Time Bills sidebar ──────────────────────────────────────────────────

// Persisted state across re-renders inside the open sidebar
let _ctRange = 3; // steps from center on each side (pinch adjusts this)
let _ctCenter = 2;
let _ctRoleData = null;
let _ctTotal = 0;
let _ctPool = null;
function openCloseTimeSidebar() {
  if (!lastStaff || !lastStaff.length || !lastTotal) return;
  const {
    rawData,
    gcIn,
    gcOut
  } = collectNamedStaffRows();
  if (!rawData.length) return;
  _ctPool = livePool || {};
  _ctTotal = lastTotal;

  // In-time uses defaults (start time stable).
  // fixedOut is ONLY the individual's own typed value — blank means "flex with close time".
  _ctRoleData = rawData.map(r => {
    const role = getRoleForList(_listIdForRowId(r.rowId));
    const rDef = roleDefaults[role] || {};
    return {
      name: r.name,
      effIn: r.inStr || rDef.in || gcIn,
      fixedOut: r.outStr || ''
    };
  }).filter(r => r.name);
  const gcOutParsed = parseTimeString(gcOut);
  _ctCenter = gcOutParsed.valid && !gcOutParsed.empty ? gcOutParsed.value : 2;
  _ctRenderSidebar();
  openModal('closeTimeSidebar');
}
function closeCloseTimeSidebar() {
  closeModal('closeTimeSidebar');
}

// Select a column — commit that time as the new gc-out, re-center the table on it
function selectCloseTime(t) {
  const el = $('gc-out');
  if (el) {
    el.value = String(t);
    onDefaultTimesChange();
  }
  _ctCenter = t;
  _ctRenderSidebar();
}
function _ctRenderSidebar() {
  // Build time list centered on _ctCenter with _ctRange steps on each side
  const times = [];
  for (let i = -_ctRange; i <= _ctRange; i++) {
    const t = Math.round((_ctCenter + i * 0.25) * 4) / 4;
    if (t > 0 && t <= 12) times.push(t);
  }
  const cols = times.map(ct => _computeForCloseTime(_ctRoleData, _ctTotal, ct, _ctPool));
  const nowIdx = times.findIndex(t => Math.abs(t - _ctCenter) < 0.01);
  const body = $('close-time-body');
  body.innerHTML = _renderCloseTimeTable(times, cols, _ctPool, nowIdx);

  // Attach pinch listener to the scroll wrapper
  const wrap = body.querySelector('.ct-scroll-wrap');
  if (!wrap) return;
  let pinchStartDist = 0;
  wrap.addEventListener('touchstart', e => {
    if (e.touches.length === 2) pinchStartDist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
  }, {
    passive: true
  });
  wrap.addEventListener('touchmove', e => {
    if (e.touches.length !== 2 || !pinchStartDist) return;
    const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
    if (d - pinchStartDist > 28) {
      _ctRange = Math.min(_ctRange + 1, 9);
      pinchStartDist = d;
      _ctRenderSidebar();
    } else if (pinchStartDist - d > 28) {
      _ctRange = Math.max(_ctRange - 1, 1);
      pinchStartDist = d;
      _ctRenderSidebar();
    }
  }, {
    passive: true
  });
  wrap.addEventListener('touchend', () => {
    pinchStartDist = 0;
  }, {
    passive: true
  });
}
function _fmtCloseTime(t) {
  let hr = Math.floor(t),
    mn = Math.round((t - hr) * 60);
  if (mn === 60) {
    hr++;
    mn = 0;
  }
  const h12 = hr % 12 || 12;
  return h12 + (mn > 0 ? ':' + (mn < 10 ? '0' : '') + mn : '') + (t <= 5 ? 'a' : 'p');
}
function _computeForCloseTime(roleData, total, closeTime, pool) {
  const defaultIn = 5;
  const staff = roleData.map(r => {
    const effOut = r.fixedOut || closeTime;
    const inParsed = parseTimeString(r.effIn);
    const outParsed = parseTimeString(String(effOut));
    const inVal = inParsed.valid && !inParsed.empty ? inParsed.value : defaultIn;
    const outVal = outParsed.valid && !outParsed.empty ? outParsed.value : closeTime;
    let h = outVal - inVal;
    if (h < 0) h += 12;
    const eo = outVal < inVal ? outVal + 12 : outVal;
    return {
      n: r.name,
      h,
      eo,
      base: 0,
      bonus: 0,
      closer: false,
      final: 0
    };
  }).filter(p => p.h > 0 && p.h <= 12);
  if (!staff.length) return null;
  const totH = staff.reduce((s, p) => s + p.h, 0);
  if (!totH) return null;
  const rate = total / totH;
  staff.forEach(p => {
    p.base = Math.floor(p.h * rate);
  });
  const floored = staff.reduce((s, p) => s + p.base, 0);
  const remainder = total - floored;
  const peakEo = Math.max(...staff.map(p => p.eo));
  const closers = staff.filter(p => p.eo >= peakEo);
  const perCloser = closers.length ? Math.floor(remainder / closers.length) : 0;
  const leftover = remainder - perCloser * closers.length;
  closers.forEach(p => {
    p.bonus = perCloser;
    p.closer = true;
  });
  staff.forEach(p => {
    p.final = p.base + p.bonus;
  });
  const req = getSmallBillRequirements(staff, pool, leftover);
  return {
    staff,
    req,
    minFives: Math.max(0, (req.minOneFiveValue - req.minOnes) / 5),
    minTens: Math.max(0, (req.minOneFiveTenValue - req.minOneFiveValue) / 10),
    leftover
  };
}
function _renderCloseTimeTable(times, cols, pool, nowIdx) {
  const names = _ctRoleData.map(r => r.name);

  // nowCls(i): extra class string for cells in the "current" column
  const n = i => i === nowIdx ? ' ct-col-now' : '';

  // Header — time columns are tappable to select that close time
  const thCells = times.map((t, i) => `<th class="${i === nowIdx ? 'ct-th-now' : 'ct-th-sel'}" onclick="selectCloseTime(${t})">${_fmtCloseTime(t)}</th>`).join('');

  // Per-person tip rows
  const personRows = names.map(name => {
    const cells = cols.map((col, i) => {
      if (!col) return `<td class="zero${n(i)}">—</td>`;
      const p = col.staff.find(s => s.n === name);
      if (!p) return `<td class="zero${n(i)}">—</td>`;
      return `<td class="${p.closer ? 'ct-closer' : 'ct-person'}${n(i)}">$${p.final}</td>`;
    }).join('');
    return `<tr><td class="ct-lbl">${escapeHTML(name)}</td>${cells}</tr>`;
  }).join('');

  // Remainder row
  const remRow = `<tr class="ct-rem-row"><td class="ct-lbl">Rem</td>` + cols.map((col, i) => {
    if (!col || !col.leftover) return `<td class="zero${n(i)}">—</td>`;
    return `<td class="ct-rem${n(i)}">$${col.leftover}</td>`;
  }).join('') + '</tr>';

  // Bill rows — only $1s count; $1+5 and $1+5+10 cumulative values
  const avail15 = (pool[1] || 0) + (pool[5] || 0) * 5;
  const avail1510 = avail15 + (pool[10] || 0) * 10;
  function dataRow(label, getCls, getVal) {
    return `<tr><td class="ct-lbl">${label}</td>` + cols.map((col, i) => {
      if (!col) return `<td class="zero${n(i)}">—</td>`;
      const {
        cls,
        val
      } = getVal(col);
      return `<td class="${cls}${n(i)}">${val}</td>`;
    }).join('') + '</tr>';
  }
  const onesRow = dataRow('$1s', null, col => {
    const v = col.req.minOnes,
      ok = v <= (pool[1] || 0);
    return {
      cls: ok ? 'ct-ok' : 'ct-short',
      val: v
    };
  });
  const val15Row = dataRow('$1+5', null, col => {
    const v = col.req.minOneFiveValue,
      ok = v <= avail15;
    return {
      cls: ok ? 'ct-ok' : 'ct-short',
      val: '$' + v
    };
  });
  const val1510Row = dataRow('$1+5+10', null, col => {
    const v = col.req.minOneFiveTenValue,
      ok = v <= avail1510;
    return {
      cls: ok ? 'ct-ok' : 'ct-short',
      val: '$' + v
    };
  });
  const divRow = label => `<tr class="ct-sect-hdr"><td colspan="${times.length + 1}">${label}</td></tr>`;
  return `<div class="ct-scroll-wrap"><table class="ct-tbl">
    <thead><tr><th class="ct-lbl-th"></th>${thCells}</tr></thead>
    <tbody>
      ${personRows}${remRow}
      ${divRow('Bills')}
      ${onesRow}${val15Row}${val1510Row}
    </tbody>
  </table></div>`;
}
function renderDistTable(swb, poolAfter, distCtx) {
  const sb = $('stale-dist');
  if (sb) sb.classList.remove('visible');

  // Unpack context; fall back to globals so existing callers still work.
  const remainderBills = distCtx?.remainderBills ?? lastRemainderBills ?? {};
  const distributionError = distCtx?.distributionError ?? lastDistributionError ?? '';
  const leftover = distCtx?.leftover ?? lastLeftover ?? 0;
  const pool = distCtx?.pool ?? livePool ?? {};
  const unpaid = swb.reduce((s, p) => s + Math.max(0, p.rem || 0), 0);
  const remPV = poolValue(remainderBills);
  const hasRemShort = leftover > 0 && remPV !== leftover;
  const hasErr = !!distributionError || unpaid > 0 || hasRemShort;
  const errMsg = distributionError || (unpaid > 0 ? 'Distribution short $' + unpaid : 'Remainder not representable by available bills');
  const req = getSmallBillRequirements(swb, pool, leftover);
  const reqHTML = renderRequirementSummary(req, pool);

  // Compute both trade options independently — trade-down for shortage, trade-up for excess.
  _pendingTradeDown = hasErr ? previewSmallBillTrades(swb, pool, leftover) : null;
  _pendingTradeUp = !hasErr ? computeTradeUp(pool, req) : null;
  const tradeDownHTML = renderTradeDownCard(_pendingTradeDown, pool);
  const tradeUpHTML = _pendingTradeUp ? renderTradeUpCard(_pendingTradeUp, pool) : '';
  const actionBtns = '<div class="dist-action-grid">' + '<button class="ct-open-btn" onclick="openCloseTimeSidebar()">⏱ Close Time</button>' + '<button class="ct-open-btn rem-open-btn" onclick="openRemainderSidebar()">Remainder</button>' + '</div>';
  if (hasErr) {
    const previewTableHTML = _pendingTradeDown ? '<div class="dist-preview-label">Distribution after simple trades</div>' + renderDistTableMarkup(_pendingTradeDown.staff, {
      remainderBills: _pendingTradeDown.remainderBills,
      leftover,
      preview: true
    }) : '';
    $('dist-content').innerHTML = `<div class="warn-box" style="margin-bottom:10px">⚠ ${escapeHTML(errMsg)}` + (_pendingTradeDown ? '' : ` <button onclick="switchTab('cash',$('tb-cash'))" style="background:none;border:none;color:inherit;text-decoration:underline;cursor:pointer;padding:0;font:inherit;font-weight:700">→ Go to Cash</button>`) + `</div>` + reqHTML + tradeDownHTML + previewTableHTML + actionBtns;
    return;
  }
  $('dist-content').innerHTML = reqHTML + tradeUpHTML + renderDistTableMarkup(swb, {
    remainderBills,
    leftover
  }) + actionBtns;
}

// ── Requirement summary ───────────────────────────────────────────────────────

function renderRequirementSummary(req, pool) {
  const minFives = Math.max(0, (req.minOneFiveValue - req.minOnes) / 5);
  const minTens = Math.max(0, (req.minOneFiveTenValue - req.minOneFiveValue) / 10);
  const shortFives = Math.max(0, minFives - (pool[5] || 0));
  const shortTens = Math.max(0, minTens - (pool[10] || 0));
  function reqRow(label, need, have, short) {
    const ok = short <= 0;
    const cls = ok ? 'req-row--ok' : 'req-row--short';
    const badge = ok ? '<span class="req-badge req-badge--ok">covered</span>' : `<span class="req-badge req-badge--short">short&nbsp;${short}</span>`;
    return `<div class="req-row ${cls}">
      <span class="req-row-lbl">${label}</span>
      <span class="req-row-need">${Math.ceil(need)}&nbsp;min</span>
      <span class="req-row-have">${have}&nbsp;have</span>
      ${badge}
    </div>`;
  }
  return `<div class="req-summary">
    <div class="req-summary-hdr">Minimum small bills</div>
    ${reqRow('$1s', req.minOnes, pool[1] || 0, req.onesShort)}
    ${reqRow('$5s', minFives, pool[5] || 0, shortFives)}
    ${reqRow('$10s', minTens, pool[10] || 0, shortTens)}
  </div>`;
}

// ── Apply pending trades ──────────────────────────────────────────────────────

function applyPendingTradeUp() {
  if (_pendingTradeUp) applyBillTradeToInputs(_pendingTradeUp.newPool);
}
function applyPendingTradeDown() {
  if (_pendingTradeDown) applyBillTradeToInputs(_pendingTradeDown.pool);
}

// ── Trade card: up (consolidate excess small bills → $20s) ───────────────────

function renderTradeUpCard(tradeUp, pool) {
  const nowCells = DENOMS.map(d => renderCountCell(pool[d] || 0)).join('');
  const deltaCells = DENOMS.map(d => {
    const delta = tradeUp.delta[d] || 0;
    if (delta === 0) return '<td class="zero">—</td>';
    return `<td class="${delta > 0 ? 'delta-pos' : 'delta-neg'}">${delta > 0 ? '+' : ''}${delta}</td>`;
  }).join('');
  const afterCells = DENOMS.map(d => renderCountCell(tradeUp.newPool[d] || 0)).join('');
  const nowTotal = DENOMS.reduce((s, d) => s + (pool[d] || 0) * d, 0);
  const deltaTotal = DENOMS.reduce((s, d) => s + (tradeUp.delta[d] || 0) * d, 0);
  const afterTotal = DENOMS.reduce((s, d) => s + (tradeUp.newPool[d] || 0) * d, 0);
  const deltaTotalCell = deltaTotal === 0 ? '<td class="delta-pos grand-total">$0</td>' : `<td class="${deltaTotal > 0 ? 'delta-pos' : 'delta-neg'} grand-total">${deltaTotal > 0 ? '+$' : '-$'}${Math.abs(deltaTotal)}</td>`;
  return `<div class="trade-card trade-card--up">
    <div class="trade-card-hdr">
      <div class="trade-card-info">
        <div class="trade-card-title">↑ Consolidate → $20s</div>
        <div class="trade-card-sub">Swap excess small bills for ${tradeUp.new20s}&nbsp;×&nbsp;$20. Cash tab updates on apply.</div>
      </div>
      <button class="trade-apply-btn" onclick="applyPendingTradeUp()">Apply</button>
    </div>
    <div class="dist-tbl-wrap dist-trade-table">
      <table class="dist-tbl">
        ${renderDistColGroup()}
        <thead><tr><th></th>${DENOMS.map(d => `<th><span class="dist-tbl-denom">${d}</span></th>`).join('')}<th class="total-col"><span class="dist-tbl-denom" style="color:var(--text2)">TOT</span></th></tr></thead>
        <tbody>
          <tr><td>Now</td>${nowCells}<td class="person-total">$${nowTotal}</td></tr>
          <tr><td>Delta</td>${deltaCells}${deltaTotalCell}</tr>
          <tr><td>After</td>${afterCells}<td class="person-total">$${afterTotal}</td></tr>
        </tbody>
      </table>
    </div>
  </div>`;
}

// ── Trade card: down (break large bills → small change) ───────────────────────

function renderTradeDownCard(preview, pool) {
  if (!preview) return '';
  const nowPool = pool ?? livePool ?? {};
  const nowCells = DENOMS.map(d => renderCountCell(nowPool[d] || 0)).join('');
  const deltaCells = DENOMS.map(d => {
    const delta = preview.deltas[d] || 0;
    if (delta === 0) return '<td class="zero">—</td>';
    return `<td class="${delta > 0 ? 'delta-pos' : 'delta-neg'}">${delta > 0 ? '+' : ''}${delta}</td>`;
  }).join('');
  const afterCells = DENOMS.map(d => renderCountCell(preview.pool[d] || 0)).join('');
  const tradeItems = preview.trades.length ? `<ul>${preview.trades.map(t => `<li>${escapeHTML(t)}</li>`).join('')}</ul>` : '';
  const nowTotal = DENOMS.reduce((s, d) => s + (nowPool[d] || 0) * d, 0);
  const deltaTotal = DENOMS.reduce((s, d) => s + (preview.deltas[d] || 0) * d, 0);
  const afterTotal = DENOMS.reduce((s, d) => s + (preview.pool[d] || 0) * d, 0);
  const deltaTotalCell = deltaTotal === 0 ? '<td class="delta-pos grand-total">$0</td>' : `<td class="${deltaTotal > 0 ? 'delta-pos' : 'delta-neg'} grand-total">${deltaTotal > 0 ? '+$' : '-$'}${Math.abs(deltaTotal)}</td>`;
  return `<div class="trade-card trade-card--down">
    <div class="trade-card-hdr">
      <div class="trade-card-info">
        <div class="trade-card-title">↓ Break Bills → Small Change</div>
        <div class="trade-card-sub">Counts not saved until applied.</div>
      </div>
      <button class="trade-apply-btn" onclick="applyPendingTradeDown()">Apply</button>
    </div>
    <div class="trade-card-trades">${tradeItems}</div>
    <div class="dist-tbl-wrap dist-trade-table">
      <table class="dist-tbl">
        ${renderDistColGroup()}
        <thead><tr><th></th>${DENOMS.map(d => `<th><span class="dist-tbl-denom">${d}</span></th>`).join('')}<th class="total-col"><span class="dist-tbl-denom" style="color:var(--text2)">TOT</span></th></tr></thead>
        <tbody>
          <tr><td>Now</td>${nowCells}<td class="person-total">$${nowTotal}</td></tr>
          <tr><td>Delta</td>${deltaCells}${deltaTotalCell}</tr>
          <tr><td>After</td>${afterCells}<td class="person-total">$${afterTotal}</td></tr>
        </tbody>
      </table>
    </div>
  </div>`;
}

// ── Distribution table markup ──────────────────────────────────────────────────

function renderCountCell(count) {
  return count > 0 ? `<td class="has-bills">${count}</td>` : '<td class="zero">—</td>';
}
function renderDistColGroup() {
  return '<colgroup><col class="dist-name-col">' + DENOMS.map(() => '<col class="dist-bill-col">').join('') + '<col class="dist-total-col"></colgroup>';
}
function renderDistTableMarkup(swb, options = {}) {
  const hCols = DENOMS.map(d => `<th><span class="dist-tbl-denom">${d}</span></th>`).join('') + '<th class="total-col"><span class="dist-tbl-denom" style="color:var(--text2)">TOT</span></th>';
  const sumRem = options.leftover || 0;
  const previewLabel = options.preview ? '<div class="dist-preview-label">Distribution after simple trades</div>' : '';
  const rows = swb.map(p => {
    const safe = escapeHTML(p.n);
    const pt = DENOMS.reduce((s, d) => s + (p.bills[d] || 0) * d, 0);
    const cols = DENOMS.map(d => {
      const n = p.bills[d] || 0;
      return n > 0 ? `<td class="has-bills">${n}</td>` : `<td class="zero">—</td>`;
    }).join('');
    return `<tr><td>${safe}</td>${cols}<td class="person-total">$${pt}</td></tr>`;
  }).join('');
  let remRow = '',
    remBills = {},
    remAT = 0;
  if (sumRem > 0) {
    remBills = options.remainderBills || {};
    remAT = DENOMS.reduce((s, d) => s + (remBills[d] || 0) * d, 0);
    const rc = DENOMS.map(d => {
      const n = remBills[d] || 0;
      return n > 0 ? `<td style="color:var(--muted);font-weight:600;font-size:.74rem">${n}</td>` : `<td class="zero">—</td>`;
    }).join('');
    remRow = `<tr class="dist-rem-row"><td>Rem</td>${rc}<td style="color:var(--muted);font-weight:600;border-left:1px solid var(--border);font-size:.74rem">$${sumRem}</td></tr>`;
  }
  const dtCols = DENOMS.map(d => {
    const t = swb.reduce((s, p) => s + (p.bills[d] || 0), 0) + (remBills[d] || 0);
    return t > 0 ? `<td style="color:var(--gold)">${t}</td>` : `<td class="zero">—</td>`;
  }).join('');
  const dGT = swb.reduce((s, p) => s + DENOMS.reduce((ss, d) => ss + (p.bills[d] || 0) * d, 0), 0) + remAT;
  const totalRow = `<tr class="dist-totals-row"><td>Total</td>${dtCols}<td class="grand-total">$${dGT}</td></tr>`;
  return previewLabel + `<div class="dist-tbl-wrap"><table class="dist-tbl">${renderDistColGroup()}<thead><tr><th>Name</th>${hCols}</tr></thead><tbody>${rows}${remRow}</tbody><tfoot>${totalRow}</tfoot></table></div>`;
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/dist.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/engine.js
try { (() => {
// Core calculation engine — pure functions, no DOM access

function blankBills() {
  return {
    100: 0,
    50: 0,
    20: 0,
    10: 0,
    5: 0,
    1: 0
  };
}
function normalizePool(pool) {
  const out = blankBills();
  DENOMS.forEach(d => {
    const parsed = parseWholeNumberString(pool?.[d] ?? '');
    out[d] = parsed.valid ? parsed.value : 0;
  });
  return out;
}
function buildDistributionSlots(staffArr, leftoverAmount) {
  const slots = staffArr.map(p => ({
    ref: p,
    orig: p.final,
    target: p.final,
    bills: blankBills(),
    isRemainder: false
  }));
  if (leftoverAmount > 0) {
    slots.push({
      ref: null,
      orig: leftoverAmount,
      target: leftoverAmount,
      bills: blankBills(),
      isRemainder: true
    });
  }
  return slots;
}
function getSmallBillRequirementsForSlots(slots, poolIn) {
  const pool = normalizePool(poolIn);
  const targets = slots.map(s => s.orig);
  const oddTenSlots = slots.filter(s => Math.floor(s.orig / 10) % 2 !== 0);
  const fiftyEligibleOddTenSlots = oddTenSlots.filter(s => s.orig >= 50).length;
  const fiftyCoverage = Math.min(pool[50] || 0, fiftyEligibleOddTenSlots);
  const minOnes = targets.reduce((sum, target) => sum + target % 5, 0);
  const minOneFiveValue = targets.reduce((sum, target) => sum + target % 10, 0);
  const minOneFiveTenRaw = targets.reduce((sum, target) => sum + target % 20, 0);
  const minOneFiveTenValue = Math.max(minOneFiveValue, minOneFiveTenRaw - fiftyCoverage * 10);
  const availableOnes = pool[1] || 0;
  const availableOneFiveValue = availableOnes + (pool[5] || 0) * 5;
  const availableOneFiveTenValue = availableOneFiveValue + (pool[10] || 0) * 10;
  return {
    minOnes,
    availableOnes,
    onesShort: Math.max(0, minOnes - availableOnes),
    minOneFiveValue,
    availableOneFiveValue,
    oneFiveShort: Math.max(0, minOneFiveValue - availableOneFiveValue),
    minOneFiveTenValue,
    availableOneFiveTenValue,
    oneFiveTenShort: Math.max(0, minOneFiveTenValue - availableOneFiveTenValue),
    oddTenCount: oddTenSlots.length,
    fiftyEligibleOddTenCount: fiftyEligibleOddTenSlots,
    fiftyCoverage,
    fiftyCoverageValue: fiftyCoverage * 10
  };
}
function getSmallBillRequirements(staffArr, poolIn, leftoverAmount) {
  return getSmallBillRequirementsForSlots(buildDistributionSlots(staffArr, leftoverAmount || 0), poolIn);
}
function previewSmallBillTrades(staffArr, poolIn, leftoverAmount) {
  const sourcePool = normalizePool(poolIn);
  const targetTotal = staffArr.reduce((sum, p) => sum + (p.final || 0), 0) + (leftoverAmount || 0);
  if (poolValue(sourcePool) !== targetTotal) return null;
  const adjustedPool = normalizePool(sourcePool);
  const deltas = blankBills();
  const trades = [];
  const slots = buildDistributionSlots(staffArr, leftoverAmount || 0);
  function describeBundle(bundle) {
    return DENOMS.filter(d => (bundle[d] || 0) > 0).map(d => (bundle[d] || 0) + ' x $' + d).join(' + ');
  }
  function applyBreak(from, bundle) {
    if ((adjustedPool[from] || 0) <= 0) return false;
    adjustedPool[from]--;
    deltas[from]--;
    DENOMS.forEach(d => {
      const count = bundle[d] || 0;
      if (count <= 0) return;
      adjustedPool[d] += count;
      deltas[d] += count;
    });
    trades.push('Break 1 x $' + from + ' into ' + describeBundle(bundle) + '.');
    return true;
  }
  function breakForOnes(from) {
    const bundle = blankBills();
    if (from === 5) bundle[1] = 5;
    if (from === 10) {
      bundle[5] = 1;
      bundle[1] = 5;
    }
    if (from === 20) {
      bundle[10] = 1;
      bundle[5] = 1;
      bundle[1] = 5;
    }
    if (from === 50) {
      bundle[20] = 2;
      bundle[5] = 1;
      bundle[1] = 5;
    }
    if (from === 100) {
      bundle[50] = 1;
      bundle[20] = 2;
      bundle[5] = 1;
      bundle[1] = 5;
    }
    return applyBreak(from, bundle);
  }
  function breakForFives(from) {
    const bundle = blankBills();
    if (from === 10) bundle[5] = 2;
    if (from === 20) {
      bundle[10] = 1;
      bundle[5] = 2;
    }
    if (from === 50) {
      bundle[20] = 2;
      bundle[5] = 2;
    }
    if (from === 100) {
      bundle[50] = 1;
      bundle[20] = 2;
      bundle[5] = 2;
    }
    return applyBreak(from, bundle);
  }
  function breakForTens(from) {
    const bundle = blankBills();
    if (from === 20) bundle[10] = 2;
    if (from === 50) bundle[10] = 5;
    if (from === 100) {
      bundle[50] = 1;
      bundle[10] = 5;
    }
    return applyBreak(from, bundle);
  }
  function chooseDonor(candidates) {
    return candidates.find(d => (adjustedPool[d] || 0) > 0) || null;
  }
  function trySolve() {
    const previewStaff = staffArr.map(p => ({
      ...p,
      bills: blankBills(),
      rem: p.final
    }));
    const result = calculateV19Pipeline(previewStaff, adjustedPool, leftoverAmount || 0);
    if (!result.success) return null;
    return {
      staff: previewStaff,
      pool: {
        ...adjustedPool
      },
      poolAfter: result.poolAfter,
      remainderBills: result.remainderBills || blankBills(),
      deltas: {
        ...deltas
      },
      trades: [...trades],
      requirementsBefore: getSmallBillRequirementsForSlots(slots, sourcePool),
      requirementsAfter: getSmallBillRequirementsForSlots(slots, adjustedPool)
    };
  }
  let guard = 0;
  while (getSmallBillRequirementsForSlots(slots, adjustedPool).onesShort > 0 && guard++ < 40) {
    const donor = chooseDonor([5, 10, 20, 50, 100]);
    if (!donor || !breakForOnes(donor)) return null;
  }
  while (getSmallBillRequirementsForSlots(slots, adjustedPool).oneFiveShort > 0 && guard++ < 80) {
    const donor = chooseDonor([10, 20, 50, 100]);
    if (!donor || !breakForFives(donor)) return null;
  }
  while (getSmallBillRequirementsForSlots(slots, adjustedPool).oneFiveTenShort > 0 && guard++ < 120) {
    const donor = chooseDonor([20, 50, 100]);
    if (!donor || !breakForTens(donor)) return null;
  }
  const solved = trySolve();
  if (solved) return solved;
  const fallbackBreaks = [{
    from: 5,
    bundle: {
      1: 5
    }
  }, {
    from: 10,
    bundle: {
      5: 2
    }
  }, {
    from: 20,
    bundle: {
      10: 2
    }
  }, {
    from: 50,
    bundle: {
      10: 5
    }
  }, {
    from: 100,
    bundle: {
      20: 5
    }
  }];
  for (let i = 0; i < 30; i++) {
    const next = fallbackBreaks.find(item => (adjustedPool[item.from] || 0) > 0);
    if (!next || !applyBreak(next.from, {
      ...blankBills(),
      ...next.bundle
    })) break;
    const retry = trySolve();
    if (retry) return retry;
  }
  return null;
}
function calculateV19Pipeline(staffArr, poolIn, leftoverAmount) {
  const pool = normalizePool(poolIn);
  const slots = buildDistributionSlots(staffArr, leftoverAmount || 0);
  const preflight = runPreflight(slots, pool);
  if (!preflight.ok) return {
    success: false,
    msg: preflight.msg,
    poolAfter: pool,
    remainderBills: blankBills()
  };
  const preferred = buildPreferredPath(slots, pool);
  const poolAfterSieve = preferred ? null : runCascadingSieve(slots, pool);
  const paths = preferred ? [preferred] : runDFS(slots, poolAfterSieve);
  if (!paths.length) {
    return {
      success: false,
      msg: 'Exact change impossible with current bills. Adjust bill counts in Cash.',
      poolAfter: poolAfterSieve,
      remainderBills: blankBills()
    };
  }
  const best = preferred || gradePaths(paths);
  best.slots.forEach(s => {
    if (s.isRemainder) return;
    s.ref.bills = {
      ...s.bills
    };
    s.ref.rem = 0;
  });
  const remainderSlot = best.slots.find(s => s.isRemainder);
  return {
    success: true,
    msg: '',
    poolAfter: best.leftoverPool,
    remainderBills: remainderSlot ? {
      ...remainderSlot.bills
    } : blankBills()
  };
}
function runPreflight(slots, pool) {
  const targetTotal = slots.reduce((sum, s) => sum + s.target, 0);
  const cashTotal = poolValue(pool);
  if (cashTotal < targetTotal) {
    return {
      ok: false,
      msg: 'Cash on hand is short $' + (targetTotal - cashTotal) + '.'
    };
  }
  const needs = getSmallBillRequirementsForSlots(slots, pool);
  if (needs.onesShort > 0) {
    return {
      ok: false,
      msg: 'Need ' + needs.onesShort + ' more $1s.'
    };
  }
  if (needs.oneFiveShort > 0) {
    return {
      ok: false,
      msg: 'Need $' + needs.oneFiveShort + ' more in $1s/$5s.'
    };
  }
  if (needs.oneFiveTenShort > 0) {
    return {
      ok: false,
      msg: 'Need $' + needs.oneFiveTenShort + ' more in $1s/$5s/$10s after $50s.'
    };
  }
  return {
    ok: true
  };
}
function runCascadingSieve(slots, poolIn) {
  const p = normalizePool(poolIn);
  slots.forEach(s => {
    const ones = s.target % 5;
    if (ones > 0) {
      s.bills[1] += ones;
      p[1] -= ones;
      s.target -= ones;
    }
  });
  let bundledOnes = Math.floor((p[1] || 0) / 5);
  slots.forEach(s => {
    if (s.target % 10 !== 5) return;
    if (bundledOnes > 0) {
      s.bills[1] += 5;
      p[1] -= 5;
      bundledOnes--;
      s.target -= 5;
    } else if ((p[5] || 0) > 0) {
      s.bills[5] += 1;
      p[5] -= 1;
      s.target -= 5;
    }
  });
  let bundledFives = Math.floor(((p[5] || 0) + bundledOnes) / 2);
  slots.forEach(s => {
    const isOddTens = Math.floor(s.target / 10) % 2 !== 0;
    if (!isOddTens || bundledFives <= 0) return;
    if ((p[5] || 0) >= 2) {
      s.bills[5] += 2;
      p[5] -= 2;
      s.target -= 10;
      bundledFives--;
    } else if ((p[5] || 0) === 1 && (p[1] || 0) >= 5) {
      s.bills[5] += 1;
      p[5] -= 1;
      s.bills[1] += 5;
      p[1] -= 5;
      s.target -= 10;
      bundledFives--;
    } else if ((p[1] || 0) >= 10) {
      s.bills[1] += 10;
      p[1] -= 10;
      s.target -= 10;
      bundledFives--;
    }
  });
  function assignSmallBundle(s, value) {
    const maxFives = Math.min(Math.floor(value / 5), p[5] || 0);
    for (let fives = maxFives; fives >= 0; fives--) {
      const ones = value - fives * 5;
      if ((p[1] || 0) < ones) continue;
      s.bills[5] += fives;
      p[5] -= fives;
      s.bills[1] += ones;
      p[1] -= ones;
      s.target -= value;
      return true;
    }
    return false;
  }
  [20, 10].forEach(value => {
    let assigned = true;
    while (assigned) {
      assigned = false;
      const next = slots.filter(s => s.target >= value).sort((a, b) => a.target - b.target)[0];
      if (next && assignSmallBundle(next, value)) assigned = true;
    }
  });
  return p;
}
function cloneDistributionSlots(slots) {
  return slots.map(s => ({
    ref: s.ref,
    orig: s.orig,
    target: s.target,
    bills: {
      ...s.bills
    },
    isRemainder: !!s.isRemainder
  }));
}
function apportionDenomCounts(slots, denom, available) {
  const caps = slots.map(s => Math.floor(s.target / denom));
  const totalCap = caps.reduce((sum, cap) => sum + cap, 0);
  const count = Math.min(Math.max(0, available || 0), totalCap);
  const counts = slots.map(() => 0);
  if (count <= 0) return counts;
  const totalOrig = slots.reduce((sum, s) => sum + (s.orig || 0), 0) || 1;
  const shares = slots.map((s, i) => ({
    i,
    raw: (s.orig || 0) / totalOrig * count
  }));
  let assigned = 0;
  for (const share of shares) {
    counts[share.i] = Math.min(caps[share.i], Math.floor(share.raw));
    assigned += counts[share.i];
  }
  while (assigned < count) {
    const before = assigned;
    for (const next of shares.filter(share => counts[share.i] < caps[share.i]).sort((a, b) => {
      const aFrac = a.raw - Math.floor(a.raw);
      const bFrac = b.raw - Math.floor(b.raw);
      return bFrac - aFrac || (slots[b.i].orig || 0) - (slots[a.i].orig || 0) || (slots[b.i].target || 0) - (slots[a.i].target || 0) || a.i - b.i;
    })) {
      if (assigned >= count) break;
      counts[next.i]++;
      assigned++;
    }
    if (assigned === before) break;
  }
  return counts;
}

// Preferred exact path: apportion $100s/$50s first, then solve lower
// denominations in descending order so each stage leaves balanced remainders.
// If it cannot solve exactly, the DFS below still handles the edge case.
function buildPreferredPath(slotsIn, poolIn) {
  const slots = cloneDistributionSlots(slotsIn);
  const pool = normalizePool(poolIn);
  function give(s, d, n) {
    const use = Math.min(n, pool[d] || 0, Math.floor(s.target / d));
    if (use <= 0) return 0;
    s.bills[d] += use;
    pool[d] -= use;
    s.target -= use * d;
    return use;
  }
  const hundredCounts = apportionDenomCounts(slots, 100, pool[100] || 0);
  hundredCounts.forEach((count, i) => give(slots[i], 100, count));
  if (!applyBestFiftyPlan(slots, pool)) return null;
  if (!assignLowerDenomsBalanced(slots, pool)) return null;
  return {
    slots,
    leftoverPool: pool
  };
}
function applyBestFiftyPlan(slots, pool) {
  const count = pool[50] || 0;
  if (count <= 0) return true;
  const caps = slots.map(s => Math.floor(s.target / 50));
  if (caps.reduce((sum, cap) => sum + cap, 0) < count) return false;
  const counts = slots.map(() => 0);
  let best = null;
  function lowerCapacityOk(residuals) {
    if (residuals.reduce((sum, rem) => sum + Math.floor(rem / 20), 0) < (pool[20] || 0)) return false;
    if (residuals.reduce((sum, rem) => sum + Math.floor(rem / 10), 0) < (pool[10] || 0)) return false;
    if (residuals.reduce((sum, rem) => sum + Math.floor(rem / 5), 0) < (pool[5] || 0)) return false;
    return true;
  }
  function scorePlan() {
    const staffSlots = slots.filter(s => !s.isRemainder);
    const totalOrig = staffSlots.reduce((sum, s) => sum + (s.orig || 0), 0) || 1;
    const high50 = staffSlots.map(s => {
      const i = slots.indexOf(s);
      return (s.bills[100] || 0) * 100 + counts[i] * 50;
    });
    const totalHigh50 = high50.reduce((sum, value) => sum + value, 0);
    return staffSlots.reduce((sum, s, i) => {
      const ideal = (s.orig || 0) / totalOrig * totalHigh50;
      return sum + Math.abs(high50[i] - ideal);
    }, 0);
  }
  function search(i, remaining) {
    if (i === slots.length) {
      if (remaining !== 0) return;
      const residuals = slots.map((s, idx) => s.target - counts[idx] * 50);
      if (!lowerCapacityOk(residuals)) return;
      const score = scorePlan();
      if (!best || score < best.score) best = {
        counts: [...counts],
        score
      };
      return;
    }
    const restCap = caps.slice(i + 1).reduce((sum, cap) => sum + cap, 0);
    const minUse = Math.max(0, remaining - restCap);
    const maxUse = Math.min(caps[i], remaining);
    for (let use = minUse; use <= maxUse; use++) {
      counts[i] = use;
      search(i + 1, remaining - use);
    }
    counts[i] = 0;
  }
  search(0, count);
  if (!best) return false;
  best.counts.forEach((n, i) => {
    slots[i].bills[50] += n;
    slots[i].target -= n * 50;
  });
  pool[50] = 0;
  return true;
}
function assignLowerDenomsBalanced(slots, pool) {
  for (const d of [20, 10, 5]) {
    if (!assignDenomBalanced(slots, pool, d)) return false;
  }
  const onesNeeded = slots.reduce((sum, s) => sum + s.target, 0);
  if (onesNeeded !== (pool[1] || 0)) return false;
  for (const s of slots) {
    if (s.target < 0) return false;
    s.bills[1] += s.target;
    pool[1] -= s.target;
    s.target = 0;
  }
  return slots.every(s => s.target === 0);
}
function assignDenomBalanced(slots, pool, denom) {
  const count = pool[denom] || 0;
  if (count <= 0) return true;
  const caps = slots.map(s => Math.floor(s.target / denom));
  if (caps.reduce((sum, cap) => sum + cap, 0) < count) return false;
  const counts = slots.map(() => 0);
  let best = null;
  function lowerCapacityOk(residuals) {
    if (denom === 20 && residuals.reduce((sum, rem) => sum + Math.floor(rem / 10), 0) < (pool[10] || 0)) return false;
    if ((denom === 20 || denom === 10) && residuals.reduce((sum, rem) => sum + Math.floor(rem / 5), 0) < (pool[5] || 0)) return false;
    return true;
  }
  function scoreResiduals(residuals) {
    const scored = residuals.filter((_, i) => !slots[i].isRemainder);
    const avg = scored.reduce((sum, rem) => sum + rem, 0) / (scored.length || 1);
    const range = Math.max(...scored) - Math.min(...scored);
    const deviation = scored.reduce((sum, rem) => sum + Math.abs(rem - avg), 0);
    const billSpread = Math.max(...counts) - Math.min(...counts);
    return range * 10000 + deviation * 100 + billSpread;
  }
  function search(i, remaining) {
    if (i === slots.length) {
      if (remaining !== 0) return;
      const residuals = slots.map((s, idx) => s.target - counts[idx] * denom);
      if (!lowerCapacityOk(residuals)) return;
      const score = scoreResiduals(residuals);
      if (!best || score < best.score) best = {
        counts: [...counts],
        score
      };
      return;
    }
    const restCap = caps.slice(i + 1).reduce((sum, cap) => sum + cap, 0);
    const minUse = Math.max(0, remaining - restCap);
    const maxUse = Math.min(caps[i], remaining);
    for (let use = minUse; use <= maxUse; use++) {
      counts[i] = use;
      search(i + 1, remaining - use);
    }
    counts[i] = 0;
  }
  search(0, count);
  if (!best) return false;
  best.counts.forEach((n, i) => {
    slots[i].bills[denom] += n;
    slots[i].target -= n * denom;
  });
  pool[denom] = 0;
  return true;
}
function smallBillCount(s) {
  return (s.bills[1] || 0) + (s.bills[5] || 0) + (s.bills[10] || 0);
}
function smallBillValue(s) {
  return (s.bills[1] || 0) + (s.bills[5] || 0) * 5 + (s.bills[10] || 0) * 10;
}
function removeSmallValueWithOrder(s, value, order) {
  const removed = blankBills();
  let remaining = value;
  for (const d of order) {
    const use = Math.min(s.bills[d] || 0, Math.floor(remaining / d));
    if (use <= 0) continue;
    s.bills[d] -= use;
    removed[d] = use;
    remaining -= use * d;
  }
  if (remaining !== 0) {
    for (const d of [1, 5, 10]) {
      s.bills[d] += removed[d];
    }
    return null;
  }
  return removed;
}
function removeSmallValue(s, value) {
  return removeSmallValueWithOrder(s, value, [10, 5, 1]);
}
function addSmallBundle(s, bundle) {
  [1, 5, 10].forEach(d => {
    s.bills[d] += bundle[d] || 0;
  });
}
function smallSpreadScore(slots) {
  const staffSlots = slots.filter(s => !s.isRemainder);
  const range = values => Math.max(...values) - Math.min(...values);
  const totalOrig = staffSlots.reduce((sum, s) => sum + (s.orig || 0), 0) || 1;
  const totalSmallValue = staffSlots.reduce((sum, s) => sum + smallBillValue(s), 0);
  const valuePenalty = staffSlots.reduce((sum, s) => {
    const ideal = (s.orig || 0) / totalOrig * totalSmallValue;
    return sum + Math.abs(smallBillValue(s) - ideal);
  }, 0);
  return valuePenalty * 10000 + range(staffSlots.map(smallBillValue)) * 1000 + range(staffSlots.map(smallBillCount)) * 100 + range(staffSlots.map(s => s.bills[10] || 0)) * 100 + range(staffSlots.map(s => s.bills[5] || 0)) * 100 + range(staffSlots.map(s => s.bills[1] || 0));
}
function rebalanceTwentiesAndSmallBills(slots) {
  let improved = true;
  while (improved) {
    improved = false;
    const currentScore = smallSpreadScore(slots);
    let best = null;
    for (const smallHeavy of slots.filter(s => !s.isRemainder && smallBillValue(s) >= 20)) {
      for (const twentyDonor of slots.filter(s => !s.isRemainder && s !== smallHeavy && (s.bills[20] || 0) > 0)) {
        const bundle = removeSmallValue(smallHeavy, 20);
        if (!bundle) continue;
        smallHeavy.bills[20]++;
        twentyDonor.bills[20]--;
        addSmallBundle(twentyDonor, bundle);
        const score = smallSpreadScore(slots);
        if (score < currentScore && (!best || score < best.score)) {
          best = {
            smallHeavy,
            twentyDonor,
            bundle: {
              ...bundle
            },
            score
          };
        }
        [1, 5, 10].forEach(d => {
          twentyDonor.bills[d] -= bundle[d] || 0;
        });
        twentyDonor.bills[20]++;
        smallHeavy.bills[20]--;
        addSmallBundle(smallHeavy, bundle);
      }
    }
    if (best) {
      const bundle = removeSmallValue(best.smallHeavy, 20);
      best.smallHeavy.bills[20]++;
      best.twentyDonor.bills[20]--;
      addSmallBundle(best.twentyDonor, bundle);
      improved = true;
    }
  }
  rebalanceSmallDenominationBundles(slots);
}
function subtractSmallBundle(s, bundle) {
  [1, 5, 10].forEach(d => {
    s.bills[d] -= bundle[d] || 0;
  });
}
function rebalanceSmallDenominationBundles(slots) {
  let improved = true;
  while (improved) {
    improved = false;
    const currentScore = smallSpreadScore(slots);
    let best = null;
    for (const swapValue of [20, 10, 5]) {
      for (const highBundleSlot of slots.filter(s => !s.isRemainder && smallBillValue(s) >= swapValue)) {
        for (const lowBundleSlot of slots.filter(s => !s.isRemainder && s !== highBundleSlot && smallBillValue(s) >= swapValue)) {
          const highBundle = removeSmallValueWithOrder(highBundleSlot, swapValue, [10, 5, 1]);
          if (!highBundle) continue;
          const lowBundle = removeSmallValueWithOrder(lowBundleSlot, swapValue, [1, 5, 10]);
          if (!lowBundle) {
            addSmallBundle(highBundleSlot, highBundle);
            continue;
          }
          addSmallBundle(highBundleSlot, lowBundle);
          addSmallBundle(lowBundleSlot, highBundle);
          const score = smallSpreadScore(slots);
          if (score < currentScore && (!best || score < best.score)) {
            best = {
              highBundleSlot,
              lowBundleSlot,
              highBundle: {
                ...highBundle
              },
              lowBundle: {
                ...lowBundle
              },
              swapValue,
              score
            };
          }
          subtractSmallBundle(lowBundleSlot, highBundle);
          subtractSmallBundle(highBundleSlot, lowBundle);
          addSmallBundle(lowBundleSlot, lowBundle);
          addSmallBundle(highBundleSlot, highBundle);
        }
      }
    }
    if (best) {
      const highBundle = removeSmallValueWithOrder(best.highBundleSlot, best.swapValue, [10, 5, 1]);
      const lowBundle = removeSmallValueWithOrder(best.lowBundleSlot, best.swapValue, [1, 5, 10]);
      addSmallBundle(best.highBundleSlot, lowBundle);
      addSmallBundle(best.lowBundleSlot, highBundle);
      improved = true;
    }
  }
}
function runDFS(slots, poolIn) {
  const validPaths = [];
  const bigDenoms = [100, 50, 20, 10];
  const pool = normalizePool(poolIn);
  const sortedIdxs = slots.map((_, i) => i).sort((a, b) => slots[b].target - slots[a].target);
  function search(pIdx) {
    if (validPaths.length >= 100) return;
    if (pIdx === slots.length) {
      validPaths.push({
        slots: slots.map(s => ({
          ...s,
          bills: {
            ...s.bills
          }
        })),
        leftoverPool: {
          ...pool
        }
      });
      return;
    }
    const person = slots[sortedIdxs[pIdx]];
    if (person.target === 0) {
      search(pIdx + 1);
      return;
    }
    function fillPerson(targetVal, dIdx) {
      if (targetVal === 0) {
        search(pIdx + 1);
        return;
      }
      if (dIdx >= bigDenoms.length) return;
      const d = bigDenoms[dIdx];
      const maxUse = Math.min(pool[d] || 0, Math.floor(targetVal / d));
      for (let use = maxUse; use >= 0; use--) {
        person.bills[d] += use;
        pool[d] -= use;
        fillPerson(targetVal - use * d, dIdx + 1);
        person.bills[d] -= use;
        pool[d] += use;
      }
    }
    fillPerson(person.target, 0);
  }
  search(0);
  return validPaths;
}
function gradePaths(paths) {
  let bestPath = null;
  let lowestPenalty = Infinity;
  for (const path of paths) {
    let penalty = 0;
    const totalCounts = [];
    const smallBracketCounts = [];
    const mediumBracketCounts = [];
    for (const s of path.slots) {
      const idealBig = Math.floor(s.orig / 100);
      const actualBig = (s.bills[100] || 0) + ((s.bills[50] || 0) > 1 ? 1 : 0);
      penalty += Math.abs(idealBig - actualBig) * 2;
      const count1 = s.bills[1] || 0,
        count5 = s.bills[5] || 0,
        count10 = s.bills[10] || 0;
      const count20 = s.bills[20] || 0,
        count50 = s.bills[50] || 0,
        count100 = s.bills[100] || 0;
      totalCounts.push(count1 + count5 + count10 + count20 + count50 + count100);
      smallBracketCounts.push(count1 + count5 + count10);
      mediumBracketCounts.push(count1 + count5 + count10 + count20);
    }
    penalty += (Math.max(...totalCounts) - Math.min(...totalCounts)) * 10;
    penalty += (Math.max(...smallBracketCounts) - Math.min(...smallBracketCounts)) * 8;
    penalty += (Math.max(...mediumBracketCounts) - Math.min(...mediumBracketCounts)) * 5;
    if (penalty < lowestPenalty) {
      lowestPenalty = penalty;
      bestPath = path;
    }
  }
  return bestPath;
}
function distributeBills(staff, available, leftover) {
  staff.forEach(p => {
    p.bills = blankBills();
    p.rem = p.final;
  });
  const result = calculateV19Pipeline(staff, available, leftover || 0);
  return {
    poolAfter: result.poolAfter || normalizePool(available),
    remainderBills: result.remainderBills || blankBills(),
    distributionError: result.success ? '' : result.msg
  };
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/engine.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/engine.test.js
try { (() => {
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const ctx = {
  console
};
vm.createContext(ctx);
vm.runInContext('const DENOMS=[100,50,20,10,5,1];\n' + fs.readFileSync(path.join(__dirname, 'utils.js'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, 'engine.js'), 'utf8'), ctx);
function totalBills(bills) {
  return [100, 50, 20, 10, 5, 1].reduce((sum, d) => sum + (bills[d] || 0) * d, 0);
}
function runExample(pool) {
  const names = ['a', 'bc', 'c', 'd', 'aa'];
  const finals = [439, 487, 475, 390, 488];
  const staff = finals.map((final, i) => ({
    n: names[i],
    final
  }));
  const result = ctx.distributeBills(staff, pool, 1);
  const remainderBills = result.remainderBills;
  staff.forEach(person => {
    assert.strictEqual(totalBills(person.bills), person.final, person.n + ' total');
  });
  assert.strictEqual(totalBills(remainderBills), 1, 'remainder total');
  return staff;
}
function highHundredsAndFifties(person) {
  return (person.bills[100] || 0) * 100 + (person.bills[50] || 0) * 50;
}
function smallBillCount(person) {
  return (person.bills[1] || 0) + (person.bills[5] || 0) + (person.bills[10] || 0);
}
function assertSmallSpread(staff, maxSpread, label) {
  const counts = staff.map(smallBillCount);
  assert.ok(Math.max(...counts) - Math.min(...counts) <= maxSpread, label + ' small bills should be rebalanced, got ' + counts.join(', '));
}
function assertDenomSpread(staff, denom, maxSpread, label) {
  const counts = staff.map(person => person.bills[denom] || 0);
  assert.ok(Math.max(...counts) - Math.min(...counts) <= maxSpread, label + ' $' + denom + 's should be split, got ' + counts.join(', '));
}
{
  const staff = runExample({
    100: 8,
    50: 4,
    20: 62,
    10: 1,
    5: 4,
    1: 10
  });
  const a = staff.find(p => p.n === 'a');
  const aa = staff.find(p => p.n === 'aa');
  const bc = staff.find(p => p.n === 'bc');
  assert.strictEqual(aa.bills[100], 2, 'largest payout keeps a proportional $100 share');
  assert.strictEqual(highHundredsAndFifties(a), 200, '$439 is not left at $150 progress');
  assert.strictEqual(highHundredsAndFifties(bc), 200, '$487 does not jump ahead of $439 on $50 progress');
  assert.strictEqual(highHundredsAndFifties(aa), 200, '$488 remains balanced with the adjacent top payouts');
}
{
  const staff = runExample({
    100: 7,
    50: 6,
    20: 62,
    10: 1,
    5: 4,
    1: 10
  });
  const a = staff.find(p => p.n === 'a');
  const aa = staff.find(p => p.n === 'aa');
  const bc = staff.find(p => p.n === 'bc');
  assert.strictEqual(aa.bills[100], 2, '$488 keeps two $100s with extra flippers available');
  assert.strictEqual(bc.bills[100], 2, '$487 keeps two $100s with extra flippers available');
  assert.strictEqual(highHundredsAndFifties(a), 200, '$439 receives a proportional second $50');
  assert.strictEqual(highHundredsAndFifties(bc), 200, '$487 stays balanced after $100s/$50s');
  assert.strictEqual(highHundredsAndFifties(aa), 200, '$488 stays balanced after $100s/$50s');
}
{
  const staff = runExample({
    100: 7,
    50: 6,
    20: 60,
    10: 5,
    5: 4,
    1: 10
  });
  const a = staff.find(p => p.n === 'a');
  const bc = staff.find(p => p.n === 'bc');
  const aa = staff.find(p => p.n === 'aa');
  assert.strictEqual(highHundredsAndFifties(a), 200, '$439 should be lifted from $150 to $200');
  assert.strictEqual(highHundredsAndFifties(bc), 200, '$487 should not sit at $250 when $439 is $150');
  assert.strictEqual(highHundredsAndFifties(aa), 200, '$488 remains proportionally aligned with $487');
}
{
  const names = ['a', 'bc', 'c', 'd', 'aa'];
  const finals = [438, 485, 473, 388, 486];
  const staff = finals.map((final, i) => ({
    n: names[i],
    final
  }));
  ctx.distributeBills(staff, {
    100: 7,
    50: 6,
    20: 61,
    10: 1,
    5: 4,
    1: 20
  }, 0);
  staff.forEach(person => {
    assert.strictEqual(totalBills(person.bills), person.final, person.n + ' latest screenshot total');
    assert.strictEqual(highHundredsAndFifties(person), 200, person.n + ' should share $100+$50 progress evenly when constraints allow');
  });
}
{
  const names = ['a', 'bc', 'c', 'd', 'aa'];
  const finals = [438, 485, 473, 388, 486];
  const staff = finals.map((final, i) => ({
    n: names[i],
    final
  }));
  ctx.distributeBills(staff, {
    100: 7,
    50: 4,
    20: 62,
    10: 0,
    5: 2,
    1: 120
  }, 0);
  staff.forEach(person => {
    assert.strictEqual(totalBills(person.bills), person.final, person.n + ' no tens extreme total');
  });
  assertSmallSpread(staff, 12, 'no tens extreme');
  assertDenomSpread(staff, 5, 2, 'no tens extreme');
  assert.ok((staff.find(p => p.n === 'd').bills[1] || 0) < 40, 'd should not absorb almost all $1s');
}
{
  const names = ['a', 'bc', 'c', 'd', 'aa'];
  const finals = [438, 485, 473, 388, 486];
  const staff = finals.map((final, i) => ({
    n: names[i],
    final
  }));
  ctx.distributeBills(staff, {
    100: 5,
    50: 4,
    20: 62,
    10: 10,
    5: 22,
    1: 120
  }, 0);
  staff.forEach(person => {
    assert.strictEqual(totalBills(person.bills), person.final, person.n + ' many small bills extreme total');
  });
  assertSmallSpread(staff, 12, 'many small bills extreme');
  assertDenomSpread(staff, 10, 3, 'many small bills extreme');
  assertDenomSpread(staff, 5, 3, 'many small bills extreme');
  assert.ok((staff.find(p => p.n === 'd').bills[1] || 0) < 40, 'd should not absorb almost all $1s');
}
console.log('engine distribution tests passed');
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/engine.test.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/engine_day.js
try { (() => {
// Day shift multi-pool engine — pure functions, no DOM access
// Depends on utils.js (parseTimeString, poolValue) and engine.js (distributeBills)

// ── Time helpers ──────────────────────────────────────────────────────────────

// Convert a decimal time value to an absolute hour offset.
// Day shift times: 0–12 treated as AM (0=midnight, 12=noon), values >12 treated
// as-is (24h). We store day shift times as decimals where:
//   10   = 10:00 AM
//   2    = 2:00 PM (but context-shifted — see dayShiftAbsolute)
//
// Day shift runs roughly 10am–6pm. We apply the same "pm unless it would be
// before open" heuristic as night shift but anchored to 10am open.
// Anything >= 10 and <= 12 = AM, anything < 10 = PM (afternoon).
// So: 10=10am, 11=11am, 12=noon, 1=1pm, 2=2pm … 6=6pm.
function dayShiftAbsolute(t) {
  // t is a decimal 0–12 from parseTimeString
  if (t >= 10) return t; // 10am–12pm
  return t + 12; // 1pm–9pm  (1→13, 2→14 … 9→21)
}

// Overlap of [personIn, personOut) with [poolStart, poolEnd) in hours.
// All values are absolute hours (dayShiftAbsolute applied).
function overlapHours(personIn, personOut, poolStart, poolEnd) {
  const start = Math.max(personIn, poolStart);
  const end = Math.min(personOut, poolEnd);
  return Math.max(0, end - start);
}

// ── Pool window derivation ────────────────────────────────────────────────────

// Returns { morningStart, morningEnd, middleEnd } or null with an error.
// morningStart = min of all staff absolute in-times
// morningEnd   = max of server absolute out-times (only servers with explicit out)
// middleEnd    = max of bartender absolute out-times (only bartenders with explicit out)
function deriveDayShiftWindows(bartenders, servers) {
  const allStaff = [...bartenders, ...servers];

  // Absolute in-times for all staff
  const inTimes = allStaff.map(p => p.inAbs).filter(t => t !== null && t !== undefined);
  if (!inTimes.length) return {
    error: 'No staff in-times.'
  };
  const morningStart = Math.min(...inTimes);

  // Morning end = max of server EXPLICIT out-times only
  const serverOutTimes = servers.filter(p => p.hasExplicitOut).map(p => p.outAbs);
  if (!serverOutTimes.length) return {
    error: 'Need at least one server with an Out time to define the Morning Cut end.'
  };
  const morningEnd = Math.max(...serverOutTimes);
  if (morningEnd <= morningStart) return {
    error: 'Morning Cut end must be after start.'
  };

  // Middle end = max of bartender EXPLICIT out-times
  const bartOutTimes = bartenders.filter(p => p.hasExplicitOut).map(p => p.outAbs);
  if (!bartOutTimes.length) return {
    error: 'Need at least one bartender with an Out time to define the Middle Cut end.'
  };
  const middleEnd = Math.max(...bartOutTimes);
  if (middleEnd <= morningEnd) return {
    error: 'Middle Cut end must be after Morning Cut end.'
  };
  return {
    morningStart,
    morningEnd,
    middleEnd,
    error: null
  };
}

// ── Staff normalisation ───────────────────────────────────────────────────────

// Takes raw staff input rows and resolves absolute times.
// defaultInAbs: fallback absolute in-time if field blank
// defaultOutAbs: fallback absolute out-time if field blank AND not a closer
// Returns array of normalised staff objects.
function normaliseDayStaff(rawRows, role, defaultInAbs, defaultOutAbs) {
  return rawRows.map(r => {
    const inParsed = parseTimeString(r.inStr || '');
    const outParsed = parseTimeString(r.outStr || '');
    const inAbs = !inParsed.empty && inParsed.valid ? dayShiftAbsolute(inParsed.value) : defaultInAbs;
    const hasExplicitOut = !outParsed.empty && outParsed.valid;
    const isAutoCloser = !hasExplicitOut;

    // For closers we set outAbs to middleEnd later once windows are known.
    // For now store null — resolved below in calculateDayShift.
    const outAbs = hasExplicitOut ? dayShiftAbsolute(outParsed.value) : null;
    return {
      n: r.name,
      role,
      // 'bartender' | 'server'
      _rowId: r.rowId,
      inAbs,
      outAbs,
      hasExplicitOut,
      isAutoCloser,
      closer: r.closer || isAutoCloser,
      rawShares: {},
      // poolId → raw dollar share (pre-floor)
      rawTotal: 0,
      final: 0,
      bonus: 0,
      bills: {
        100: 0,
        50: 0,
        20: 0,
        10: 0,
        5: 0,
        1: 0
      }
    };
  });
}

// ── Core calculation ──────────────────────────────────────────────────────────

function calculateDayShift(bartenderRows, serverRows, poolCash, partyConfig) {
  // poolCash: { morning: number, middle: number, party1: number|null, party2: number|null }
  // partyConfig: { party1: {enabled, start, end}, party2: {enabled, start, end} }
  // All party start/end are raw string values from inputs.

  if (!bartenderRows.length && !serverRows.length) {
    return {
      error: 'Add day shift staff.'
    };
  }

  // Resolve default in/out — use 10am absolute as default in
  const defaultInAbs = 10;
  const bartenders = normaliseDayStaff(bartenderRows, 'bartender', defaultInAbs, null);
  const servers = normaliseDayStaff(serverRows, 'server', defaultInAbs, null);

  // Derive windows
  const windows = deriveDayShiftWindows(bartenders, servers);
  if (windows.error) return {
    error: windows.error
  };
  const {
    morningStart,
    morningEnd,
    middleEnd
  } = windows;

  // Resolve closer out-times now that we have middleEnd
  // Closers get outAbs = middleEnd (last possible shift end for day shift)
  [...bartenders, ...servers].forEach(p => {
    if (p.outAbs === null) p.outAbs = middleEnd;
  });

  // Validate: ensure all staff have positive shift hours
  for (const p of [...bartenders, ...servers]) {
    const h = p.outAbs - p.inAbs;
    if (h <= 0) {
      return {
        error: `${p.n} has invalid shift hours (${h}h). Check In/Out times.`
      };
    }
    p.totalHours = h;
  }

  // Build pool definitions
  const pools = [];

  // Morning cut: all staff, window [morningStart, morningEnd]
  pools.push({
    id: 'morning',
    label: 'Morning Cut',
    start: morningStart,
    end: morningEnd,
    total: poolCash.morning || 0,
    who: 'all' // bartenders + servers
  });

  // Middle cut: bartenders only, window [morningEnd, middleEnd]
  pools.push({
    id: 'middle',
    label: 'Middle Cut',
    start: morningEnd,
    end: middleEnd,
    total: poolCash.middle || 0,
    who: 'bartenders'
  });

  // Party pools
  for (const pid of ['party1', 'party2']) {
    const cfg = partyConfig[pid];
    if (!cfg || !cfg.enabled) continue;
    const startParsed = parseTimeString(cfg.start || '');
    const endParsed = parseTimeString(cfg.end || '');
    if (!startParsed.valid || startParsed.empty) {
      return {
        error: `Party pool start time is invalid.`
      };
    }
    if (!endParsed.valid || endParsed.empty) {
      return {
        error: `Party pool end time is invalid.`
      };
    }
    const pStart = dayShiftAbsolute(startParsed.value);
    const pEnd = dayShiftAbsolute(endParsed.value);
    if (pEnd <= pStart) return {
      error: `Party pool end must be after start.`
    };
    pools.push({
      id: pid,
      label: pid === 'party1' ? 'Party 1' : 'Party 2',
      start: pStart,
      end: pEnd,
      total: poolCash[pid] || 0,
      who: 'all'
    });
  }

  // Validate all pool totals
  for (const pool of pools) {
    if (pool.total < 0) return {
      error: `${pool.label} cash cannot be negative.`
    };
  }
  const totalCash = pools.reduce((s, p) => s + p.total, 0);
  if (totalCash === 0) return {
    error: 'Enter cash for at least one pool.'
  };

  // ── Compute raw shares ────────────────────────────────────────────────────

  const allStaff = [...bartenders, ...servers];
  const poolResults = [];
  for (const pool of pools) {
    const eligible = pool.who === 'bartenders' ? bartenders : allStaff;

    // Compute overlap hours per eligible person
    const participants = [];
    for (const p of eligible) {
      const hrs = overlapHours(p.inAbs, p.outAbs, pool.start, pool.end);
      if (hrs > 0) participants.push({
        person: p,
        hours: hrs
      });
    }
    const poolTotalHours = participants.reduce((s, x) => s + x.hours, 0);
    const rate = poolTotalHours > 0 ? pool.total / poolTotalHours : 0;
    for (const {
      person,
      hours
    } of participants) {
      const raw = hours * rate;
      person.rawShares[pool.id] = (person.rawShares[pool.id] || 0) + raw;
    }
    poolResults.push({
      id: pool.id,
      label: pool.label,
      start: pool.start,
      end: pool.end,
      total: pool.total,
      totalHours: poolTotalHours,
      rate,
      participants: participants.map(({
        person,
        hours
      }) => ({
        name: person.n,
        role: person.role,
        _rowId: person._rowId,
        hours,
        raw: hours * rate
      }))
    });
  }

  // ── Single floor per person ───────────────────────────────────────────────

  allStaff.forEach(p => {
    p.rawTotal = Object.values(p.rawShares).reduce((s, v) => s + v, 0);
    p.final = Math.floor(p.rawTotal);
  });
  const totalFloored = allStaff.reduce((s, p) => s + p.final, 0);
  const remainder = totalCash - totalFloored;

  // Closer bonus: split remainder evenly among closers, floor
  const closers = allStaff.filter(p => p.closer);
  const perCloser = closers.length ? Math.floor(remainder / closers.length) : 0;
  const leftover = remainder - perCloser * closers.length;
  closers.forEach(p => {
    p.bonus = perCloser;
    p.final += perCloser;
  });

  // ── Bill distribution (combined pool) ────────────────────────────────────

  // Merge all pool bill snapshots into one combined pool
  // (caller passes mergedBills as the combined count object)
  // Distribution runs at the end — we return staff with final amounts,
  // caller calls distributeBills with merged bills.

  return {
    error: null,
    pools: poolResults,
    people: allStaff,
    windows: {
      morningStart,
      morningEnd,
      middleEnd
    },
    totalCash,
    totalPaid: allStaff.reduce((s, p) => s + p.final, 0),
    leftover,
    remainder
  };
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/engine_day.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/engine_day.test.js
try { (() => {
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const ctx = {
  console
};
vm.createContext(ctx);
vm.runInContext('const DENOMS=[100,50,20,10,5,1];\n' + fs.readFileSync(path.join(__dirname, 'utils.js'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, 'engine.js'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, 'engine_day.js'), 'utf8'), ctx);

// ── Helpers ───────────────────────────────────────────────────────────────────

function bartRow(name, inStr, outStr) {
  return {
    rowId: name,
    name,
    inStr: inStr || '',
    outStr: outStr || '',
    closer: false
  };
}
function servRow(name, inStr, outStr) {
  return {
    rowId: name,
    name,
    inStr: inStr || '',
    outStr: outStr || '',
    closer: false
  };
}
function run(barts, servs, poolCash, partyConfig) {
  return vm.runInContext(`calculateDayShift(
      ${JSON.stringify(barts)},
      ${JSON.stringify(servs)},
      ${JSON.stringify(poolCash)},
      ${JSON.stringify(partyConfig || {
    party1: {
      enabled: false
    },
    party2: {
      enabled: false
    }
  })}
    )`, ctx);
}

// ── dayShiftAbsolute ──────────────────────────────────────────────────────────

{
  const abs = t => vm.runInContext(`dayShiftAbsolute(${t})`, ctx);
  assert.strictEqual(abs(10), 10, '10 → 10am');
  assert.strictEqual(abs(12), 12, '12 → noon');
  assert.strictEqual(abs(1), 13, '1  → 1pm');
  assert.strictEqual(abs(9), 21, '9  → 9pm');
}

// ── overlapHours ──────────────────────────────────────────────────────────────

{
  const overlap = (pIn, pOut, pStart, pEnd) => vm.runInContext(`overlapHours(${pIn},${pOut},${pStart},${pEnd})`, ctx);
  assert.strictEqual(overlap(10, 14, 10, 14), 4, 'full overlap');
  assert.strictEqual(overlap(10, 12, 10, 14), 2, 'partial overlap (left)');
  assert.strictEqual(overlap(12, 14, 10, 14), 2, 'partial overlap (right)');
  assert.strictEqual(overlap(14, 16, 10, 14), 0, 'outside window');
  assert.strictEqual(overlap(10, 10, 10, 14), 0, 'zero-length person shift');
}

// ── No staff → error ──────────────────────────────────────────────────────────

{
  const r = run([], [], {
    morning: 100,
    middle: 100
  });
  assert.ok(r.error, 'empty staff returns error');
}

// ── Zero cash → error ─────────────────────────────────────────────────────────

{
  const r = run([bartRow('A', '10', '3')], [servRow('B', '10', '2')], {
    morning: 0,
    middle: 0
  });
  assert.ok(r.error, 'zero cash returns error');
  assert.ok(r.error.includes('cash'), 'error mentions cash');
}

// ── Missing server out-time → error ──────────────────────────────────────────

{
  const r = run([bartRow('A', '10', '3')], [servRow('B', '10', '')],
  // no out-time for server
  {
    morning: 200,
    middle: 100
  });
  assert.ok(r.error, 'missing server out returns error');
}

// ── Missing bartender out-time → error ───────────────────────────────────────

{
  const r = run([bartRow('A', '10', '')],
  // no out-time for bartender
  [servRow('B', '10', '2')], {
    morning: 200,
    middle: 100
  });
  assert.ok(r.error, 'missing bartender out returns error');
}

// ── Basic two-pool scenario ───────────────────────────────────────────────────

{
  // Bart in 10am, out 3pm (15); Server in 10am, out 2pm (14).
  // Morning cut [10,14]: both eligible. Middle cut [14,15]: bart only.
  const r = run([bartRow('Bart', '10', '3')], [servRow('Serv', '10', '2')], {
    morning: 100,
    middle: 50
  });
  assert.strictEqual(r.error, null, 'no error');
  assert.strictEqual(r.totalCash, 150, 'totalCash');
  assert.strictEqual(r.totalPaid + r.leftover, r.totalCash, 'totalPaid + leftover === totalCash');
  assert.ok(r.people.length === 2, '2 people');
  r.people.forEach(p => assert.ok(p.final >= 0, p.n + ' payout non-negative'));
}

// ── Closer auto-detection ─────────────────────────────────────────────────────

{
  // Bart has no out-time → auto-closer; server has explicit out.
  const r = run([bartRow('CloserBart', '10', '')], [servRow('Serv', '10', '2')], {
    morning: 100,
    middle: 50
  });
  // Could still error if window derivation fails without bartender explicit out
  // (middleEnd needs at least one bartender explicit out). That's the expected behavior.
  assert.ok(r.error, 'missing bartender explicit out should error (window derivation)');
}
{
  // When bartender has explicit out, server has no out → server is auto-closer.
  const r = run([bartRow('Bart', '10', '3')], [servRow('CloserServ', '10', '2'), servRow('AutoClose', '10', '')], {
    morning: 100,
    middle: 50
  });
  assert.strictEqual(r.error, null, 'no error with server auto-closer');
  const closer = r.people.find(p => p.n === 'AutoClose');
  assert.ok(closer.closer, 'AutoClose is marked as closer');
  assert.ok(closer.bonus >= 0, 'closer has non-negative bonus');
}

// ── Party pool inclusion ──────────────────────────────────────────────────────

{
  const r = run([bartRow('Bart', '10', '3')], [servRow('Serv', '10', '2')], {
    morning: 100,
    middle: 50,
    party1: 60
  }, {
    party1: {
      enabled: true,
      start: '11',
      end: '1'
    },
    party2: {
      enabled: false
    }
  });
  assert.strictEqual(r.error, null, 'no error with party pool');
  assert.strictEqual(r.totalCash, 210, 'totalCash includes party pool');
  assert.strictEqual(r.totalPaid + r.leftover, r.totalCash, 'totalPaid + leftover === totalCash with party');
  const partyPool = r.pools.find(p => p.id === 'party1');
  assert.ok(partyPool, 'party1 pool in results');
  assert.strictEqual(partyPool.total, 60, 'party1 total');
}

// ── Single bartender, single server ──────────────────────────────────────────

{
  const r = run([bartRow('B', '10', '4')], [servRow('S', '11', '2')], {
    morning: 80,
    middle: 40
  });
  assert.strictEqual(r.error, null, 'minimal case no error');
  assert.strictEqual(r.totalPaid + r.leftover, r.totalCash, 'minimal: totals balance');
}
console.log('engine_day tests passed');
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/engine_day.test.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/main.js
try { (() => {
// Bootstrap — runs after all other scripts are loaded
const _today = new Date();
const yyyy = _today.getFullYear();
const mm = String(_today.getMonth() + 1).padStart(2, '0');
const dd = String(_today.getDate()).padStart(2, '0');
$('tipDate').value = yyyy + '-' + mm + '-' + dd;
const _saved = loadState();
function _savedBillSnap(snap) {
  const out = {
    100: '',
    50: '',
    20: '',
    10: '',
    5: '',
    1: ''
  };
  DENOMS.forEach(d => {
    out[d] = snap?.[d] ?? '';
  });
  return out;
}
isRestoringState = true;
if (_saved) {
  // ── Shared fields ──
  if (_saved.date) $('tipDate').value = _saved.date;
  if (_saved.gcIn) $('gc-in').value = _saved.gcIn;
  if (_saved.gcOut) $('gc-out').value = _saved.gcOut;

  // ── Shift mode ──
  const savedShift = _saved.shiftMode || 'night';
  shiftMode = savedShift;
  const btnNight = $('shift-btn-night');
  const btnDay = $('shift-btn-day');
  if (btnNight) btnNight.classList.toggle('active', savedShift === 'night');
  if (btnDay) btnDay.classList.toggle('active', savedShift === 'day');
  const shiftLabel = $('shift-mode-label');
  if (shiftLabel) shiftLabel.textContent = savedShift === 'night' ? 'Night Shift' : 'Day Shift';
  const nightCash = $('night-cash-section');
  const dayCash = $('day-cash-section');
  const nightStaff = $('night-staff-section');
  const dayStaff = $('day-staff-section');
  if (nightCash) nightCash.style.display = savedShift === 'night' ? '' : 'none';
  if (dayCash) dayCash.style.display = savedShift === 'day' ? '' : 'none';
  if (nightStaff) nightStaff.style.display = savedShift === 'night' ? '' : 'none';
  if (dayStaff) dayStaff.style.display = savedShift === 'day' ? '' : 'none';

  // ── Night shift cash ──
  if (_saved.netTotal) $('net-total-input').value = _saved.netTotal;
  netTotalSnapshot = _saved.netTotal ?? '';
  perBillSnapshot = _savedBillSnap(_saved.perBillBills ?? (_saved.cashMode === 'perbill' ? _saved.bills : {}));
  netBillSnapshot = _savedBillSnap(_saved.netBillBills ?? (_saved.cashMode === 'nettotal' ? _saved.bills : {}));

  // ── Bartenders ──
  // Night shift: staffList. Day shift: bartenderList. Both use the same saved 'staff' array.
  const bartListId = savedShift === 'day' ? 'bartenderList' : 'staffList';
  const bartRows = _saved.staff?.length >= 1 ? _saved.staff : savedShift === 'night' ? [{}, {}, {}] : [{}];
  bartRows.forEach((s, i) => {
    addStaff(false, bartListId);
    const row = document.querySelectorAll('#' + bartListId + ' .staff-row-modal')[i];
    if (!row) return;
    row.querySelector('[data-field="name"]').value = s.name ?? '';
    row.querySelector('[data-field="in"]').value = s.in ?? '';
    row.querySelector('[data-field="out"]').value = s.out ?? '';
    if (s.closer) row.querySelector('.sri-closer')?.classList.add('on');
    calcHours(row.id.replace('staff', ''));
  });

  // ── Role defaults ──
  if (_saved.roleDefaults) {
    ['bartender', 'server', 'support'].forEach(role => {
      if (_saved.roleDefaults[role]) {
        roleDefaults[role].in = _saved.roleDefaults[role].in || '';
        roleDefaults[role].out = _saved.roleDefaults[role].out || '';
      }
    });
  }
  if (_saved.staffViewRole) staffViewRole = _saved.staffViewRole;
  remainderOverrides = _saved.remainderOverrides || null;

  // ── Servers (day shift) ──
  if (savedShift === 'day' && _saved.servers?.length) {
    _saved.servers.forEach((s, i) => {
      addStaff(false, 'serverList');
      const row = document.querySelectorAll('#serverList .staff-row-modal')[i];
      if (!row) return;
      row.querySelector('[data-field="name"]').value = s.name ?? '';
      row.querySelector('[data-field="in"]').value = s.in ?? '';
      row.querySelector('[data-field="out"]').value = s.out ?? '';
      if (s.closer) row.querySelector('.sri-closer')?.classList.add('on');
      calcHours(row.id.replace('staff', ''));
    });
  } else if (savedShift === 'day') {
    addStaff(false, 'serverList');
  }

  // ── Night shift servers ──
  if (savedShift === 'night' && _saved.nightServers?.length) {
    _saved.nightServers.forEach((s, i) => {
      addStaff(false, 'nightServerList');
      const row = document.querySelectorAll('#nightServerList .staff-row-modal')[i];
      if (!row) return;
      row.querySelector('[data-field="name"]').value = s.name ?? '';
      row.querySelector('[data-field="in"]').value = s.in ?? '';
      row.querySelector('[data-field="out"]').value = s.out ?? '';
      if (s.closer) row.querySelector('.sri-closer')?.classList.add('on');
      calcHours(row.id.replace('staff', ''));
    });
  }

  // ── Support staff (both shifts) ──
  if (_saved.support?.length) {
    _saved.support.forEach((s, i) => {
      addStaff(false, 'supportList');
      const row = document.querySelectorAll('#supportList .staff-row-modal')[i];
      if (!row) return;
      const rowId = row.id.replace('staff', '');
      row.querySelector('[data-field="name"]').value = s.name ?? '';
      row.querySelector('[data-field="in"]').value = s.in ?? '';
      row.querySelector('[data-field="out"]').value = s.out ?? '';
      if (Array.isArray(s.cuts)) supportCutAssignments[rowId] = s.cuts;
      calcHours(rowId);
    });
  }

  // ── Day shift pool cash ──
  if (_saved.dayPools) {
    ['morning', 'middle', 'party1', 'party2'].forEach(pid => {
      const saved = _saved.dayPools[pid];
      if (!saved) return;
      const pool = dayPools[pid];
      pool.cashMode = saved.cashMode || 'perbill';
      pool.netTotalSnapshot = saved.netTotalSnapshot || '';
      pool.perBillSnapshot = _savedBillSnap(saved.perBillSnapshot);
      pool.netBillSnapshot = _savedBillSnap(saved.netBillSnapshot);
      if (pid === 'party1' || pid === 'party2') {
        pool.enabled = !!saved.enabled;
        pool.windowStart = saved.windowStart || '';
        pool.windowEnd = saved.windowEnd || '';
      }
    });
  }

  // Night shift cash mode
  cashMode = _saved.cashMode || 'perbill';
  if (savedShift === 'night') setCashMode(cashMode);

  // Render day cash panels after state is set
  if (savedShift === 'day') {
    renderDayPoolCashPanels();
    ['morning', 'middle', 'party1', 'party2'].forEach(pid => {
      const pool = dayPools[pid];
      if (!pool.enabled && (pid === 'party1' || pid === 'party2')) return;
      if (pool.cashMode === 'nettotal') {
        const el = $('dp-net-' + pid);
        if (el) {
          el.value = pool.netTotalSnapshot || '';
          onDayPoolNetTotalChange(pid);
        }
      } else {
        DENOMS.forEach(d => {
          const el = $('dp-b' + d + '-' + pid);
          if (el) el.value = pool.perBillSnapshot?.[d] ?? '';
        });
        onDayPoolBillsChange(pid);
      }
    });
  }
} else {
  // Fresh session defaults
  addStaff(false, 'staffList');
  addStaff(false, 'staffList');
  addStaff(false, 'staffList');
  if (shiftMode === 'day') {
    addStaff(false, 'serverList');
    renderDayPoolCashPanels();
  } else {
    setCashMode('nettotal');
  }
}

// Sync the default times modal per-role fields on load
if (typeof _syncModalRoleFields === 'function') _syncModalRoleFields();
isRestoringState = false;

// Date change listeners
$('tipDate').addEventListener('change', saveState);
$('tipDate').addEventListener('input', saveState);
reindexTabOrder();
updateSectionCounts();

// Apply role toggle UI state
switchStaffRole(staffViewRole);
updateRoleDefaultsUI();
if (shiftMode === 'day') {
  updateDayStockCards();
} else {
  updateStockCards();
}
updateTabIndicators();
autoCalculate();

// Pulse-hint first empty staff name field (night mode only — day mode has bartenderList)
const _firstEmptySelector = shiftMode === 'day' ? '#bartenderList [data-field="name"]' : '#staffList [data-field="name"]';
const _firstEmpty = document.querySelector(_firstEmptySelector);
if (_firstEmpty && !_firstEmpty.value.trim()) {
  const _row = _firstEmpty.closest('.staff-row-modal');
  if (_row) {
    _row.classList.add('pulse-hint');
    setTimeout(() => _row.classList.remove('pulse-hint'), 1600);
  }
}

// Hide tab bar when software keyboard is open so it doesn't block inputs.
// Uses a body class; CSS handles both the bar and content padding.
if (window.visualViewport) {
  const KEYBOARD_THRESHOLD = 120; // px shrinkage below which we ignore (URL bar etc)
  const updateKeyboardState = () => {
    const shrink = window.screen.height - window.visualViewport.height;
    document.body.classList.toggle('keyboard-open', shrink > KEYBOARD_THRESHOLD);
  };
  window.visualViewport.addEventListener('resize', updateKeyboardState);
  window.visualViewport.addEventListener('scroll', updateKeyboardState);
}

// Desktop keyboard shortcuts. Numeric tab jumps only run when the user is not typing.
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.setAttribute('role', 'tab');
  btn.setAttribute('aria-selected', btn.classList.contains('active') ? 'true' : 'false');
});
function _isTypingTarget(el) {
  if (!el) return false;
  const tag = el.tagName;
  return el.isContentEditable || tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT';
}
document.addEventListener('keydown', e => {
  if (e.defaultPrevented || e.altKey || e.ctrlKey || e.metaKey || _isTypingTarget(e.target)) return;
  const tabByKey = {
    '1': 'home',
    '2': 'cash',
    '3': 'staff',
    '4': 'summary',
    '5': 'dist'
  };
  const tabName = tabByKey[e.key];
  if (tabName) {
    switchTab(tabName, $('tb-' + tabName));
    e.preventDefault();
    return;
  }
  if (e.key.toLowerCase() === 'a' && $('tab-staff')?.classList.contains('active')) {
    const listId = typeof getActiveListId === 'function' ? getActiveListId() : 'staffList';
    addStaff(true, listId);
    e.preventDefault();
  }
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/main.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/modals.js
try { (() => {
const _modalLastFocus = {};
function _openModalEls() {
  return [...document.querySelectorAll('.modal-overlay.open')];
}
function _syncModalBodyLock() {
  const hasOpenModal = _openModalEls().length > 0;
  document.body.classList.toggle('modal-open', hasOpenModal);
  document.body.style.overflow = hasOpenModal ? 'hidden' : '';
}
function openModal(id) {
  const modal = $(id);
  if (!modal) return;
  _modalLastFocus[id] = document.activeElement;
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
  _syncModalBodyLock();
  requestAnimationFrame(() => {
    if (!modal.classList.contains('open') || modal.contains(document.activeElement)) return;
    const focusTarget = modal.querySelector('.modal-close, button, input, [tabindex]:not([tabindex="-1"])');
    if (focusTarget) focusTarget.focus({
      preventScroll: true
    });
  });
}
function closeModal(id) {
  const modal = $(id);
  if (!modal || !modal.classList.contains('open')) return;
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden', 'true');
  _syncModalBodyLock();
  const lastFocus = _modalLastFocus[id];
  if (lastFocus && document.body.contains(lastFocus)) {
    lastFocus.focus({
      preventScroll: true
    });
  }
  delete _modalLastFocus[id];
  updateShiftStockCards();
  autoCalculate();
}
function modalBgClose(e, id) {
  if (e.target === $(id)) closeModal(id);
}
function closeTopModal() {
  const modals = _openModalEls();
  const topModal = modals[modals.length - 1];
  if (!topModal) return false;
  closeModal(topModal.id);
  return true;
}
document.querySelectorAll('.modal-overlay').forEach(modal => {
  modal.setAttribute('aria-hidden', modal.classList.contains('open') ? 'false' : 'true');
  modal.setAttribute('role', 'dialog');
  modal.setAttribute('aria-modal', 'true');
});
document.addEventListener('keydown', e => {
  if (e.key !== 'Escape') return;
  if (closeTopModal()) e.preventDefault();
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/modals.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/persist.js
try { (() => {
const STORAGE_KEY = 'tippool_v1';
function saveState() {
  if (isRestoringState) return;
  if (typeof snapshotCurrentCashMode === 'function') snapshotCurrentCashMode();
  const serializeList = selector => [...document.querySelectorAll(selector)].map(r => {
    const rowId = r.id.replace('staff', '');
    const ctEl = document.getElementById('ct' + rowId);
    return {
      _rowId: rowId,
      name: r.querySelector('[data-field="name"]').value,
      in: r.querySelector('[data-field="in"]').value,
      out: r.querySelector('[data-field="out"]').value,
      closer: ctEl ? ctEl.classList.contains('on') : false
    };
  });
  const bartenderSelector = shiftMode === 'day' ? '#bartenderList .staff-row-modal' : '#staffList .staff-row-modal';
  const staff = serializeList(bartenderSelector);
  const servers = serializeList('#serverList .staff-row-modal');
  const nightServers = serializeList('#nightServerList .staff-row-modal');
  const support = serializeList('#supportList .staff-row-modal').map(p => ({
    ...p,
    cuts: supportCutAssignments[p._rowId] || []
  }));

  // Snapshot current day pool cash states
  const dayPoolSnap = {};
  ['morning', 'middle', 'party1', 'party2'].forEach(pid => {
    const p = dayPools[pid];
    if (!p) return;
    const snap = {
      cashMode: p.cashMode,
      netTotalSnapshot: p.netTotalSnapshot || '',
      perBillSnapshot: {
        ...p.perBillSnapshot
      },
      netBillSnapshot: {
        ...p.netBillSnapshot
      }
    };
    if (pid === 'party1' || pid === 'party2') {
      snap.enabled = p.enabled;
      snap.windowStart = p.windowStart || '';
      snap.windowEnd = p.windowEnd || '';
    }
    if (p.cashMode === 'nettotal') {
      const el = $('dp-net-' + pid);
      if (el) snap.netTotalSnapshot = el.value || '';
    } else {
      DENOMS.forEach(d => {
        const el = $('dp-b' + d + '-' + pid);
        if (el) snap.perBillSnapshot[d] = el.value || '';
      });
    }
    dayPoolSnap[pid] = snap;
  });
  const snap = {
    v: 3,
    saved: Date.now(),
    date: $('tipDate')?.value ?? '',
    gcIn: $('gc-in')?.value ?? '',
    gcOut: $('gc-out')?.value ?? '',
    shiftMode,
    cashMode,
    staffViewRole,
    roleDefaults,
    remainderOverrides,
    bills: typeof readBillInputSnapshot === 'function' ? readBillInputSnapshot() : {},
    perBillBills: perBillSnapshot,
    netBillBills: netBillSnapshot,
    netTotal: $('net-total-input')?.value ?? '',
    staff,
    servers,
    nightServers,
    support,
    dayPools: dayPoolSnap
  };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(snap));
  } catch (e) {
    console.warn('TipPool: localStorage unavailable', e);
  }
}
function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const snap = JSON.parse(raw);
    validateSessionSnapshot(snap);
    return snap;
  } catch {
    return null;
  }
}
function isPlainObject(value) {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}
function validateBillSnapshot(value, label) {
  if (value == null) return;
  if (!isPlainObject(value)) throw new Error(label + ' must be an object');
  DENOMS.forEach(d => {
    const billValue = value[d];
    if (billValue == null) return;
    if (typeof billValue !== 'string' && typeof billValue !== 'number') {
      throw new Error(label + ' contains invalid bill values');
    }
    if (!parseWholeNumberString(billValue).valid) {
      throw new Error(label + ' contains non-whole bill counts');
    }
  });
}
function validateSessionSnapshot(snap) {
  if (!isPlainObject(snap)) throw new Error('Not a valid TipPool file');
  if (snap.v !== 1 && snap.v !== 2 && snap.v !== 3) throw new Error('Incompatible file version');
  ['date', 'gcIn', 'gcOut', 'cashMode', 'netTotal'].forEach(key => {
    if (snap[key] != null && typeof snap[key] !== 'string') throw new Error(key + ' must be a string');
  });
  if (snap.cashMode && snap.cashMode !== 'perbill' && snap.cashMode !== 'nettotal') {
    throw new Error('cashMode is invalid');
  }
  if (snap.shiftMode && snap.shiftMode !== 'night' && snap.shiftMode !== 'day') {
    throw new Error('shiftMode is invalid');
  }
  if (snap.remainderOverrides != null && !isPlainObject(snap.remainderOverrides)) {
    throw new Error('remainderOverrides must be an object');
  }
  if (isPlainObject(snap.remainderOverrides)) {
    Object.values(snap.remainderOverrides).forEach(value => {
      if (!Number.isSafeInteger(Number(value)) || Number(value) < 0) {
        throw new Error('remainderOverrides contains invalid values');
      }
    });
  }
  validateBillSnapshot(snap.bills, 'bills');
  validateBillSnapshot(snap.perBillBills, 'perBillBills');
  validateBillSnapshot(snap.netBillBills, 'netBillBills');
  if (snap.staff != null) {
    if (!Array.isArray(snap.staff)) throw new Error('staff must be an array');
    snap.staff.forEach(person => {
      if (!isPlainObject(person)) throw new Error('staff entries must be objects');
      ['name', 'in', 'out'].forEach(key => {
        if (person[key] != null && typeof person[key] !== 'string') throw new Error('staff ' + key + ' must be a string');
      });
      if (person.closer != null && typeof person.closer !== 'boolean') throw new Error('staff closer must be a boolean');
    });
  }
  if (snap.servers != null) {
    if (!Array.isArray(snap.servers)) throw new Error('servers must be an array');
    snap.servers.forEach(person => {
      if (!isPlainObject(person)) throw new Error('server entries must be objects');
    });
  }
}
function exportSession() {
  saveState();
  const data = localStorage.getItem(STORAGE_KEY);
  if (!data) {
    alert('Nothing to export yet.');
    return;
  }
  const date = $('tipDate')?.value ?? 'session';
  const filename = 'tippool-' + date + '.json';
  const blob = new Blob([data], {
    type: 'application/json'
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
function importSession(file) {
  if (!file) return;
  const reader = new FileReader();
  const input = $('importFileInput');
  const resetInput = () => {
    if (input) input.value = '';
  };
  reader.onload = e => {
    try {
      const parsed = JSON.parse(e.target.result);
      validateSessionSnapshot(parsed);
      localStorage.setItem(STORAGE_KEY, e.target.result);
      resetInput();
      location.reload();
    } catch (err) {
      alert('Import failed: ' + err.message);
      resetInput();
    }
  };
  reader.onerror = () => {
    alert('Could not read file.');
    resetInput();
  };
  reader.readAsText(file);
}
function clearSession() {
  if (!confirm('Start a new session? This will clear all current data.')) return;
  localStorage.removeItem(STORAGE_KEY);
  location.reload();
}
function triggerImport() {
  const input = $('importFileInput');
  if (input) input.value = '';
  $('importFileInput').click();
}
function toggleSessionMenu() {
  const menu = $('sessionMenu');
  if (menu) menu.classList.toggle('hidden');
}
document.addEventListener('click', e => {
  const menu = $('sessionMenu');
  if (!menu || menu.classList.contains('hidden')) return;
  if (!menu.contains(e.target) && e.target.id !== 'sessionMenuBtn') {
    menu.classList.add('hidden');
  }
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/persist.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/person.js
try { (() => {
function openPersonModal(rowId) {
  const person = lastStaff.find(p => p._rowId === String(rowId));
  if (!person) return;
  const safe = escapeHTML(person.n);
  const initials = escapeHTML(person.n.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2));
  const inStr = fmtTime(person.i, person.i, false);
  const outStr = fmtTime(person.o, person.i, person.o < person.i);
  const hrsStr = fmtHrs(person.h);
  const closerBadge = person.closer ? '<span class="closer-badge" style="margin-left:5px">closer</span>' : '';
  const dp = (_lastDistStaff || []).find(p => p._rowId === String(rowId));
  const hasBills = dp && DENOMS.some(d => (dp.bills[d] || 0) > 0);
  const billsHTML = hasBills ? '<div class="profile-bills-row">' + DENOMS.map(d => {
    const n = dp.bills[d] || 0;
    return `<div class="profile-bill-chip"><span class="pbc2-denom">$${d}</span><span class="pbc2-count${n === 0 ? ' zero' : ''}">${n === 0 ? '—' : n}</span></div>`;
  }).join('') + '</div>' : `<div style="color:var(--muted);font-size:.75rem;font-family:var(--font-mono);padding:6px 0">No distribution calculated yet</div>`;
  $('personModalLabel').textContent = person.n;
  $('personModalBody').innerHTML = `
    <div class="person-profile-hdr">
      <div class="person-profile-avatar">${initials}</div>
      <div class="person-profile-name">${safe}${closerBadge}</div>
      <div class="person-profile-sub">${hrsStr}h · ${inStr}–${outStr}</div>
    </div>
    <div class="person-profile-body">
      <div class="profile-section">
        <div class="profile-section-lbl">Hours</div>
        <div class="profile-hours-block">
          <div class="profile-hrs-big">${escapeHTML(hrsStr)}h</div>
          <div class="profile-hours-detail"><div class="profile-in-out">${inStr} – ${outStr}</div><div class="profile-shift-lbl">Start – End</div></div>
        </div>
        <div class="profile-edit-row">
          <span class="profile-edit-lbl">In</span>
          <input class="profile-time-input" id="pi-in-${rowId}" value="${person._autoCloser ? '' : escapeHTML(String(person.i))}" placeholder="${escapeHTML(String(person.i))}" inputmode="decimal" onchange="updatePersonFromModal('${escapeHTML(String(rowId))}')">
          <span class="profile-edit-sep">–</span>
          <span class="profile-edit-lbl">Out</span>
          <input class="profile-time-input" id="pi-out-${rowId}" value="${person._autoCloser ? '' : escapeHTML(String(person.o))}" placeholder="${person._autoCloser ? 'closer' : escapeHTML(String(person.o))}" inputmode="decimal" onchange="updatePersonFromModal('${escapeHTML(String(rowId))}')">
        </div>
      </div>
      <div class="profile-section">
        <div class="profile-section-lbl">Tips</div>
        <div class="profile-tips-grid">
          <div class="profile-tip-cell"><div class="profile-tip-cell-lbl">Base</div><div class="profile-tip-cell-val">$${person.base}</div></div>
          ${person.bonus > 0 ? `<div class="profile-tip-cell bonus"><div class="profile-tip-cell-lbl">Closer Bonus</div><div class="profile-tip-cell-val">+$${person.bonus}</div></div>` : `<div class="profile-tip-cell"><div class="profile-tip-cell-lbl">Rate</div><div class="profile-tip-cell-val" style="font-size:.82rem">$${lastRate.toFixed(2)}/h</div></div>`}
          <div class="profile-tip-cell span2"><div class="profile-tip-cell-lbl">Total Payout</div><div class="profile-tip-cell-val">$${person.final}</div></div>
        </div>
      </div>
      <div class="profile-section"><div class="profile-section-lbl">Bill Distribution</div>${billsHTML}</div>
      <button class="profile-delete-btn" onclick="deletePersonFromModal('${escapeHTML(String(rowId))}')">Delete person</button>
    </div>`;
  openModal('personModal');
}
function updatePersonFromModal(rowId) {
  const row = $('staff' + rowId);
  if (!row) return;
  const ni = $('pi-in-' + rowId);
  const no = $('pi-out-' + rowId);
  if (ni) {
    const el = row.querySelector('[data-field="in"]');
    if (el) {
      el.value = ni.value;
      el.classList.remove('using-default');
    }
  }
  if (no) {
    const el = row.querySelector('[data-field="out"]');
    if (el) {
      el.value = no.value;
      el.classList.remove('using-default');
    }
  }
  calcHours(rowId);
  autoCalculate();
  setTimeout(() => {
    if ($('personModal').classList.contains('open')) openPersonModal(rowId);
  }, 120);
}
function deletePersonFromModal(rowId) {
  const listId = typeof _findListForId === 'function' ? _findListForId(rowId) : null;
  if (!listId) return;
  closeModal('personModal');
  delStaff(rowId, listId);
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/person.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/remainder.js
try { (() => {
// Remainder allocation panel — night shift only.
// Automatic mode keeps the original closer split. Manual mode stores rowId -> add-on dollars.

function getLastRemainderPool() {
  if (lastRemainderPool > 0) return lastRemainderPool;
  return (lastStaff || []).reduce((s, p) => s + (p.bonus || 0), 0) + (lastLeftover || 0);
}
function hasManualRemainderOverrides() {
  return !!(remainderOverrides && typeof remainderOverrides === 'object');
}
function getAutoRemainderAllocation(staff, remainderPool) {
  const bonuses = {};
  staff.forEach(p => {
    bonuses[p._rowId] = 0;
  });
  const closers = staff.filter(p => p.closer);
  const perCloser = closers.length ? Math.floor(remainderPool / closers.length) : 0;
  closers.forEach(p => {
    bonuses[p._rowId] = perCloser;
  });
  return {
    bonuses,
    leftover: remainderPool - perCloser * closers.length
  };
}
function sanitizeRemainderOverrides(staff, remainderPool) {
  if (!hasManualRemainderOverrides()) return null;
  const rowIds = staff.map(p => String(p._rowId));
  const clean = {};
  let allocated = 0;
  rowIds.forEach(rowId => {
    const raw = Number(remainderOverrides[rowId] || 0);
    const val = Number.isFinite(raw) ? Math.max(0, Math.floor(raw)) : 0;
    clean[rowId] = val;
    allocated += val;
  });

  // If cash/staff changes made the previous allocation too large, trim from the bottom rows.
  for (let i = rowIds.length - 1; allocated > remainderPool && i >= 0; i--) {
    const rowId = rowIds[i];
    const cut = Math.min(clean[rowId], allocated - remainderPool);
    clean[rowId] -= cut;
    allocated -= cut;
  }
  remainderOverrides = clean;
  return clean;
}
function applyRemainderAllocation(staff, remainderPool) {
  const allocation = hasManualRemainderOverrides() ? {
    bonuses: sanitizeRemainderOverrides(staff, remainderPool) || {},
    manual: true
  } : {
    ...getAutoRemainderAllocation(staff, remainderPool),
    manual: false
  };
  let allocated = 0;
  staff.forEach(p => {
    p.bonus = allocation.bonuses[p._rowId] || 0;
    allocated += p.bonus;
  });
  return {
    remainderPool,
    leftover: Math.max(0, remainderPool - allocated),
    manual: allocation.manual
  };
}
function seedManualRemainderOverrides() {
  if (!lastStaff || !lastStaff.length) return false;
  if (!hasManualRemainderOverrides()) {
    remainderOverrides = {};
    lastStaff.forEach(p => {
      remainderOverrides[p._rowId] = p.bonus || 0;
    });
  }
  return true;
}
function adjustRemainderBonus(rowId, delta) {
  if (!seedManualRemainderOverrides()) return;
  const key = String(rowId);
  const pool = getLastRemainderPool();
  const allocated = Object.values(remainderOverrides).reduce((s, v) => s + (Number(v) || 0), 0);
  const current = Number(remainderOverrides[key] || 0);
  if (delta > 0 && allocated >= pool) return;
  remainderOverrides[key] = Math.max(0, current + delta);
  autoCalculate();
  requestAnimationFrame(renderRemainderSidebar);
}
function resetRemainderAllocation() {
  remainderOverrides = null;
  autoCalculate();
  requestAnimationFrame(renderRemainderSidebar);
}
function openRemainderSidebar() {
  if (shiftMode !== 'night' || !lastStaff || !lastStaff.length || !lastTotal) return;
  renderRemainderSidebar();
  openModal('remainderSidebar');
}
function closeRemainderSidebar() {
  closeModal('remainderSidebar');
}
function renderRemainderSidebar() {
  const body = $('remainder-body');
  if (!body) return;
  if (shiftMode !== 'night' || !lastStaff || !lastStaff.length || !lastTotal) {
    body.innerHTML = '<div class="rem-empty">Enter night-shift cash and staff to see remainder allocation.</div>';
    return;
  }
  const pool = getLastRemainderPool();
  const allocated = lastStaff.reduce((s, p) => s + (p.bonus || 0), 0);
  const remaining = Math.max(0, pool - allocated);
  const manual = hasManualRemainderOverrides();
  const remBillsValue = poolValue(lastRemainderBills || {});
  const canAdd = remaining > 0;
  const rows = lastStaff.map(p => {
    const raw = Number.isFinite(p.exact) ? p.exact.toFixed(2) : '0.00';
    const add = p.bonus || 0;
    const closer = p.closer ? '<span class="rem-closer">closer</span>' : '';
    const minusDisabled = add <= 0 ? ' disabled' : '';
    const plusDisabled = !canAdd ? ' disabled' : '';
    return `<div class="rem-row">
      <div class="rem-person">
        <span class="rem-name">${escapeHTML(p.n)}</span>
        ${closer}
      </div>
      <div class="rem-num rem-raw"><span>Raw</span><strong>$${raw}</strong></div>
      <div class="rem-num rem-floor"><span>Floor</span><strong>$${p.base}</strong></div>
      <div class="rem-stepper" aria-label="Adjust ${escapeHTML(p.n)} remainder add-on">
        <button onclick="adjustRemainderBonus('${escapeHTML(p._rowId)}', -1)"${minusDisabled}>&minus;</button>
        <strong>+$${add}</strong>
        <button onclick="adjustRemainderBonus('${escapeHTML(p._rowId)}', 1)"${plusDisabled}>+</button>
      </div>
      <div class="rem-final"><span>Amt</span><strong>$${p.final}</strong></div>
    </div>`;
  }).join('');
  const remBills = remBillsValue > 0 ? '<div class="rem-bills">' + DENOMS.map(d => {
    const n = lastRemainderBills?.[d] || 0;
    return `<span class="${n ? '' : 'zero'}">$${d} ${n || '—'}</span>`;
  }).join('') + '</div>' : '<div class="rem-bills rem-bills-empty">No remainder bills left in drawer.</div>';
  body.innerHTML = `
    <div class="rem-summary">
      <div><span>Remainder pool</span><strong>$${pool}</strong></div>
      <div><span>Applied</span><strong>$${allocated}</strong></div>
      <div><span>Rem</span><strong>$${remaining}</strong></div>
    </div>
    <div class="rem-mode-row">
      <span>${manual ? 'Manual add-ons are active.' : 'Auto split is using closer badges.'}</span>
      <button onclick="resetRemainderAllocation()"${manual ? '' : ' disabled'}>Reset Auto</button>
    </div>
    <div class="rem-head">
      <span>Person</span><span>Before floor</span><span>Floored</span><span>Add</span><span>Amount</span>
    </div>
    <div class="rem-rows">${rows}</div>
    <div class="rem-bills-title">Remainder bills in drawer</div>
    ${remBills}
  `;
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/remainder.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/shift.js
try { (() => {
// Shift mode toggle — switches between Night and Day shift UI

function setShiftMode(mode, skipConfirm) {
  if (mode === shiftMode) return;

  // Warn if there's existing data
  if (!skipConfirm) {
    const hasNightData = shiftMode === 'night' && (getTotal() > 0 || lastStaff.length > 0);
    const hasDayData = shiftMode === 'day' && lastDayResult !== null;
    if (hasNightData || hasDayData) {
      if (!confirm('Switch shift mode? Current session data will be cleared.')) return;
    }
  }
  shiftMode = mode;
  remainderOverrides = null;
  lastRemainderPool = 0;

  // Toggle tab-panel visibility for cash section
  const nightCash = $('night-cash-section');
  const dayCash = $('day-cash-section');
  if (nightCash) nightCash.style.display = mode === 'night' ? '' : 'none';
  if (dayCash) dayCash.style.display = mode === 'day' ? '' : 'none';

  // Toggle staff sections
  const nightStaff = $('night-staff-section');
  const dayStaff = $('day-staff-section');
  if (nightStaff) nightStaff.style.display = mode === 'night' ? '' : 'none';
  if (dayStaff) dayStaff.style.display = mode === 'day' ? '' : 'none';

  // Update shift toggle buttons
  const btnNight = $('shift-btn-night');
  const btnDay = $('shift-btn-day');
  if (btnNight) btnNight.classList.toggle('active', mode === 'night');
  if (btnDay) btnDay.classList.toggle('active', mode === 'day');

  // Update header subtitle
  const shiftLabel = $('shift-mode-label');
  if (shiftLabel) shiftLabel.textContent = mode === 'night' ? 'Night Shift' : 'Day Shift';

  // Reset results
  if (mode === 'night') {
    lastDayResult = null;
    lastStaff = [];
  } else {
    lastStaff = [];
    // Render day cash panels
    renderDayPoolCashPanels();
  }
  clearStaleBanners();
  renderBlockedPlaceholders(mode === 'night' ? 'Enter cash & staff to calculate.' : 'Enter day shift staff & pool cash to calculate.');
  // Re-apply role filter for the new shift mode
  if (typeof reapplyRoleVisibility === 'function') reapplyRoleVisibility();
  updateShiftStockCards();
  autoCalculate();
  saveState();
}
function updateShiftStockCards() {
  if (shiftMode === 'day') {
    updateDayStockCards();
  } else {
    updateStockCards();
  }
  updateTabIndicators();
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/shift.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/staff.js
try { (() => {
// ── Role helpers ──────────────────────────────────────────────────────────────

function getRoleForList(listId) {
  if (listId === 'supportList') return 'support';
  if (listId === 'nightServerList' || listId === 'serverList') return 'server';
  return 'bartender';
}
function getActiveListId() {
  if (staffViewRole === 'support') return 'supportList';
  if (shiftMode === 'day') {
    return staffViewRole === 'server' ? 'serverList' : 'bartenderList';
  }
  return staffViewRole === 'server' ? 'nightServerList' : 'staffList';
}

// ── Role toggle ───────────────────────────────────────────────────────────────

function switchStaffRole(role) {
  staffViewRole = role;
  document.querySelector('.role-toggle')?.classList.remove('open');

  // Update toggle buttons
  ['bartender', 'server', 'support'].forEach(r => {
    const btn = $('rb-' + r);
    if (btn) btn.classList.toggle('active', r === role);
  });
  _applyRoleVisibility();
  updateRoleDefaultsUI();
  updateRoleViewCount();
}
function onRoleButtonClick(role) {
  const toggle = document.querySelector('.role-toggle');
  if (role === staffViewRole && toggle && !toggle.classList.contains('open')) {
    toggle.classList.add('open');
    return;
  }
  switchStaffRole(role);
}
function _applyRoleVisibility() {
  const role = staffViewRole;
  const isDay = shiftMode === 'day';
  const isSup = role === 'support';

  // Night shift wraps
  const nb = $('night-bar-wrap');
  const ns = $('night-srv-wrap');
  if (nb) nb.style.display = !isDay && !isSup && role === 'bartender' ? '' : 'none';
  if (ns) ns.style.display = !isDay && !isSup && role === 'server' ? '' : 'none';

  // Day shift wraps
  const db = $('day-bar-wrap');
  const ds = $('day-srv-wrap');
  if (db) db.style.display = isDay && !isSup && role === 'bartender' ? '' : 'none';
  if (ds) ds.style.display = isDay && !isSup && role === 'server' ? '' : 'none';

  // Support section (shared across both shifts)
  const sup = $('support-staff-section');
  if (sup) sup.style.display = isSup ? '' : 'none';

  // Re-render support cut chips if day mode
  if (isSup && shiftMode === 'day') refreshSupportCutChips();
}

// Called by setShiftMode after switching — keeps role filter consistent
function reapplyRoleVisibility() {
  _applyRoleVisibility();
  updateRoleViewCount();
}

// ── Per-role default times ────────────────────────────────────────────────────

function updateRoleDefaultsUI() {
  const d = roleDefaults[staffViewRole] || {};
  const i = $('rdef-in'),
    o = $('rdef-out');
  if (i) i.value = d.in || '';
  if (o) o.value = d.out || '';
  // Sync modal fields
  _syncModalRoleFields();
}
function _syncModalRoleFields() {
  const roles = {
    bartender: 'bar',
    server: 'srv',
    support: 'sup'
  };
  Object.entries(roles).forEach(([role, key]) => {
    const d = roleDefaults[role] || {};
    const mi = $('rdef-modal-' + key + '-in'),
      mo = $('rdef-modal-' + key + '-out');
    if (mi) mi.value = d.in || '';
    if (mo) mo.value = d.out || '';
  });
}
function onRoleDefaultChange(field) {
  const el = field === 'in' ? $('rdef-in') : $('rdef-out');
  if (!el) return;
  _setRoleDefault(staffViewRole, field, el.value.trim());
}
function onModalRoleDefaultChange(role, field) {
  const keyMap = {
    bartender: 'bar',
    server: 'srv',
    support: 'sup'
  };
  const el = $('rdef-modal-' + keyMap[role] + '-' + field);
  if (!el) return;
  _setRoleDefault(role, field, el.value.trim());
  // Keep inline fields in sync if viewing this role
  if (role === staffViewRole) updateRoleDefaultsUI();
}
function _setRoleDefault(role, field, val) {
  if (!roleDefaults[role]) return;
  roleDefaults[role][field] = val;
  // Re-render placeholders for rows in this role
  _refreshRolePlaceholders(role, field);
  // Recalculate hours for all rows in this role
  _recalcRoleHours(role);
  autoCalculate();
}
function _refreshRolePlaceholders(role, field) {
  const listIds = _listIdsForRole(role);
  const defaultVal = roleDefaults[role][field] || (field === 'in' ? $('gc-in')?.value.trim() || '' : $('gc-out')?.value.trim() || '');
  listIds.forEach(lid => {
    document.querySelectorAll('#' + lid + ' .staff-row-modal').forEach(r => {
      const el = r.querySelector('[data-field="' + field + '"]');
      if (el && !el.value.trim()) {
        el.placeholder = defaultVal || (field === 'in' ? '—' : '—');
        el.classList.toggle('using-default', !!defaultVal);
      }
    });
  });
}
function _recalcRoleHours(role) {
  const listIds = _listIdsForRole(role);
  listIds.forEach(lid => {
    document.querySelectorAll('#' + lid + ' .staff-row-modal').forEach(r => {
      const id = r.id.replace('staff', '');
      calcHours(id);
    });
  });
}
function _listIdsForRole(role) {
  if (role === 'support') return ['supportList'];
  if (role === 'server') return ['nightServerList', 'serverList'];
  return ['staffList', 'bartenderList'];
}

// ── Tab order & placeholders ──────────────────────────────────────────────────

function reindexTabOrder() {
  const reindex = (listId, offset) => {
    const rows = [...document.querySelectorAll('#' + listId + ' .staff-row-modal')];
    const n = rows.length;
    const role = getRoleForList(listId);
    const defIn = roleDefaults[role]?.in || $('gc-in')?.value.trim() || '';
    const defOut = roleDefaults[role]?.out || $('gc-out')?.value.trim() || '';
    rows.forEach((r, i) => {
      const nameEl = r.querySelector('[data-field="name"]');
      const inEl = r.querySelector('[data-field="in"]');
      const outEl = r.querySelector('[data-field="out"]');
      if (nameEl) {
        nameEl.placeholder = 'Employee ' + (i + 1);
        nameEl.tabIndex = offset + i + 1;
      }
      if (inEl) {
        inEl.tabIndex = offset + n + i + 1;
        inEl.placeholder = defIn || '—';
      }
      if (outEl) {
        outEl.tabIndex = offset + 2 * n + i + 1;
        outEl.placeholder = defOut || '—';
      }
    });
  };
  reindex('staffList', 0);
  reindex('nightServerList', 0);
  reindex('bartenderList', 0);
  reindex('serverList', 100);
  reindex('supportList', 200);
}

// ── Add staff row ─────────────────────────────────────────────────────────────

function addStaff(focusNew, listId) {
  const role = getRoleForList(listId);
  const isSupport = role === 'support';

  // Assign ID from the right counter
  let id;
  if (isSupport) {
    supportId++;
    id = supportId;
  } else if (listId === 'nightServerList' || listId === 'serverList') {
    serverStaffId++;
    id = serverStaffId;
  } else {
    staffId++;
    id = staffId;
  }
  const div = document.createElement('div');
  div.className = 'staff-row-modal' + (isSupport ? ' sup-row' : '');
  div.id = 'staff' + id;
  if (isSupport) {
    div.innerHTML = _supportRowHTML(id, listId);
  } else {
    div.innerHTML = _staffRowHTML(id, listId);
  }
  $(listId).appendChild(div);
  initStaffRowSwipe(div);
  reindexTabOrder();
  calcHours(id);
  updateSectionCounts();
  updateRoleViewCount();
  if (focusNew) setTimeout(() => div.querySelector('[data-field="name"]').focus(), 30);
  saveState();
}
function _staffRowHTML(id, listId) {
  return '<div class="sri-name">' + '<input data-field="name" oninput="onStaffNameInput()" autocomplete="off" autocorrect="off" autocapitalize="words">' + '<div class="sri-meta" id="meta' + id + '">Add times to calculate hours</div>' + '</div>' + '<div class="sri-time-field"><span class="sri-tlbl">in</span>' + '<input data-field="in" inputmode="decimal" oninput="onTimeInput(' + id + ',\'in\')" onchange="calcHours(' + id + ');autoCalculate()">' + '</div>' + '<div class="sri-time-field"><span class="sri-tlbl">out</span>' + '<input data-field="out" inputmode="decimal" oninput="onTimeInput(' + id + ',\'out\')" onchange="calcHours(' + id + ');autoCalculate()">' + '</div>' + '<div class="sri-hrs" id="hrs' + id + '">–</div>' + '<button class="sri-closer" id="ct' + id + '" onclick="toggleCloser(' + id + ')" title="Closer override" tabindex="-1"><span>c</span><span class="sc-lbl">close</span></button>' + '<button class="sri-del" onclick="delStaff(' + id + ',\'' + listId + '\')" tabindex="-1">Delete</button>';
}
function _supportRowHTML(id, listId) {
  // Cut chips are rendered dynamically when switching to day mode
  const cutsHTML = shiftMode === 'day' ? '<div class="sup-cuts" id="sup-cuts-' + id + '">' + _supportCutChipsHTML(String(id)) + '</div>' : '<div class="sup-cuts sup-cuts--hidden" id="sup-cuts-' + id + '"></div>';
  return '<div class="sri-name">' + '<input data-field="name" oninput="onStaffNameInput()" autocomplete="off" autocorrect="off" autocapitalize="words">' + '<div class="sri-meta" id="meta' + id + '">Add times to calculate hours</div>' + '</div>' + '<div class="sri-time-field"><span class="sri-tlbl">in</span>' + '<input data-field="in" inputmode="decimal" oninput="onTimeInput(' + id + ',\'in\')" onchange="calcHours(' + id + ');autoCalculate()">' + '</div>' + '<div class="sri-time-field"><span class="sri-tlbl">out</span>' + '<input data-field="out" inputmode="decimal" oninput="onTimeInput(' + id + ',\'out\')" onchange="calcHours(' + id + ');autoCalculate()">' + '</div>' + '<div class="sri-hrs" id="hrs' + id + '">–</div>' + cutsHTML + '<button class="sri-del" onclick="delStaff(' + id + ',\'supportList\')" tabindex="-1">Delete</button>';
}
function initStaffRowSwipe(row) {
  if (!row || row.dataset.swipeReady) return;
  row.dataset.swipeReady = '1';
  let startX = 0;
  let startY = 0;
  row.addEventListener('touchstart', e => {
    const t = e.touches[0];
    startX = t.clientX;
    startY = t.clientY;
  }, {
    passive: true
  });
  row.addEventListener('touchend', e => {
    if (!startX) return;
    const t = e.changedTouches[0];
    const dx = t.clientX - startX;
    const dy = t.clientY - startY;
    if (Math.abs(dx) > Math.abs(dy) && dx < -44) {
      row.classList.add('swiped');
    } else if (dx > 24 || Math.abs(dx) < 8) {
      row.classList.remove('swiped');
    }
    startX = 0;
    startY = 0;
  }, {
    passive: true
  });
}
function _supportCutChipsHTML(rowId) {
  const activeIds = typeof getDayPoolActiveIds === 'function' ? getDayPoolActiveIds() : [];
  const labels = {
    morning: 'Day',
    middle: 'Mid',
    party1: 'P1',
    party2: 'P2'
  };
  const assigned = supportCutAssignments[rowId] || [];
  return activeIds.map(id => '<button class="sup-cut-chip' + (assigned.includes(id) ? ' active' : '') + '"' + ' onclick="toggleSupportCut(\'' + rowId + '\',\'' + id + '\')">' + escapeHTML(labels[id] || id) + '</button>').join('');
}
function refreshSupportCutChips() {
  document.querySelectorAll('#supportList .sup-row').forEach(r => {
    const rowId = r.id.replace('staff', '');
    const el = $('sup-cuts-' + rowId);
    if (!el) return;
    el.classList.toggle('sup-cuts--hidden', shiftMode !== 'day');
    if (shiftMode === 'day') el.innerHTML = _supportCutChipsHTML(rowId);
  });
}
function toggleSupportCut(rowId, cutId) {
  if (!supportCutAssignments[rowId]) supportCutAssignments[rowId] = [];
  const arr = supportCutAssignments[rowId];
  const idx = arr.indexOf(cutId);
  if (idx >= 0) arr.splice(idx, 1);else arr.push(cutId);
  const el = $('sup-cuts-' + rowId);
  if (el) el.innerHTML = _supportCutChipsHTML(rowId);
  autoCalculate();
  saveState();
}

// ── Event handlers ────────────────────────────────────────────────────────────

function onStaffNameInput() {
  if (shiftMode === 'day') updateDayStockCards();else updateStockCards();
  updateTabIndicators();
  updateRoleViewCount();
  autoCalculate();
}
function delStaff(id, listId) {
  const el = $('staff' + id);
  if (el) el.remove();
  // Clean up support cut assignments
  if (listId === 'supportList') delete supportCutAssignments[String(id)];
  reindexTabOrder();
  updateSectionCounts();
  updateRoleViewCount();
  if (shiftMode === 'day') updateDayStockCards();else updateStockCards();
  updateTabIndicators();
  autoCalculate();
  saveState();
}
function toggleCloser(id) {
  $('ct' + id)?.classList.toggle('on');
  const row = $('staff' + id);
  if (row) _updateStaffMeta(row, $('hrs' + id)?.textContent || '');
  autoCalculate();
}
function _updateStaffMeta(row, hoursText) {
  if (!row) return;
  const id = row.id.replace('staff', '');
  const meta = $('meta' + id);
  if (!meta) return;
  const ctEl = $('ct' + id);
  const outEl = row.querySelector('[data-field="out"]');
  const closer = ctEl && ctEl.classList.contains('on') || !outEl?.value.trim();
  const safeHours = hoursText && hoursText !== '–' ? hoursText + ' hrs' : 'Add times to calculate hours';
  meta.innerHTML = escapeHTML(safeHours) + (closer ? ' <span class="sri-meta-badge">closer</span>' : '');
}
function updateSectionCounts() {
  const bartSelector = shiftMode === 'day' ? '#bartenderList .staff-row-modal' : '#staffList .staff-row-modal';
  const servSelector = shiftMode === 'day' ? '#serverList .staff-row-modal' : '#nightServerList .staff-row-modal';
  const bartCount = [...document.querySelectorAll(bartSelector)].filter(r => r.querySelector('[data-field="name"]').value.trim()).length;
  const servCount = [...document.querySelectorAll(servSelector)].filter(r => r.querySelector('[data-field="name"]').value.trim()).length;
  const supCount = [...document.querySelectorAll('#supportList .staff-row-modal')].filter(r => r.querySelector('[data-field="name"]').value.trim()).length;

  // Keep hidden compat spans in sync
  const spc = $('staffPageCount');
  const spc2 = $('staffPageCount2');
  const bc = $('bartender-count');
  const sc = $('server-count');
  const nightTotal = bartCount + servCount;
  const dayTotal = bartCount + servCount;
  if (spc) spc.textContent = nightTotal + (nightTotal === 1 ? ' person' : ' people');
  if (spc2) spc2.textContent = dayTotal + (dayTotal === 1 ? ' person' : ' people');
  if (bc) bc.textContent = bartCount + (bartCount === 1 ? ' person' : ' people');
  if (sc) sc.textContent = servCount + (servCount === 1 ? ' person' : ' people');
}
function updateRoleViewCount() {
  const el = $('role-view-count');
  const listId = getActiveListId();
  const rows = document.querySelectorAll('#' + listId + ' .staff-row-modal');
  let named = 0;
  rows.forEach(r => {
    if (r.querySelector('[data-field="name"]').value.trim()) named++;
  });
  const roleLabel = {
    bartender: 'bartender',
    server: 'server',
    support: 'support'
  }[staffViewRole] || staffViewRole;
  if (el) el.textContent = named + ' ' + (named === 1 ? roleLabel : roleLabel + 's');
  updateStaffPageChrome(named);
}
function updateStaffPageChrome(namedCount) {
  const title = $('staff-role-title');
  const subtitle = $('staff-role-subtitle');
  const badge = $('staff-role-badge');
  const labels = {
    bartender: {
      title: 'Bartenders',
      badge: 'Bartender',
      cls: 'role-bartender'
    },
    server: {
      title: 'Servers',
      badge: 'Server',
      cls: 'role-server'
    },
    support: {
      title: 'Support',
      badge: 'Support',
      cls: 'role-support'
    }
  };
  const current = labels[staffViewRole] || labels.bartender;
  const modeLabel = shiftMode === 'day' ? 'Day shift' : 'Night shift';
  const countLabel = namedCount === 1 ? '1 named person' : namedCount + ' named people';
  if (title) title.textContent = current.title;
  if (subtitle) subtitle.textContent = modeLabel + ' · ' + countLabel;
  if (badge) {
    badge.textContent = current.badge;
    badge.className = 'role-badge ' + current.cls;
  }
}
function onDefaultTimesChange() {
  reindexTabOrder();
  // Refresh role-aware placeholders for all roles (global fallback may have changed)
  ['bartender', 'server', 'support'].forEach(role => {
    _refreshRolePlaceholders(role, 'in');
    _refreshRolePlaceholders(role, 'out');
  });
  // Recalc hours for every row across all lists
  ['staffList', 'nightServerList', 'bartenderList', 'serverList', 'supportList'].forEach(lid => {
    document.querySelectorAll('#' + lid + ' .staff-row-modal').forEach(r => calcHours(r.id.replace('staff', '')));
  });
  autoCalculate();
}
function onTimeInput(id, field) {
  const row = $('staff' + id);
  if (!row) return;
  const el = row.querySelector('[data-field="' + field + '"]');
  if (el) el.classList.remove('using-default');
  calcHours(id);
}
function _findListForId(id) {
  const lists = ['staffList', 'nightServerList', 'bartenderList', 'serverList', 'supportList'];
  for (const lid of lists) {
    if ($('staff' + id)?.closest('#' + lid)) return lid;
  }
  return null;
}
function calcHours(id) {
  const row = $('staff' + id);
  if (!row) return;
  const inEl = row.querySelector('[data-field="in"]');
  const outEl = row.querySelector('[data-field="out"]');
  const el = $('hrs' + id);

  // Determine role-specific defaults for this row's list
  const listId = _findListForId(id) || '';
  const role = getRoleForList(listId);
  const rDef = roleDefaults[role] || {};
  const defIn = rDef.in || $('gc-in')?.value.trim() || '';
  const defOut = rDef.out || $('gc-out')?.value.trim() || '';
  const inRaw = inEl?.value.trim() || defIn;
  const outRaw = outEl?.value.trim() || defOut;
  const uDI = !inEl?.value.trim() && !!defIn;
  const uDO = !outEl?.value.trim() && !!defOut;
  if (inEl) {
    inEl.classList.toggle('using-default', uDI);
    inEl.placeholder = defIn || '—';
  }
  if (outEl) {
    outEl.classList.toggle('using-default', uDO);
    outEl.placeholder = defOut || '—';
  }
  const inParsed = parseTimeString(inRaw);
  const outParsed = parseTimeString(outRaw);
  setInputInvalid($('gc-in'), !!defIn && !parseTimeString(defIn).valid);
  setInputInvalid($('gc-out'), !!defOut && !parseTimeString(defOut).valid);
  setInputInvalid(inEl, !!inRaw && !inParsed.valid);
  setInputInvalid(outEl, !!outRaw && !outParsed.valid);
  if (!inParsed.valid || !outParsed.valid) {
    if (el) {
      el.textContent = '?';
      el.className = 'sri-hrs err';
    }
    _updateStaffMeta(row, '?');
    _updateCards();
    return;
  }
  if (inParsed.empty || outParsed.empty) {
    if (el) {
      el.textContent = '–';
      el.className = 'sri-hrs';
    }
    _updateStaffMeta(row, '');
    _updateCards();
    return;
  }
  const inV = inParsed.value;
  const outV = outParsed.value;
  let h = outV - inV;
  if (h < 0) h += 12;
  if (h === 0 || h > 12) {
    if (el) {
      el.textContent = '?';
      el.className = 'sri-hrs err';
    }
    _updateStaffMeta(row, '?');
    _updateCards();
    return;
  }
  if (el) {
    el.textContent = fmtHrs(h);
    el.className = 'sri-hrs filled' + (uDI || uDO ? ' default-hrs' : '');
  }
  _updateStaffMeta(row, fmtHrs(h));
  _updateCards();
}
function _updateCards() {
  if (shiftMode === 'day') updateDayStockCards();else updateStockCards();
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/staff.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/state.js
try { (() => {
// Global mutable state — written by calculator, read by renderers
let staffId = 0;
let serverStaffId = 1000; // servers start at 1000 to avoid id collisions
let supportId = 2000; // support staff start at 2000
let livePool = {};
let lastStaff = [];
let lastTotal = 0;
let lastTotH = 0;
let lastRate = 0;
let lastLeftover = 0;
let lastRemainderPool = 0;
let lastPoolAfter = {};
let lastRemainderBills = {};
let lastDistributionError = '';
let _lastDistStaff = [];
let cashMode = 'nettotal';
let perBillSnapshot = {
  100: '',
  50: '',
  20: '',
  10: '',
  5: '',
  1: ''
};
let netBillSnapshot = {
  100: '',
  50: '',
  20: '',
  10: '',
  5: '',
  1: ''
};
let netTotalSnapshot = '';
let isRestoringState = false;
let isUpdatingNetTotal = false;
let currentInputError = '';
let remainderOverrides = null; // null = automatic closer split; object = manual rowId -> add-on dollars

// ── Shift mode ────────────────────────────────────────────────────────────────
// 'night' = current single-pool behaviour
// 'day'   = multi-pool day shift (morning cut + middle cut + optional parties)
let shiftMode = 'night';

// ── Day shift pool state ──────────────────────────────────────────────────────
// Each pool has its own cash entry (per-bill or net-total snapshot).
// poolEnabled flags control whether party pools are active.
let dayPools = {
  morning: {
    cashMode: 'nettotal',
    perBillSnapshot: {
      100: '',
      50: '',
      20: '',
      10: '',
      5: '',
      1: ''
    },
    netBillSnapshot: {
      100: '',
      50: '',
      20: '',
      10: '',
      5: '',
      1: ''
    },
    netTotalSnapshot: ''
  },
  middle: {
    cashMode: 'nettotal',
    perBillSnapshot: {
      100: '',
      50: '',
      20: '',
      10: '',
      5: '',
      1: ''
    },
    netBillSnapshot: {
      100: '',
      50: '',
      20: '',
      10: '',
      5: '',
      1: ''
    },
    netTotalSnapshot: ''
  },
  party1: {
    enabled: false,
    windowStart: '',
    windowEnd: '',
    cashMode: 'nettotal',
    perBillSnapshot: {
      100: '',
      50: '',
      20: '',
      10: '',
      5: '',
      1: ''
    },
    netBillSnapshot: {
      100: '',
      50: '',
      20: '',
      10: '',
      5: '',
      1: ''
    },
    netTotalSnapshot: ''
  },
  party2: {
    enabled: false,
    windowStart: '',
    windowEnd: '',
    cashMode: 'nettotal',
    perBillSnapshot: {
      100: '',
      50: '',
      20: '',
      10: '',
      5: '',
      1: ''
    },
    netBillSnapshot: {
      100: '',
      50: '',
      20: '',
      10: '',
      5: '',
      1: ''
    },
    netTotalSnapshot: ''
  }
};

// ── Staff role toggle ─────────────────────────────────────────────────────────
// Which role tab is active in the staff section
let staffViewRole = 'bartender'; // 'bartender' | 'server' | 'support'

// Per-role default times — explicitly set by the inline/default-time controls.
let roleDefaults = {
  bartender: {
    in: '',
    out: ''
  },
  server: {
    in: '',
    out: ''
  },
  support: {
    in: '',
    out: ''
  }
};

// Support staff cut assignments: rowId → string[] of cut IDs
// e.g. { '2001': ['middle', 'party1'] }
let supportCutAssignments = {};

// Support tip-out overrides per cut (set in the tip-out modal):
// { cutId: { rowId: { hours: number, pct: number } } }
let supportTipOutOverrides = {};

// Which day-shift pool card is currently expanded (accordion — one at a time)
let selectedDayPool = 'morning';

// Last computed day shift results (for rendering)
let lastDayResult = null;
/*
  lastDayResult shape:
  {
    pools: [
      { id: 'morning', label: 'Morning Cut', start, end, total, totalHours, participants: [{name,role,hours,raw}] },
      { id: 'middle',  label: 'Middle Cut',  start, end, total, totalHours, participants: [...] },
      { id: 'party1',  label: 'Party 1',     start, end, total, totalHours, participants: [...] },
      { id: 'party2',  label: 'Party 2',     start, end, total, totalHours, participants: [...] },
    ],
    people: [
      { n, role, _rowId, i, o, h, rawTotal, final, bonus, closer, bills:{} }
    ],
    totalCash, totalPaid, leftover, rate (combined), error
  }
*/

const $ = id => document.getElementById(id);
const DENOMS = [100, 50, 20, 10, 5, 1];
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/state.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/summary.js
try { (() => {
// renderSummary — night shift summary tab
//
// Parameters:
//   staffWithBills  — staff array post-distribution (has .bills assigned)
//   staffOrig       — original staff array from computation (same objects here, kept for API compat)
//   total           — total cash pool
//   totH            — total hours worked
//   rate            — $/hr rate
//   leftover        — dollars remaining in drawer
//   poolAfter       — bill counts remaining after distribution (unused in markup, kept for compat)
//   distCtx         — { remainderBills, distributionError, pool }
//
// No computation globals are read here. All data arrives via parameters.

function renderSummary(staffWithBills, staffOrig, total, totH, rate, leftover, poolAfter, distCtx) {
  const sb = $('stale-summary');
  if (sb) sb.classList.remove('visible');

  // Unpack distribution context, fall back to globals only as a safety net
  // so existing callers that don't pass distCtx still work during migration.
  const remainderBills = distCtx?.remainderBills ?? lastRemainderBills ?? {};
  const distributionError = distCtx?.distributionError ?? lastDistributionError ?? '';
  const pool = distCtx?.pool ?? livePool ?? {};
  const dateVal = $('tipDate').value;
  const [yr, mo, dy] = dateVal ? dateVal.split('-') : ['', '', ''];
  const dateStr = mo && dy && yr ? `${parseInt(mo)}/${parseInt(dy)}/${yr}` : '';
  const sumFinal = staffWithBills.reduce((s, p) => s + p.final, 0);
  const grandTotal = sumFinal + leftover;
  const personCards = staffWithBills.map(p => {
    const safe = escapeHTML(p.n);
    const initials = escapeHTML(p.n.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2));
    const inStr = fmtTime(p.i, p.i, false);
    const outStr = fmtTime(p.o, p.i, p.o < p.i);
    const closerBadge = p.closer ? '<span class="closer-badge">closer</span>' : '';
    const bonusLine = p.bonus > 0 ? `<div class="person-bonus-row">
           <span class="person-bonus-base">${p.base}</span>
           <span class="person-bonus-pill">+${p.bonus}</span>
         </div>` : `<div class="person-bonus-row">
           <span class="person-bonus-base person-bonus-base--only">${p.base}</span>
         </div>`;
    return `<div class="person-card" onclick="openPersonModal('${escapeHTML(p._rowId)}')">
      <div class="person-card-top">
        <div class="person-avatar">${initials}</div>
        <div class="person-main">
          <div class="person-name-row"><span class="person-name">${safe}</span>${closerBadge}</div>
        </div>
        <div class="person-hrs-block">
          <div class="person-hrs-val">${fmtHrs(p.h)}</div>
          <div class="person-hrs-times">${inStr}–${outStr}</div>
        </div>
        <div class="person-tip-col">
          <div class="person-tip">${p.final}</div>
          ${bonusLine}
        </div>
      </div>
    </div>`;
  }).join('');
  const remainderCard = leftover > 0 ? `<div class="person-card remainder-card">
        <div class="person-card-top">
          <div class="person-avatar remainder-avatar">R</div>
          <div class="person-main">
            <div class="person-name-row"><span class="person-name" style="color:var(--muted)">Remainder</span></div>
          </div>
          <div class="person-hrs-block">
            <div class="person-hrs-val muted" style="font-size:.72rem">stays</div>
            <div class="person-hrs-times">in drawer</div>
          </div>
          <div class="person-tip-col"><div class="person-tip muted">$${leftover}</div></div>
        </div>
      </div>` : '';
  const leftoverMeta = leftover > 0 ? `<div class="summary-meta-item"><div class="summary-meta-lbl">Remainder</div><div class="summary-meta-val" style="color:var(--muted)">$${leftover}</div></div>` : '';
  const unpaid = staffWithBills.reduce((s, p) => s + Math.max(0, p.rem || 0), 0);
  const remainderPaid = poolValue(remainderBills);
  const remShort = leftover > 0 && remainderPaid !== leftover;
  const warnMsg = distributionError || (unpaid > 0 ? 'Distribution short $' + unpaid : remShort ? 'Remainder cannot be represented by available bills' : '');
  let warnHTML = '';
  if (warnMsg) {
    const req = getSmallBillRequirements(staffWithBills, pool, leftover);
    const reqHTML = renderRequirementSummary(req, pool);
    warnHTML = `<div class="warn-box">⚠ ${escapeHTML(warnMsg)} ` + `<button onclick="switchTab('cash',$('tb-cash'))" style="background:none;border:none;color:inherit;text-decoration:underline;cursor:pointer;padding:0;font:inherit;font-weight:700">→ Go to Cash</button></div>` + reqHTML;
  }
  $('summary-content').innerHTML = `
    <div class="summary-hero">
      <div class="summary-hero-label">Total Pool${dateStr ? ' · ' + dateStr : ''}</div>
      <div class="summary-hero-val">$${total}</div>
      <div class="summary-meta">
        <div class="summary-meta-item"><div class="summary-meta-lbl">Total Hrs</div><div class="summary-meta-val">${fmtHrs(totH)}</div></div>
        <div class="summary-meta-item"><div class="summary-meta-lbl">Rate</div><div class="summary-meta-val">$${rate.toFixed(2)}/hr</div></div>
        <div class="summary-meta-item"><div class="summary-meta-lbl">Paid Out</div><div class="summary-meta-val">$${sumFinal}</div></div>
        ${leftoverMeta}
      </div>
    </div>
    <div class="section-hdr">Breakdown</div>
    <div class="summary-breakdown-head"><span></span><span></span><span>Hrs</span><span>Tip</span></div>
    ${personCards}
    ${remainderCard}
    <div class="summary-totals-strip">
      <span class="summary-totals-lbl">Total</span>
      <div class="summary-totals-right">
        <span class="summary-totals-hrs">${fmtHrs(totH)}</span>
        <span class="summary-totals-val">$${grandTotal}</span>
      </div>
    </div>
    ${warnHTML}
  `;
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/summary.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/summary_day.js
try { (() => {
// Day shift summary renderer
//
// renderDaySummary(result, distCtx)
//   result  — from calculateDayShift()
//   distCtx — { remainderBills, distributionError, poolAfter, mergedBills }
//
// renderDayDist(result, distCtx)
//   same shapes
//
// updateHomeLiveDay(result, distCtx)
//   distCtx — { distributionError } (only field needed here)

function renderDaySummary(result, distCtx) {
  const sb = $('stale-summary');
  if (sb) sb.classList.remove('visible');

  // Unpack; fall back to globals for callers that predate this parameter.
  const distributionError = distCtx?.distributionError ?? lastDistributionError ?? '';
  const dateVal = $('tipDate').value;
  const [yr, mo, dy] = dateVal ? dateVal.split('-') : ['', '', ''];
  const dateStr = mo && dy && yr ? `${parseInt(mo)}/${parseInt(dy)}/${yr}` : '';

  // ── Helpers ──────────────────────────────────────────────────────────────

  const fmtAbs = t => {
    const isAm = t < 12;
    const hr = Math.floor(t);
    const mn = Math.round((t - hr) * 60);
    let h12 = hr % 12;
    if (h12 === 0) h12 = 12;
    const minStr = mn > 0 ? ':' + (mn < 10 ? '0' : '') + mn : ':00';
    return h12 + minStr + ' ' + (isAm ? 'AM' : 'PM');
  };
  const fmtH = h => parseFloat(h.toFixed(2)).toString();

  // Active pools only
  const pools = result.pools.filter(p => p.total > 0 || p.participants.length > 0);
  const poolLabel = p => {
    if (p.id === 'morning') return 'Day';
    if (p.id === 'middle') return 'Mid';
    const partyPools = pools.filter(x => x.id.startsWith('party'));
    if (partyPools.length === 1) return 'Party';
    return 'Party ' + (partyPools.indexOf(p) + 1);
  };
  const totalCash = result.totalCash;
  const totalHoursAll = result.people.reduce((s, p) => s + p.totalHours, 0);
  const totalPaidSum = result.people.reduce((s, p) => s + p.final, 0);
  const colCount = pools.length + 2;

  // ── Column header row ─────────────────────────────────────────────────────

  const thCols = pools.map(p => `<th class="ds-pool-col">${escapeHTML(poolLabel(p))}</th>`).join('') + '<th class="ds-total-col">Total</th>';

  // ── Metadata rows ─────────────────────────────────────────────────────────

  const metaRows = [{
    label: 'Start',
    vals: pools.map(p => fmtAbs(p.start)),
    total: null
  }, {
    label: 'End',
    vals: pools.map(p => fmtAbs(p.end)),
    total: null
  }, {
    label: 'Hours',
    vals: pools.map(p => fmtH(p.end - p.start)),
    total: null
  }, {
    label: 'Tips',
    vals: pools.map(p => p.total > 0 ? p.total : '—'),
    total: totalCash,
    boldTotal: true
  }, {
    label: 'Hours',
    vals: pools.map(p => p.totalHours > 0 ? fmtH(p.totalHours) : '—'),
    total: fmtH(totalHoursAll)
  }, {
    label: 'Hourly',
    vals: pools.map(p => p.totalHours > 0 ? (p.total / p.totalHours).toFixed(2) : '—'),
    total: totalHoursAll > 0 ? (totalCash / totalHoursAll).toFixed(2) : '—'
  }];
  const metaTbody = metaRows.map(row => {
    const tds = row.vals.map(v => `<td class="ds-pool-col">${escapeHTML(String(v))}</td>`).join('');
    const tot = row.total != null ? `<td class="ds-total-col${row.boldTotal ? ' ds-bold' : ''}">${escapeHTML(String(row.total))}</td>` : `<td class="ds-total-col ds-muted">—</td>`;
    return `<tr class="ds-meta-row"><td class="ds-label-col">${escapeHTML(row.label)}</td>${tds}${tot}</tr>`;
  }).join('');

  // ── Person rows ───────────────────────────────────────────────────────────

  const personRows = result.people.map(p => {
    const name = escapeHTML(p.n);
    const roleBadge = `<span class="ds-role-badge ds-role-${p.role}">${p.role === 'bartender' ? 'bar' : 'srv'}</span>`;
    const closerDot = p.closer ? '<span class="ds-closer-dot"></span>' : '';
    const tds = pools.map(pool => {
      const raw = p.rawShares[pool.id] || 0;
      if (raw <= 0) return '<td class="ds-pool-col ds-empty">—</td>';
      const hrs = pool.participants.find(px => px.name === p.n)?.hours || 0;
      return `<td class="ds-pool-col ds-person-cell">
        <span class="ds-pay">${Math.floor(raw)}</span><span class="ds-hrs">${fmtH(hrs)}h</span>
      </td>`;
    }).join('');
    return `<tr class="ds-person-row">
      <td class="ds-label-col ds-name-cell">${name}${roleBadge}${closerDot}</td>
      ${tds}
      <td class="ds-total-col ds-bold">$${p.final}</td>
    </tr>`;
  }).join('');

  // ── Totals row ────────────────────────────────────────────────────────────

  const totalsTds = pools.map(pool => {
    const paid = pool.participants.reduce((s, px) => s + Math.floor(px.raw), 0);
    const hrs = fmtH(pool.totalHours);
    return `<td class="ds-pool-col ds-person-cell ds-totals-cell">
      <span class="ds-pay">${paid > 0 ? paid : '—'}</span><span class="ds-hrs">${hrs}h</span>
    </td>`;
  }).join('');
  const totalPaidWithSupport = totalPaidSum + (result.supportPeople || []).reduce((s, p) => s + p.final, 0);
  const totalsRow = `<tr class="ds-totals-row">
    <td class="ds-label-col">Total</td>
    ${totalsTds}
    <td class="ds-total-col ds-bold">$${totalPaidWithSupport}</td>
  </tr>`;

  // ── Remainder row ─────────────────────────────────────────────────────────

  const remRow = result.leftover > 0 ? `<tr class="ds-rem-row">
        <td class="ds-label-col">Remainder</td>
        ${pools.map(() => '<td class="ds-pool-col"></td>').join('')}
        <td class="ds-total-col ds-muted-val">$${result.leftover}</td>
      </tr>` : '';

  // ── Warn box ──────────────────────────────────────────────────────────────

  const warnHTML = distributionError ? `<div class="warn-box" style="margin-top:8px">⚠ ${escapeHTML(distributionError)}
        <button onclick="switchTab('cash',$('tb-cash'))" style="background:none;border:none;color:inherit;text-decoration:underline;cursor:pointer;padding:0;font:inherit;font-weight:700">→ Go to Cash</button>
       </div>` : '';

  // ── Assemble ──────────────────────────────────────────────────────────────

  $('summary-content').innerHTML = `
    <div class="ds-hero">
      <div class="ds-hero-label">Day Shift${dateStr ? ' · ' + dateStr : ''}</div>
      <div class="ds-hero-val">$${result.totalCash}</div>
    </div>
    <div class="ds-table-wrap">
      <table class="ds-table">
        <thead>
          <tr>
            <th class="ds-label-col ds-cut-hdr">Cut</th>
            ${thCols}
          </tr>
        </thead>
        <tbody>
          ${metaTbody}
          <tr class="ds-divider"><td colspan="${colCount}"></td></tr>
          <tr class="ds-name-hdr">
            <th class="ds-label-col">Name</th>
            ${pools.map(p => `<th class="ds-pool-col">${escapeHTML(poolLabel(p))}</th>`).join('')}
            <th class="ds-total-col">Total</th>
          </tr>
          ${personRows}
          ${totalsRow}
          ${remRow}
          ${_renderSupportSummaryRows(result, colCount, pools)}
        </tbody>
      </table>
    </div>
    ${warnHTML}
  `;
}
function _renderSupportSummaryRows(result, colCount, pools) {
  const sup = result.supportPeople || [];
  if (!sup.length) return '';
  const tipOuts = result.supportTipOuts || {};
  const rows = sup.map(p => {
    // Show per-cut tip-out in each pool column
    const cutCells = pools.map(pool => {
      const cutItems = tipOuts[pool.id] || [];
      const item = cutItems.find(x => x.rowId === p._rowId);
      return item && item.tipOut > 0 ? `<td class="ds-pool-col ds-person-cell"><span class="ds-pay">${item.tipOut}</span></td>` : `<td class="ds-pool-col ds-empty">—</td>`;
    }).join('');
    return `<tr class="ds-person-row ds-support-row">
      <td class="ds-label-col ds-name-cell">
        ${escapeHTML(p.n)}<span class="ds-role-badge ds-role-support">sup</span>
      </td>
      ${cutCells}
      <td class="ds-total-col ds-bold ds-support-val">$${p.final}</td>
    </tr>`;
  }).join('');
  const total = sup.reduce((s, p) => s + p.final, 0);
  const totalCutCells = pools.map(pool => {
    const poolTotal = (tipOuts[pool.id] || []).reduce((s, x) => s + x.tipOut, 0);
    return poolTotal > 0 ? `<td class="ds-pool-col ds-person-cell"><span class="ds-pay">${poolTotal}</span></td>` : `<td class="ds-pool-col ds-empty">—</td>`;
  }).join('');
  return `<tr class="ds-divider"><td colspan="${colCount}"></td></tr>
    <tr class="ds-name-hdr">
      <th class="ds-label-col" style="color:#9d7dca;letter-spacing:.8px">Support Tip-Out</th>
      ${pools.map(p => `<th class="ds-pool-col" style="color:#9d7dca">${escapeHTML(p.id === 'morning' ? 'Day' : p.id === 'middle' ? 'Mid' : p.id)}</th>`).join('')}
      <th class="ds-total-col" style="color:#9d7dca">Total</th>
    </tr>
    ${rows}
    <tr class="ds-support-total-row">
      <td class="ds-label-col" style="color:var(--muted)">Total</td>
      ${totalCutCells}
      <td class="ds-total-col ds-bold ds-support-val">$${total}</td>
    </tr>`;
}

// ── Day shift dist renderer ───────────────────────────────────────────────────

function renderDayDist(result, distCtx) {
  const sb = $('stale-dist');
  if (sb) sb.classList.remove('visible');

  // Unpack; fall back to globals for backward compat.
  const remainderBills = distCtx?.remainderBills ?? lastRemainderBills ?? {};
  const distributionError = distCtx?.distributionError ?? lastDistributionError ?? '';

  // Include support people (already in distCtx.staffWithBills) in unpaid check
  const allStaff = distCtx?.staffWithBills ?? [...result.people, ...(result.supportPeople || [])];
  const unpaid = allStaff.reduce((s, p) => s + Math.max(0, p.rem || 0), 0);
  const hasErr = !!distributionError || unpaid > 0;
  const errMsg = distributionError || (unpaid > 0 ? 'Distribution short $' + unpaid : '');
  const hCols = DENOMS.map(d => `<th><span class="dist-tbl-denom">${d}</span></th>`).join('') + '<th class="total-col"><span class="dist-tbl-denom" style="color:var(--text2)">TOT</span></th>';
  const roleLbl = p => p.role === 'support' ? 'sup' : p.role === 'bartender' ? 'bar' : 'srv';
  const rows = allStaff.map(p => {
    const safe = escapeHTML(p.n);
    const roleCls = p.role || 'bartender';
    const roleBadge = `<span class="role-badge role-${roleCls}" style="margin-left:3px">${roleLbl(p)}</span>`;
    const pt = DENOMS.reduce((s, d) => s + (p.bills[d] || 0) * d, 0);
    const cols = DENOMS.map(d => {
      const n = p.bills[d] || 0;
      return n > 0 ? `<td class="has-bills">${n}</td>` : `<td class="zero">—</td>`;
    }).join('');
    return `<tr><td>${safe}${roleBadge}</td>${cols}<td class="person-total">$${pt}</td></tr>`;
  }).join('');
  let remRow = '';
  if (result.leftover > 0) {
    const rc = DENOMS.map(d => {
      const n = remainderBills[d] || 0;
      return n > 0 ? `<td style="color:var(--muted);font-weight:600;font-size:.74rem">${n}</td>` : `<td class="zero">—</td>`;
    }).join('');
    remRow = `<tr class="dist-rem-row"><td>Rem</td>${rc}<td style="color:var(--muted);font-weight:600;border-left:1px solid var(--border);font-size:.74rem">$${result.leftover}</td></tr>`;
  }
  const dtCols = DENOMS.map(d => {
    const t = allStaff.reduce((s, p) => s + (p.bills[d] || 0), 0) + (remainderBills[d] || 0);
    return t > 0 ? `<td style="color:var(--gold)">${t}</td>` : `<td class="zero">—</td>`;
  }).join('');
  const dGT = allStaff.reduce((s, p) => s + DENOMS.reduce((ss, d) => ss + (p.bills[d] || 0) * d, 0), 0) + poolValue(remainderBills);
  const totalRow = `<tr class="dist-totals-row"><td>Total</td>${dtCols}<td class="grand-total">$${dGT}</td></tr>`;
  const tableHTML = `<div class="dist-tbl-wrap"><table class="dist-tbl">
    <colgroup><col class="dist-name-col">${DENOMS.map(() => '<col class="dist-bill-col">').join('')}<col class="dist-total-col"></colgroup>
    <thead><tr><th>Name</th>${hCols}</tr></thead>
    <tbody>${rows}${remRow}</tbody>
    <tfoot>${totalRow}</tfoot>
  </table></div>`;
  const errHTML = hasErr ? `<div class="warn-box" style="margin-bottom:10px">⚠ ${escapeHTML(errMsg)} <button onclick="switchTab('cash',$('tb-cash'))" style="background:none;border:none;color:inherit;text-decoration:underline;cursor:pointer;padding:0;font:inherit;font-weight:700">→ Go to Cash</button></div>` : '';
  $('dist-content').innerHTML = errHTML + tableHTML;
}

// ── Day shift home live update ────────────────────────────────────────────────

function updateHomeLiveDay(result, distCtx) {
  const sec = $('home-live-section');
  if (!sec) return;
  if (!result) {
    sec.innerHTML = `<div class="home-dashboard">
      <div class="home-status-card idle">
        <div class="home-status-label">Session status</div>
        <div class="home-status-title">Enter day shift staff &amp; cash</div>
        <div class="home-status-sub">Add bartenders and servers with shift times</div>
      </div>
      <div class="home-action-grid">
        <button onclick="switchTab('cash', $('tb-cash'))"><span>Cash</span><em>pools</em></button>
        <button onclick="switchTab('staff', $('tb-staff'))"><span>Staff</span><em>bartenders</em></button>
        <button onclick="switchTab('summary', $('tb-summary'))"><span>Summary</span><em>pending</em></button>
        <button onclick="switchTab('dist', $('tb-dist'))"><span>Dist</span><em>pending</em></button>
      </div>
    </div>`;
    return;
  }

  // Unpack; fall back to global for backward compat.
  const distributionError = distCtx?.distributionError ?? lastDistributionError ?? '';
  const distOk = !distributionError;
  const statusText = currentInputError || (distOk ? 'Distribution ready' : 'Adjust bill counts in Cash');
  const statusClass = currentInputError ? 'warn' : distOk ? 'ok' : 'warn';
  const nBart = result.people.filter(p => p.role === 'bartender').length;
  const nServ = result.people.filter(p => p.role === 'server').length;
  sec.innerHTML = `<div class="home-dashboard">
    <div class="home-status-card ${statusClass}">
      <div class="home-status-label">Day Shift · Session status</div>
      <div class="home-status-title">${statusText}</div>
      <div class="home-status-sub">${nBart} bartender${nBart !== 1 ? 's' : ''} · ${nServ} server${nServ !== 1 ? 's' : ''} · $${result.totalCash} total</div>
    </div>
    <div class="home-metric-grid">
      <div class="home-metric"><span>Pools</span><strong>${result.pools.length}</strong></div>
      <div class="home-metric"><span>Paid Out</span><strong>$${result.totalPaid}</strong></div>
      <div class="home-metric"><span>Remainder</span><strong>${result.leftover > 0 ? '$' + result.leftover : '—'}</strong></div>
    </div>
    <div class="home-action-grid">
      <button onclick="switchTab('cash', $('tb-cash'))"><span>Cash</span><em>$${result.totalCash}</em></button>
      <button onclick="switchTab('staff', $('tb-staff'))"><span>Staff</span><em>${result.people.length} people</em></button>
      <button onclick="switchTab('summary', $('tb-summary'))"><span>Summary</span><em>${distOk ? 'ready' : 'pending'}</em></button>
      <button onclick="switchTab('dist', $('tb-dist'))"><span>Dist</span><em>${distOk ? 'ready' : 'check bills'}</em></button>
    </div>
  </div>`;
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/summary_day.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/support.js
try { (() => {
// Support staff helpers — cut assignments, overlap hours, tip-out modal

// ── Collect support rows ──────────────────────────────────────────────────────

function collectSupportRows() {
  const rows = document.querySelectorAll('#supportList .staff-row-modal');
  const result = [];
  rows.forEach(r => {
    const name = r.querySelector('[data-field="name"]').value.trim();
    if (!name) return;
    const rowId = r.id.replace('staff', '');
    const inEl = r.querySelector('[data-field="in"]');
    const outEl = r.querySelector('[data-field="out"]');
    const defIn = roleDefaults.support?.in || $('gc-in')?.value.trim() || '';
    const defOut = roleDefaults.support?.out || $('gc-out')?.value.trim() || '';
    const inStr = inEl?.value.trim() || defIn;
    const outStr = outEl?.value.trim() || defOut;
    const inP = parseTimeString(inStr);
    const outP = parseTimeString(outStr);
    // Convert to absolute day-shift hours (same scale as engine_day.js)
    const inAbs = inP.valid && !inP.empty ? dayShiftAbsolute(inP.value) : null;
    const outAbs = outP.valid && !outP.empty ? dayShiftAbsolute(outP.value) : null;
    result.push({
      name,
      rowId,
      inAbs,
      outAbs,
      cuts: supportCutAssignments[rowId] || []
    });
  });
  return result;
}

// ── Cut window helpers ────────────────────────────────────────────────────────

// Returns { morning, middle, party1?, party2? } window {start, end} in absolute hours.
// Windows are derived from staffRows (same logic as engine_day.js deriveDayShiftWindows).
function deriveSupportCutWindows(poolCash, partyConfig, bartenderRows, serverRows) {
  // Parse absolute times for all tipped staff
  const toAbs = rows => rows.map(r => {
    const defIn = roleDefaults.bartender?.in || roleDefaults.server?.in || $('gc-in')?.value.trim() || '';
    const defOut = roleDefaults.bartender?.out || roleDefaults.server?.out || $('gc-out')?.value.trim() || '';
    const inStr = r.inStr || defIn;
    const outStr = r.outStr || defOut;
    const inP = parseTimeString(inStr);
    const outP = parseTimeString(outStr);
    return {
      inAbs: inP.valid && !inP.empty ? dayShiftAbsolute(inP.value) : null,
      outAbs: outP.valid && !outP.empty ? dayShiftAbsolute(outP.value) : null,
      hasExplicitOut: !!r.outStr,
      role: r.role
    };
  });
  const bars = toAbs(bartenderRows);
  const srvs = toAbs(serverRows);
  const all = [...bars, ...srvs];
  const inTimes = all.map(p => p.inAbs).filter(t => t !== null);
  if (!inTimes.length) return null;
  const morningStart = Math.min(...inTimes);
  const srvOuts = srvs.filter(p => p.hasExplicitOut && p.outAbs !== null).map(p => p.outAbs);
  if (!srvOuts.length) return null;
  const morningEnd = Math.max(...srvOuts);
  const barOuts = bars.filter(p => p.hasExplicitOut && p.outAbs !== null).map(p => p.outAbs);
  if (!barOuts.length) return null;
  const middleEnd = Math.max(...barOuts);
  if (morningEnd <= morningStart || middleEnd <= morningEnd) return null;
  const windows = {
    morning: {
      start: morningStart,
      end: morningEnd
    },
    middle: {
      start: morningEnd,
      end: middleEnd
    }
  };

  // Party pools use explicit window inputs
  ['party1', 'party2'].forEach(pid => {
    const cfg = partyConfig?.[pid];
    if (!cfg?.enabled) return;
    const sp = parseTimeString(cfg.start || '');
    const ep = parseTimeString(cfg.end || '');
    if (sp.valid && !sp.empty && ep.valid && !ep.empty) {
      windows[pid] = {
        start: dayShiftAbsolute(sp.value),
        end: dayShiftAbsolute(ep.value)
      };
    }
  });
  return windows;
}

// Hours a support person overlaps with a cut window
function supportOverlapHours(person, win) {
  if (person.inAbs === null || person.outAbs === null) return 0;
  const start = Math.max(person.inAbs, win.start);
  const end = Math.min(person.outAbs, win.end);
  return Math.max(0, parseFloat((end - start).toFixed(4)));
}

// ── Compute tip-outs ──────────────────────────────────────────────────────────

// Returns { cutId: [ { name, rowId, hours, pct, tipOut, cutHours, ratePerHr } ] }
function computeAllSupportTipOuts(rawPoolCash, partyConfig, supportPeople) {
  if (!supportPeople || !supportPeople.length) return {};

  // Collect tipped staff rows to derive cut windows
  const bartenderRows = _collectDayTippedRows('bartenderList', 'bartender');
  const serverRows = _collectDayTippedRows('serverList', 'server');
  const windows = deriveSupportCutWindows(rawPoolCash, partyConfig, bartenderRows, serverRows);
  if (!windows) return {};
  const result = {};
  Object.entries(windows).forEach(([cutId, win]) => {
    const cutTotal = rawPoolCash[cutId] || 0;
    if (cutTotal <= 0) return;
    const cutHours = win.end - win.start;
    if (cutHours <= 0) return;
    const ratePerHr = cutTotal / cutHours;
    const items = supportPeople.filter(p => p.cuts.includes(cutId)).map(p => {
      const override = supportTipOutOverrides[cutId]?.[p.rowId];
      const hours = override?.hours !== undefined ? override.hours : supportOverlapHours(p, win);
      const pct = override?.pct !== undefined ? override.pct : 10;
      const tipOut = Math.floor(hours * ratePerHr * pct / 100);
      return {
        name: p.name,
        rowId: p.rowId,
        hours,
        pct,
        tipOut,
        cutHours,
        ratePerHr
      };
    });
    if (items.length) result[cutId] = items;
  });
  return result;
}
function _collectDayTippedRows(listId, role) {
  const rows = document.querySelectorAll('#' + listId + ' .staff-row-modal');
  const result = [];
  rows.forEach(r => {
    const name = r.querySelector('[data-field="name"]').value.trim();
    if (!name) return;
    const inEl = r.querySelector('[data-field="in"]');
    const outEl = r.querySelector('[data-field="out"]');
    result.push({
      inStr: inEl?.value.trim() || '',
      outStr: outEl?.value.trim() || '',
      role
    });
  });
  return result;
}

// ── Aggregate support tip-outs into distributable people objects ──────────────

// Returns an array of support person objects (same shape as engineResult.people)
// with final = sum of tip-outs across all their assigned cuts.
function aggregateSupportForDist(supportTipOuts) {
  const byPerson = {};
  Object.values(supportTipOuts).forEach(items => {
    items.forEach(item => {
      if (!byPerson[item.rowId]) {
        byPerson[item.rowId] = {
          n: item.name,
          _rowId: item.rowId,
          role: 'support',
          final: 0,
          h: 0,
          i: 0,
          o: 0,
          eo: 0,
          closer: false,
          _autoCloser: false,
          base: 0,
          bonus: 0,
          rawShares: {},
          bills: {}
        };
      }
      byPerson[item.rowId].final += item.tipOut;
      byPerson[item.rowId].h += item.hours;
    });
  });
  return Object.values(byPerson).filter(p => p.final > 0);
}

// ── Tip-out modal ─────────────────────────────────────────────────────────────

let _tipOutModalCutId = null; // which cut is open

function openSupportTipOutModal(cutId) {
  _tipOutModalCutId = cutId;
  const cutLabels = {
    morning: 'Morning Cut',
    middle: 'Middle Cut',
    party1: 'Party 1',
    party2: 'Party 2'
  };
  const result = lastDayResult;
  if (!result) return;
  const tipOuts = result.supportTipOuts || {};
  const items = tipOuts[cutId] || [];
  const rawCash = result.rawPoolCash?.[cutId] || 0;
  const adjCash = rawCash - items.reduce((s, x) => s + x.tipOut, 0);
  const win = _getCutWindowForModal(cutId);
  const winStr = win ? _fmtAbsTime(win.start) + '–' + _fmtAbsTime(win.end) + ' (' + parseFloat(win.end - win.start).toFixed(2) + ' hrs)' : '—';
  $('supportModalTitle').textContent = (cutLabels[cutId] || cutId) + ' · Support Tip-Out';
  if (!items.length) {
    $('supportModalBody').innerHTML = `
      <div style="color:var(--muted);font-size:.8rem;padding:8px 0">
        No support staff assigned to this cut.<br>
        <em style="font-size:.7rem">Go to Staff → Support and assign cuts to each support person.</em>
      </div>`;
    openModal('supportTipOutModal');
    return;
  }
  const totalTipOut = items.reduce((s, x) => s + x.tipOut, 0);
  const ratePerHr = items[0]?.ratePerHr || 0;
  const cutHrs = items[0]?.cutHours || 0;
  const cards = items.map(item => `
    <div class="stom-card" id="stom-card-${item.rowId}">
      <div class="stom-name">${escapeHTML(item.name)}</div>
      <div class="stom-fields">
        <div class="stom-field">
          <span class="stom-lbl">Hours in cut</span>
          <input class="stom-input" id="stom-hrs-${item.rowId}" type="number" min="0" step="0.25"
            value="${parseFloat(item.hours.toFixed(2))}"
            oninput="onSupportModalInput('${item.rowId}','hrs')">
          <span class="stom-sub">${parseFloat(item.hours.toFixed(2))} / ${parseFloat(cutHrs.toFixed(2))} hrs
            (${cutHrs > 0 ? (item.hours / cutHrs * 100).toFixed(1) : 0}%)</span>
        </div>
        <div class="stom-field">
          <span class="stom-lbl">Rate %</span>
          <input class="stom-input" id="stom-pct-${item.rowId}" type="number" min="0" step="1"
            value="${item.pct}"
            oninput="onSupportModalInput('${item.rowId}','pct')">
          <span class="stom-sub">$${ratePerHr.toFixed(2)}/hr × ${item.pct}%</span>
        </div>
        <div class="stom-field stom-field--tip">
          <span class="stom-lbl">Tip out</span>
          <input class="stom-input stom-input--tip" id="stom-tip-${item.rowId}" type="number" min="0" step="1"
            value="${item.tipOut}"
            oninput="onSupportModalInput('${item.rowId}','tip')">
          <span class="stom-sub">floor(hrs × rate × %)</span>
        </div>
      </div>
    </div>`).join('');
  $('supportModalBody').innerHTML = `
    <div class="stom-meta">
      <div class="stom-meta-row"><span class="stom-meta-lbl">Window</span><span class="stom-meta-val">${escapeHTML(winStr)}</span></div>
      <div class="stom-meta-row"><span class="stom-meta-lbl">Cut tips</span><span class="stom-meta-val">$${rawCash}</span></div>
      <div class="stom-meta-row"><span class="stom-meta-lbl">Tips/hr</span><span class="stom-meta-val">$${ratePerHr.toFixed(2)}</span></div>
    </div>
    <div class="stom-note">Each field is interdependent — editing one recalculates the others.</div>
    ${cards}
    <div class="stom-totals">
      <div class="stom-total-row">
        <span class="stom-total-lbl">Total tip-out</span>
        <span class="stom-total-val" id="stom-total">$${totalTipOut}</span>
      </div>
      <div class="stom-total-row">
        <span class="stom-total-lbl">Remaining for pool</span>
        <span class="stom-total-val stom-adj" id="stom-adj">$${adjCash}</span>
      </div>
    </div>`;
  openModal('supportTipOutModal');
}
function onSupportModalInput(rowId, changedField) {
  const cutId = _tipOutModalCutId;
  if (!cutId) return;
  const result = lastDayResult;
  if (!result) return;
  const tipOuts = result.supportTipOuts?.[cutId] || [];
  const item = tipOuts.find(x => x.rowId === rowId);
  if (!item) return;
  const hrsEl = $('stom-hrs-' + rowId);
  const pctEl = $('stom-pct-' + rowId);
  const tipEl = $('stom-tip-' + rowId);
  let hours = parseFloat(hrsEl?.value) || 0;
  let pct = parseFloat(pctEl?.value) || 0;
  let tipOut = parseFloat(tipEl?.value);
  const rate = item.ratePerHr;
  if (changedField === 'hrs' || changedField === 'pct') {
    tipOut = Math.floor(hours * rate * pct / 100);
    if (tipEl) tipEl.value = tipOut;
  } else if (changedField === 'tip') {
    // Back-solve for pct given hours
    tipOut = Math.floor(tipOut);
    pct = hours > 0 && rate > 0 ? parseFloat((tipOut / (hours * rate) * 100).toFixed(1)) : 0;
    if (pctEl) pctEl.value = pct;
  }

  // Save overrides and recalculate
  if (!supportTipOutOverrides[cutId]) supportTipOutOverrides[cutId] = {};
  supportTipOutOverrides[cutId][rowId] = {
    hours,
    pct
  };

  // Update totals display
  const rawCash = result.rawPoolCash?.[cutId] || 0;
  const allCards = document.querySelectorAll('.stom-card');
  let newTotal = 0;
  allCards.forEach(card => {
    const rid = card.id.replace('stom-card-', '');
    const t = parseInt($('stom-tip-' + rid)?.value) || 0;
    newTotal += t;
  });
  const totalEl = $('stom-total');
  const adjEl = $('stom-adj');
  if (totalEl) totalEl.textContent = '$' + newTotal;
  if (adjEl) adjEl.textContent = '$' + Math.max(0, rawCash - newTotal);

  // Trigger a recalculation so summary updates live
  scheduleCalculate();
}
function _getCutWindowForModal(cutId) {
  if (!lastDayResult) return null;
  const pool = lastDayResult.pools?.find(p => p.id === cutId);
  if (!pool) return null;
  return {
    start: pool.start,
    end: pool.end
  };
}
function _fmtAbsTime(t) {
  if (t === null || t === undefined) return '?';
  const isAm = t < 12;
  const hr = Math.floor(t);
  const mn = Math.round((t - hr) * 60);
  let h12 = hr % 12;
  if (h12 === 0) h12 = 12;
  const minStr = mn > 0 ? ':' + (mn < 10 ? '0' : '') + mn : '';
  return h12 + minStr + (isAm ? 'AM' : 'PM');
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/support.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/tabs.js
try { (() => {
function _isVisibleForFocus(el) {
  return !!(el && el.offsetParent !== null);
}
function _focusFirstEmpty(selector) {
  const inputs = document.querySelectorAll(selector);
  for (const inp of inputs) {
    if (_isVisibleForFocus(inp) && !inp.value.trim()) {
      inp.focus();
      return true;
    }
  }
  return false;
}
function _focusCashEntry() {
  if (shiftMode === 'day') {
    const activePoolId = typeof selectedDayPool !== 'undefined' && selectedDayPool ? selectedDayPool : typeof getDayPoolActiveIds === 'function' ? getDayPoolActiveIds()[0] : 'morning';
    const activeInput = $('dp-net-' + activePoolId);
    if (_isVisibleForFocus(activeInput)) {
      activeInput.focus();
      return;
    }
    _focusFirstEmpty('#day-cash-section input');
    return;
  }
  if (cashMode === 'nettotal') {
    const netInput = $('net-total-input');
    if (_isVisibleForFocus(netInput)) netInput.focus();
    return;
  }
  const billIds = ['b100', 'b50', 'b20', 'b10', 'b5', 'b1'];
  for (const id of billIds) {
    const el = $(id);
    if (_isVisibleForFocus(el) && !el.value) {
      el.focus();
      return;
    }
  }
}
function switchTab(name, btn) {
  const panel = $('tab-' + name);
  if (!panel) return;
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => {
    b.classList.remove('active');
    b.setAttribute('aria-selected', 'false');
  });
  panel.classList.add('active');
  const tabBtn = btn || $('tb-' + name);
  if (tabBtn) {
    tabBtn.classList.add('active');
    tabBtn.setAttribute('aria-selected', 'true');
  }
  requestAnimationFrame(() => {
    $('mainContent').scrollTop = 0;
  });

  // Focus synchronously — still inside the click/key gesture chain (iOS Safari requires this).
  if (name === 'staff') {
    const listId = typeof getActiveListId === 'function' ? getActiveListId() : 'staffList';
    _focusFirstEmpty('#' + listId + ' [data-field="name"]');
  }
  if (name === 'cash') _focusCashEntry();
}
function updateTabIndicators() {
  const total = getTotal();
  const cd = $('tab-dot-cash'),
    cs = $('tab-sub-cash');
  if (total > 0) {
    cd.className = 'tab-dot ok';
    cs.textContent = '$' + total;
    cs.className = 'tab-sub has-val';
  } else {
    cd.className = 'tab-dot empty';
    cs.textContent = '—';
    cs.className = 'tab-sub';
  }
  const staffSelector = shiftMode === 'day' ? '#bartenderList .staff-row-modal, #serverList .staff-row-modal' : '#staffList .staff-row-modal';
  const rows = document.querySelectorAll(staffSelector);
  let named = 0;
  rows.forEach(r => {
    if (r.querySelector('[data-field="name"]').value.trim()) named++;
  });
  const sd = $('tab-dot-staff'),
    ss = $('tab-sub-staff');
  if (named > 0) {
    sd.className = 'tab-dot ok';
    ss.textContent = named + (named === 1 ? ' person' : ' ppl');
    ss.className = 'tab-sub has-staff';
  } else {
    sd.className = 'tab-dot empty';
    ss.textContent = '—';
    ss.className = 'tab-sub';
  }
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/tabs.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/utils.js
try { (() => {
// Pure helpers — no DOM side-effects; safe to unit-test in isolation

function parseWholeNumberString(raw) {
  const text = String(raw ?? '').trim();
  if (!text) return {
    valid: true,
    empty: true,
    value: 0
  };
  if (!/^\d+$/.test(text)) return {
    valid: false,
    empty: false,
    value: 0
  };
  const value = Number(text);
  return {
    valid: Number.isSafeInteger(value),
    empty: false,
    value: Number.isSafeInteger(value) ? value : 0
  };
}
function parseTimeString(raw) {
  const text = String(raw ?? '').trim();
  if (!text) return {
    valid: true,
    empty: true,
    value: null
  };
  if (!/^(?:\d+(?:\.\d+)?|\.\d+)$/.test(text)) return {
    valid: false,
    empty: false,
    value: null
  };
  const value = Number(text);
  const inRange = Number.isFinite(value) && value >= 0 && value < 13;
  return {
    valid: inRange,
    empty: false,
    value: inRange ? value : null
  };
}
function setInputInvalid(el, invalid) {
  if (el) el.classList.toggle('input-invalid', !!invalid);
}
function getVal(id) {
  const parsed = parseWholeNumberString($(id)?.value ?? '');
  return parsed.valid && parsed.value > 0 ? parsed.value : 0;
}
function poolValue(pool) {
  return DENOMS.reduce((s, d) => s + (pool[d] || 0) * d, 0);
}
function escapeHTML(v) {
  return String(v).replace(/[&<>"']/g, c => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[c]);
}
function fmtHrs(h) {
  return parseFloat(h.toFixed(2)).toString();
}
function fmtTime(t, inTime, wrapped) {
  let hr = Math.floor(t),
    mn = Math.round((t - hr) * 60);
  if (mn === 60) {
    hr++;
    mn = 0;
  }
  let h12 = hr % 12;
  if (h12 === 0) h12 = 12;
  return h12 + (mn > 0 ? ':' + (mn < 10 ? '0' : '') + mn : '') + (wrapped ? 'a' : 'p');
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/utils.js", error: String((e && e.message) || e) }); }

// uploads/zet3-main (4)/js/utils.test.js
try { (() => {
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const ctx = {
  console
};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, 'utils.js'), 'utf8'), ctx);
assert.deepStrictEqual(ctx.parseWholeNumberString('').value, 0);
assert.strictEqual(ctx.parseWholeNumberString('12').valid, true);
assert.strictEqual(ctx.parseWholeNumberString('0012').value, 12);
assert.strictEqual(ctx.parseWholeNumberString('1.5').valid, false);
assert.strictEqual(ctx.parseWholeNumberString('5abc').valid, false);
assert.strictEqual(ctx.parseWholeNumberString('-1').valid, false);
assert.strictEqual(ctx.parseTimeString('').empty, true);
assert.strictEqual(ctx.parseTimeString('5').value, 5);
assert.strictEqual(ctx.parseTimeString('5.5').value, 5.5);
assert.strictEqual(ctx.parseTimeString('.5').value, 0.5);
assert.strictEqual(ctx.parseTimeString('12').valid, true);
assert.strictEqual(ctx.parseTimeString('12.5').valid, true);
assert.strictEqual(ctx.parseTimeString('5abc').valid, false);
assert.strictEqual(ctx.parseTimeString('-1').valid, false);
console.log('utility parsing tests passed');
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/zet3-main (4)/js/utils.test.js", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.SegmentedControl = __ds_scope.SegmentedControl;

__ds_ns.DenomRow = __ds_scope.DenomRow;

__ds_ns.MoneyValue = __ds_scope.MoneyValue;

__ds_ns.StatCard = __ds_scope.StatCard;

__ds_ns.PersonCard = __ds_scope.PersonCard;

})();
